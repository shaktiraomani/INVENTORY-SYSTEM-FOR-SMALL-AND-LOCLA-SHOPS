import { GoogleGenAI } from "@google/genai";
import { getInvoices, getParties, getProducts, getTransactions } from "./db";

export const askAI = async (prompt: string): Promise<string> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    return "API Key is missing in code configuration.";
  }

  const ai = new GoogleGenAI({ apiKey: apiKey });

  // Gather Context
  const context = {
    sales_summary: getInvoices().slice(0, 30).map(i => ({ date: i.date, total: i.totalAmount, paid: i.paidAmount, party: i.partyName, type: i.type })),
    products: getProducts().slice(0, 50).map(p => ({ name: p.name, stock: p.stock })),
    transactions: getTransactions().slice(0, 20)
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following business data JSON: ${JSON.stringify(context)}. User Query: ${prompt}`,
      config: {
        systemInstruction: "You are the AI assistant for 'Sakshi ERP Pro'. Keep the answer concise, professional, and actionable. If asking about sales, calculate totals from the provided JSON. Do not mention 'JSON' or technical terms.",
      }
    });
    return response.text || "No response generated.";
  } catch (e) {
    console.error("AI Error:", e);
    return "Failed to fetch AI response. Please check your internet connection.";
  }
};