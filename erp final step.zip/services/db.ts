import { Party, Product, Invoice, Transaction, UserSettings, StockAdjustment, ProductVariant, PartyType, UserAccount } from '../types';

// ==========================================
// CONFIGURATION
// ==========================================
const defaultSettings: UserSettings = {
  businessName: 'Sakshi Enterprises',
  address: '123 Market Road, City Center',
  phone: '9876543210',
  upiId: 'merchant@upi',
  gstin: '',
  logo: '',
  footerText: 'Thank you for your business!',
  invoicePrefix: 'INV-',
  invoiceStartSequence: 1001,
  availableGstRates: [0, 5, 12, 18, 28],
  themeColor: '#2563eb', // Default Blue
  darkMode: false,
};

// ==========================================
// MOCK DATA (FOR LOCAL PREVIEW)
// ==========================================
const MOCK_DATA = {
  parties: [
    { id: '101', name: 'Cash Customer', phone: '9999999999', address: 'Local', type: 'CUSTOMER', balance: 0 },
    { id: '102', name: 'Rahul Traders', phone: '8888888888', address: 'Industrial Area', type: 'SUPPLIER', balance: -5000 },
    { id: '103', name: 'Priya Boutique', phone: '7777777777', address: 'Main Market', type: 'CUSTOMER', balance: 2500 }
  ],
  products: [
    { id: '201', name: 'Cotton Shirt', category: 'Apparel', unit: 'PCS', buyPrice: 400, price: 800, stock: 45, variants: [] },
    { id: '202', name: 'Denim Jeans', category: 'Apparel', unit: 'PCS', buyPrice: 700, price: 1200, stock: 30, variants: [] },
    { id: '203', name: 'Running Shoes', category: 'Footwear', unit: 'PAIR', buyPrice: 1500, price: 2500, stock: 12, variants: [] }
  ],
  invoices: [
    { 
      id: 'INV-1001', date: new Date().toISOString().split('T')[0], partyId: '103', partyName: 'Priya Boutique', 
      items: [
        { id: '201', name: 'Cotton Shirt', price: 800, buyPrice: 400, unit: 'PCS', stock: 45, qty: 2, total: 1600, discount: 0, discountType: 'PERCENT', taxableValue: 1600, gstAmount: 0 }
      ],
      totalAmount: 1600, paidAmount: 0, paymentMethod: 'CREDIT', type: 'SALE', taxType: 'NONE' 
    }
  ],
  transactions: [],
  settings: defaultSettings,
  users: [
    { id: 'u1', username: 'admin', password: '123', name: 'Admin User', role: 'ADMIN' },
    { id: 'u2', username: 'staff', password: '123', name: 'Staff User', role: 'STAFF' }
  ]
};

// ==========================================
// IN-MEMORY CACHE (State Management)
// ==========================================
let _parties: Party[] = [];
let _products: Product[] = [];
let _invoices: Invoice[] = [];
let _transactions: Transaction[] = [];
let _settings: UserSettings = defaultSettings;
let _stockAdjustments: StockAdjustment[] = [];
let _users: UserAccount[] = [];

// ==========================================
// CONNECTION LAYER (Hybrid: GAS vs LocalStorage)
// ==========================================

const isGasEnvironment = () => {
  // Check if running inside Google Apps Script iframe
  return typeof window !== 'undefined' && window.google && window.google.script;
};

// Wrapper to call Backend Functions
const backendCall = async (functionName: string, payload?: any): Promise<any> => {
  if (isGasEnvironment()) {
    console.log(`[GAS] Calling ${functionName}...`);
    // Native Google Apps Script Call
    return new Promise((resolve, reject) => {
      // @ts-ignore
      window.google.script.run
        .withSuccessHandler((response: any) => {
            try {
                // Parse if string, otherwise pass through
                const result = (typeof response === 'string') ? JSON.parse(response) : response;
                resolve(result);
            } catch (e) {
                console.error("JSON Parse Error from Backend:", e);
                // Return raw response if parse fails, might be useful
                resolve(response);
            }
        })
        .withFailureHandler((err: any) => {
            console.error("GAS Failure:", err);
            reject(err);
        })
        [functionName](payload ? JSON.stringify(payload) : undefined);
    });
  } else {
    // === LOCAL SIMULATION MODE ===
    console.log(`[Local Mode] calling ${functionName}`, payload);
    
    return new Promise((resolve) => {
        setTimeout(() => {
            const lsKey = 'sakshi_erp_local_data_v3';
            let localData: any = null;
            
            try {
              const raw = localStorage.getItem(lsKey);
              if (raw) localData = JSON.parse(raw);
            } catch (e) {
              console.warn("Failed to parse local storage, resetting.");
            }

            if (functionName === 'apiGetData') {
                if (!localData || !localData.parties) {
                    console.log("[Local Mode] Seeding Mock Data...");
                    localData = MOCK_DATA;
                    localStorage.setItem(lsKey, JSON.stringify(localData));
                }
                resolve(localData);
            } else if (functionName === 'apiPostData') {
                // Simulate saving to DB by updating LocalStorage
                if (!localData) localData = MOCK_DATA;
                
                const { type, action, payload: item } = payload;
                const collectionMap: Record<string, string> = {
                   'party': 'parties',
                   'product': 'products',
                   'invoice': 'invoices',
                   'transaction': 'transactions',
                   'setting': 'settings',
                   'user': 'users'
                };
                
                const key = collectionMap[type];
                
                if (type === 'setting') {
                    localData.settings = item;
                } else if (key && Array.isArray(localData[key])) {
                    if (action === 'create') {
                        localData[key].push(item);
                    } else if (action === 'update') {
                        const idx = localData[key].findIndex((x: any) => x.id === item.id);
                        if (idx >= 0) localData[key][idx] = item;
                    } else if (action === 'delete') {
                        localData[key] = localData[key].filter((x: any) => x.id !== item.id);
                    }
                }
                
                localStorage.setItem(lsKey, JSON.stringify(localData));
                resolve({ status: 'success' });
            }
        }, 500); // Simulate network delay
    });
  }
};

// ==========================================
// SYNC STATUS FOR UI
// ==========================================
export const syncStatus = {
    listeners: [] as ((status: 'idle' | 'saving' | 'saved' | 'error') => void)[],
    subscribe(fn: (status: 'idle' | 'saving' | 'saved' | 'error') => void) {
        this.listeners.push(fn);
        return () => { this.listeners = this.listeners.filter(l => l !== fn); };
    },
    notify(status: 'idle' | 'saving' | 'saved' | 'error') {
        this.listeners.forEach(fn => fn(status));
    }
};

const syncToSheet = async (payload: any) => {
  syncStatus.notify('saving');
  try {
    await backendCall('apiPostData', payload);
    syncStatus.notify('saved');
    setTimeout(() => syncStatus.notify('idle'), 2000);
  } catch (error) {
    console.error("Failed to sync", error);
    syncStatus.notify('error');
    alert("Connection Error: Data saved locally but failed to sync to Google Sheet. Please check internet.");
  }
};

export const refreshData = async () => {
    syncStatus.notify('saving'); 
    await initDB();
    syncStatus.notify('saved');
    setTimeout(() => syncStatus.notify('idle'), 1000);
};

// Initialize App: Load ALL data
export const initDB = async (): Promise<boolean> => {
  try {
    console.log("Initializing DB...");
    const data = await backendCall('apiGetData');
    
    // Safety check for empty return
    if (!data) {
       console.warn("No data received from backend.");
       return false;
    }

    _parties = data.parties || [];
    _products = (data.products || []).map((p: any) => {
        let variants = [];
        try {
            variants = typeof p.variants === 'string' ? JSON.parse(p.variants) : p.variants;
        } catch(e) { /* ignore */ }
        return { ...p, variants: variants || [] };
    });
    _invoices = (data.invoices || []).map((inv: any) => {
        let items = [];
        try {
            items = typeof inv.items === 'string' ? JSON.parse(inv.items) : inv.items;
        } catch(e) { console.error("Error parsing invoice items", e); }
        return { ...inv, items: items || [] };
    });
    _transactions = data.transactions || [];
    
    // USERS (If empty, seed admin)
    _users = data.users || [];
    if (_users.length === 0) {
        // Fallback admin if DB is fresh
        _users.push({ id: 'u1', username: 'admin', password: '123', name: 'Administrator', role: 'ADMIN' });
    }

    const fetchedSettings = data.settings || {};
    
    // ROBUST SETTINGS PARSING
    // Ensure availableGstRates is strictly an array
    let gstRates = defaultSettings.availableGstRates;
    if (fetchedSettings.availableGstRates) {
        if (typeof fetchedSettings.availableGstRates === 'string') {
            try {
                // Handle case where it might be empty string or invalid JSON
                if (fetchedSettings.availableGstRates.trim() !== "") {
                    const parsed = JSON.parse(fetchedSettings.availableGstRates);
                    if (Array.isArray(parsed)) gstRates = parsed;
                }
            } catch(e){
                console.warn("Failed to parse GST rates, using default.");
            }
        } else if (Array.isArray(fetchedSettings.availableGstRates)) {
             gstRates = fetchedSettings.availableGstRates;
        }
    }

    _settings = { ...defaultSettings, ...fetchedSettings, availableGstRates: gstRates };
    
    // Apply Dark Mode immediately
    if (_settings.darkMode) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }

    // Set Favicon if logo exists
    if (_settings.logo) {
        const link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
        if (link) link.href = _settings.logo;
        else {
            const newLink = document.createElement('link');
            newLink.rel = 'icon';
            newLink.href = _settings.logo;
            document.head.appendChild(newLink);
        }
    }

    console.log("DB Initialized. Invoices:", _invoices.length);
    return true;
  } catch (error) {
    console.error("Error loading data", error);
    return false;
  }
};

// ==========================================
// GETTERS
// ==========================================
export const generateId = () => Math.random().toString(36).substr(2, 9);

// Custom Invoice Number Generation
const generateInvoiceNumber = (): string => {
  const prefix = _settings.invoicePrefix || 'INV-';
  const startSeq = _settings.invoiceStartSequence || 1001;
  
  let maxSeq = 0;
  
  // Find highest sequence number currently used for this prefix
  _invoices.forEach(inv => {
      if (inv.id && inv.id.startsWith(prefix)) {
          const suffix = inv.id.replace(prefix, '');
          const seq = parseInt(suffix, 10);
          if (!isNaN(seq)) {
              maxSeq = Math.max(maxSeq, seq);
          }
      }
  });

  // Next is either the configured start sequence, or one more than current max
  const nextSeq = Math.max(startSeq, maxSeq + 1);

  return `${prefix}${nextSeq}`;
};

export const getSettings = (): UserSettings => _settings;
export const getParties = (): Party[] => [..._parties];
export const getProducts = (): Product[] => [..._products];
export const getInvoices = (): Invoice[] => [..._invoices];
export const getTransactions = (): Transaction[] => [..._transactions];
export const getStockAdjustments = (): StockAdjustment[] => [..._stockAdjustments];
export const getUsers = (): UserAccount[] => [..._users];

export const getLowStockProducts = (threshold: number = 10): Product[] => {
  return _products.filter(p => {
    if (p.variants && p.variants.length > 0) {
      return p.variants.some(v => v.stock < threshold);
    }
    return p.stock < threshold;
  });
};

// ==========================================
// AUTHENTICATION
// ==========================================
export const authenticate = (username: string, password: string): UserAccount | null => {
    const user = _users.find(u => u.username === username && u.password === password);
    return user || null;
};

// ==========================================
// SETTERS (Optimistic Updates + Background Sync)
// ==========================================

// --- USERS ---
export const saveUser = (user: UserAccount) => {
    const isNew = !user.id;
    const u = { ...user, id: user.id || generateId() };
    
    const idx = _users.findIndex(x => x.id === u.id);
    if (idx >= 0) _users[idx] = u;
    else _users.push(u);

    syncToSheet({ type: 'user', action: isNew ? 'create' : 'update', payload: u });
};

export const deleteUser = (id: string) => {
    _users = _users.filter(u => u.id !== id);
    syncToSheet({ type: 'user', action: 'delete', payload: { id } });
};

export const saveSettings = (s: UserSettings) => {
  _settings = s;
  
  // Toggle Dark Mode DOM Class immediately
  if (s.darkMode) document.documentElement.classList.add('dark');
  else document.documentElement.classList.remove('dark');

  const payload = { ...s, availableGstRates: JSON.stringify(s.availableGstRates || []) };
  syncToSheet({ type: 'setting', action: 'update', payload: payload });
  
  // Update Favicon Immediately
  if (s.logo) {
      const link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
      if (link) link.href = s.logo;
  }
};

// --- PARTY ---
export const saveParty = (party: Party) => {
  const isNew = !party.id;
  const p = { ...party, id: party.id || generateId() };
  
  const idx = _parties.findIndex(x => x.id === p.id);
  if (idx >= 0) _parties[idx] = p;
  else _parties.push(p);

  syncToSheet({ type: 'party', action: isNew ? 'create' : 'update', payload: p });
};

export const deleteParty = (id: string) => {
  _parties = _parties.filter(p => p.id !== id);
  syncToSheet({ type: 'party', action: 'delete', payload: { id } });
};

// --- PRODUCT ---
export const saveProduct = (product: Product) => {
  const isNew = !product.id;
  let calculatedStock = product.stock;
  if (product.variants && product.variants.length > 0) {
      calculatedStock = product.variants.reduce((acc, v) => acc + v.stock, 0);
  }

  const p = { ...product, stock: calculatedStock, id: product.id || generateId() };
  const payload = { ...p, variants: JSON.stringify(p.variants || []) };

  const idx = _products.findIndex(x => x.id === p.id);
  if (idx >= 0) _products[idx] = p;
  else _products.push(p);

  syncToSheet({ type: 'product', action: isNew ? 'create' : 'update', payload: payload });
};

export const deleteProduct = (id: string) => {
  _products = _products.filter(p => p.id !== id);
  syncToSheet({ type: 'product', action: 'delete', payload: { id } });
};

const updateStockInternal = (productId: string, variantId: string | undefined, qtyChange: number) => {
    const pIdx = _products.findIndex(p => p.id === productId);
    if (pIdx >= 0) {
        const product = _products[pIdx];
        if (variantId && product.variants) {
            const vIdx = product.variants.findIndex(v => v.id === variantId);
            if (vIdx >= 0) {
                product.variants[vIdx].stock += qtyChange;
                product.stock = product.variants.reduce((acc, v) => acc + v.stock, 0);
            }
        } else {
            product.stock += qtyChange;
        }
        const payload = { ...product, variants: JSON.stringify(product.variants || []) };
        syncToSheet({ type: 'product', action: 'update', payload: payload });
    }
};

export const adjustStock = (adjustment: Omit<StockAdjustment, 'id' | 'date'>) => {
  const newAdj: StockAdjustment = {
    ...adjustment,
    id: generateId(),
    date: new Date().toISOString().split('T')[0]
  };
  _stockAdjustments.unshift(newAdj);
  const qtyChange = adjustment.type === 'INCREASE' ? adjustment.qty : -adjustment.qty;
  updateStockInternal(adjustment.productId, adjustment.variantId, qtyChange);
};

// --- INVOICE ---
export const createInvoice = (invoice: Invoice) => {
  const newInvoice = { ...invoice, id: generateInvoiceNumber() };
  _invoices.unshift(newInvoice);

  newInvoice.items.forEach(item => {
    const qtyEffect = newInvoice.type === 'SALE' ? -item.qty : item.qty;
    updateStockInternal(item.id, item.variantId, qtyEffect);
  });

  const partyIdx = _parties.findIndex(p => p.id === newInvoice.partyId);
  if (partyIdx >= 0) {
    const due = newInvoice.totalAmount - newInvoice.paidAmount;
    if (newInvoice.type === 'SALE') _parties[partyIdx].balance += due;
    else _parties[partyIdx].balance -= due;
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  const sheetPayload = {
    ...newInvoice,
    items: JSON.stringify(newInvoice.items)
  };
  syncToSheet({ type: 'invoice', action: 'create', payload: sheetPayload });
};

export const updateInvoice = (updatedInvoice: Invoice) => {
  const idx = _invoices.findIndex(i => i.id === updatedInvoice.id);
  if (idx === -1) return;
  const oldInvoice = _invoices[idx];

  // Reverse old stock
  oldInvoice.items.forEach(item => {
      const reverseEffect = oldInvoice.type === 'SALE' ? item.qty : -item.qty;
      updateStockInternal(item.id, item.variantId, reverseEffect);
  });

  // Reverse old balance
  const oldPartyIdx = _parties.findIndex(p => p.id === oldInvoice.partyId);
  if (oldPartyIdx >= 0) {
      const oldDue = oldInvoice.totalAmount - oldInvoice.paidAmount;
      if (oldInvoice.type === 'SALE') _parties[oldPartyIdx].balance -= oldDue; 
      else _parties[oldPartyIdx].balance += oldDue; 
      syncToSheet({ type: 'party', action: 'update', payload: _parties[oldPartyIdx] });
  }

  // Apply new stock
  updatedInvoice.items.forEach(item => {
      const newEffect = updatedInvoice.type === 'SALE' ? -item.qty : item.qty;
      updateStockInternal(item.id, item.variantId, newEffect);
  });

  // Apply new balance
  const newPartyIdx = _parties.findIndex(p => p.id === updatedInvoice.partyId);
  if (newPartyIdx >= 0) {
      const newDue = updatedInvoice.totalAmount - updatedInvoice.paidAmount;
      if (updatedInvoice.type === 'SALE') _parties[newPartyIdx].balance += newDue;
      else _parties[newPartyIdx].balance -= newDue;
      syncToSheet({ type: 'party', action: 'update', payload: _parties[newPartyIdx] });
  }
  
  _invoices[idx] = updatedInvoice;
  const sheetPayload = { ...updatedInvoice, items: JSON.stringify(updatedInvoice.items) };
  syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload }); 
};

export const deleteInvoice = (id: string) => {
  const invoice = _invoices.find(i => i.id === id);
  if (!invoice) return;

  invoice.items.forEach(item => {
    const reverseEffect = invoice.type === 'SALE' ? item.qty : -item.qty;
    updateStockInternal(item.id, item.variantId, reverseEffect);
  });

  const partyIdx = _parties.findIndex(p => p.id === invoice.partyId);
  if (partyIdx >= 0) {
    const due = invoice.totalAmount - invoice.paidAmount;
    if (invoice.type === 'SALE') _parties[partyIdx].balance -= due;
    else _parties[partyIdx].balance += due;
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  _invoices = _invoices.filter(i => i.id !== id);
  syncToSheet({ type: 'invoice', action: 'delete', payload: { id } });
};

// --- TRANSACTIONS ---
export const createTransaction = (transaction: Transaction) => {
  const newTx = { ...transaction, id: generateId() };
  _transactions.unshift(newTx);

  const partyIdx = _parties.findIndex(p => p.id === transaction.partyId);
  if (partyIdx >= 0) {
    if (transaction.type === 'PAYMENT_IN') _parties[partyIdx].balance -= transaction.amount;
    else _parties[partyIdx].balance += transaction.amount;
    
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  if (transaction.invoiceId) {
      const invIdx = _invoices.findIndex(i => i.id === transaction.invoiceId);
      if (invIdx >= 0) {
          _invoices[invIdx].paidAmount += transaction.amount;
          const sheetPayload = { ..._invoices[invIdx], items: JSON.stringify(_invoices[invIdx].items) };
          syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload });
      }
  }

  syncToSheet({ type: 'transaction', action: 'create', payload: newTx });
};

export const updateTransaction = (updatedTx: Transaction) => {
  const idx = _transactions.findIndex(t => t.id === updatedTx.id);
  if (idx === -1) return;
  const oldTx = _transactions[idx];

  // 1. Reverse Old Transaction Effect
  // Party Balance
  const oldPartyIdx = _parties.findIndex(p => p.id === oldTx.partyId);
  if (oldPartyIdx >= 0) {
      if (oldTx.type === 'PAYMENT_IN') _parties[oldPartyIdx].balance += oldTx.amount;
      else _parties[oldPartyIdx].balance -= oldTx.amount;
      // Note: We sync later to avoid double sync if party is same
  }

  // Invoice Paid Amount
  if (oldTx.invoiceId) {
      const oldInvIdx = _invoices.findIndex(i => i.id === oldTx.invoiceId);
      if (oldInvIdx >= 0) {
          _invoices[oldInvIdx].paidAmount -= oldTx.amount;
          const sheetPayload = { ..._invoices[oldInvIdx], items: JSON.stringify(_invoices[oldInvIdx].items) };
          syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload });
      }
  }

  // 2. Apply New Transaction Effect
  // Party Balance
  const newPartyIdx = _parties.findIndex(p => p.id === updatedTx.partyId);
  if (newPartyIdx >= 0) {
      if (updatedTx.type === 'PAYMENT_IN') _parties[newPartyIdx].balance -= updatedTx.amount;
      else _parties[newPartyIdx].balance += updatedTx.amount;
      syncToSheet({ type: 'party', action: 'update', payload: _parties[newPartyIdx] });

      // Sync old party if different
      if (oldTx.partyId !== updatedTx.partyId && oldPartyIdx >= 0) {
          syncToSheet({ type: 'party', action: 'update', payload: _parties[oldPartyIdx] });
      }
  }

  // Invoice Paid Amount
  if (updatedTx.invoiceId) {
      const newInvIdx = _invoices.findIndex(i => i.id === updatedTx.invoiceId);
      if (newInvIdx >= 0) {
          _invoices[newInvIdx].paidAmount += updatedTx.amount;
          const sheetPayload = { ..._invoices[newInvIdx], items: JSON.stringify(_invoices[newInvIdx].items) };
          syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload });
      }
  }

  _transactions[idx] = updatedTx;
  syncToSheet({ type: 'transaction', action: 'update', payload: updatedTx });
};

export const deleteTransaction = (id: string) => {
  const transaction = _transactions.find(t => t.id === id);
  if (!transaction) return;

  // 1. Reverse Party Balance Effect
  const partyIdx = _parties.findIndex(p => p.id === transaction.partyId);
  if (partyIdx >= 0) {
    if (transaction.type === 'PAYMENT_IN') _parties[partyIdx].balance += transaction.amount;
    else _parties[partyIdx].balance -= transaction.amount;
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  // 2. Reverse Invoice Paid Amount Effect
  if (transaction.invoiceId) {
      const invIdx = _invoices.findIndex(i => i.id === transaction.invoiceId);
      if (invIdx >= 0) {
          _invoices[invIdx].paidAmount -= transaction.amount;
          const sheetPayload = { ..._invoices[invIdx], items: JSON.stringify(_invoices[invIdx].items) };
          syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload });
      }
  }

  // 3. Delete Transaction
  _transactions = _transactions.filter(t => t.id !== id);
  syncToSheet({ type: 'transaction', action: 'delete', payload: { id } });
};
