
import React, { useEffect, useState } from 'react';
import { Invoice, UserSettings, PrintOptions } from '../types';
import QRCode from 'qrcode';

interface Props {
  invoice: Invoice;
  settings: UserSettings;
  options: PrintOptions;
}

export const InvoiceTemplate: React.FC<Props> = ({ invoice, settings, options }) => {
  const [qrUrl, setQrUrl] = useState('');

  const isSale = invoice.type === 'SALE';
  const docTitle = isSale ? 'INVOICE' : 'PURCHASE ORDER';
  const partyLabel = isSale ? 'Billed To' : 'Vendor / Supplier';
  const isInterState = invoice.taxType === 'INTER';
  const isNoTax = invoice.taxType === 'NONE';
  
  // Default to blue if no theme color set
  const themeColor = settings.themeColor || '#2563eb';

  // Font Classes
  const fontClass = {
      'sans': 'font-sans',
      'serif': 'font-serif',
      'mono': 'font-mono'
  }[options.font || 'sans'];

  // Logo Size Classes
  const logoClass = {
      'sm': 'h-12',
      'md': 'h-16',
      'lg': 'h-24'
  }[options.logoSize || 'md'];

  useEffect(() => {
    if (isSale && settings.upiId && options.showQr) {
      // Clean UPI ID
      const upiId = settings.upiId.trim();
      if (!upiId) return;

      const upiString = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(settings.businessName)}&am=${invoice.totalAmount.toFixed(2)}&tr=${invoice.id}&tn=Inv-${invoice.id}`;
      
      QRCode.toDataURL(upiString, { margin: 0 })
        .then(setQrUrl)
        .catch(console.error);
    } else {
        setQrUrl('');
    }
  }, [invoice, settings, options.showQr, isSale]);

  const totalDiscount = invoice.items.reduce((acc, item) => {
    const gross = item.price * item.qty;
    let discAmt = item.discountType === 'PERCENT' ? (gross * item.discount) / 100 : item.discount;
    return acc + discAmt;
  }, 0);

  const totalTaxAmt = invoice.items.reduce((acc, item) => acc + (item.gstAmount || 0), 0);

  return (
    <div className={`max-w-[210mm] mx-auto p-8 bg-white min-h-[297mm] text-slate-800 ${fontClass}`} style={{ borderTop: `8px solid ${themeColor}` }}>
      
      {/* HEADER */}
      {options.showHeader && (
        <header className="flex justify-between items-start border-b-2 pb-6 mb-8" style={{ borderColor: themeColor }}>
            <div className="flex-1">
                {settings.logo && (
                    <img src={settings.logo} alt="Logo" className={`${logoClass} object-contain mb-3`} />
                )}
                <h1 className="text-2xl font-bold uppercase tracking-tight" style={{ color: themeColor }}>{settings.businessName}</h1>
                <div className="text-sm mt-1 text-slate-600 whitespace-pre-line max-w-xs leading-tight">{settings.address}</div>
                <div className="text-sm text-slate-600 font-medium mt-1">Ph: {settings.phone}</div>
                {settings.gstin && <div className="text-sm text-slate-600">GSTIN: {settings.gstin}</div>}
            </div>
            <div className="text-right">
                <div className="text-4xl font-extrabold text-slate-100 uppercase tracking-widest select-none">
                    {docTitle}
                </div>
                <div className="mt-4">
                    <table className="text-right ml-auto text-sm">
                        <tbody>
                            <tr><td className="pr-4 text-slate-500">Invoice No:</td><td className="font-bold text-lg">{invoice.id}</td></tr>
                            <tr><td className="pr-4 text-slate-500">Date:</td><td className="font-bold">{invoice.date}</td></tr>
                            {invoice.dueDate && (
                                <tr><td className="pr-4 text-slate-500">Due Date:</td><td className="font-bold text-red-600">{invoice.dueDate}</td></tr>
                            )}
                            {invoice.referenceNo && (
                                <tr><td className="pr-4 text-slate-500">Reference:</td><td className="font-bold">{invoice.referenceNo}</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </header>
      )}

      {/* BILL TO & QR CODE */}
      <div className="flex justify-between items-start mb-8">
        <div className="w-1/2 p-4 bg-slate-50 rounded border border-slate-100">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">{partyLabel}</h3>
            <div className="font-bold text-lg text-slate-800">{invoice.partyName}</div>
            <div className="text-sm text-slate-600 mt-1">{invoice.items[0]?.variantId ? 'Details unavailable' : ''}</div>
            {invoice.gstin && <div className="text-sm text-slate-600 mt-1 font-mono">GSTIN: {invoice.gstin}</div>}
        </div>

        {/* QR CODE SECTION */}
        {options.showQr && qrUrl && (
            <div className="flex flex-col items-center">
                <div className="border p-2 bg-white rounded shadow-sm">
                   <img src={qrUrl} alt="UPI QR" className="w-24 h-24" />
                </div>
                <span className="text-[10px] uppercase font-bold text-slate-400 mt-1">Scan to Pay</span>
                <span className="text-xs font-bold text-slate-700">₹ {invoice.totalAmount.toFixed(2)}</span>
            </div>
        )}
      </div>

      {/* ITEM TABLE */}
      <table className="w-full mb-8 border-collapse">
        <thead>
            <tr className="text-white text-sm uppercase" style={{ backgroundColor: themeColor }}>
                <th className="p-3 text-left first:rounded-tl last:rounded-tr">Item</th>
                <th className="p-3 text-right">Price</th>
                <th className="p-3 text-center">Qty</th>
                <th className="p-3 text-right">Disc</th>
                { !isNoTax && (
                    <>
                        <th className="p-3 text-right">Taxable</th>
                        {isInterState ? (
                            <th className="p-3 text-right">IGST</th>
                        ) : (
                            <>
                                <th className="p-3 text-right">CGST</th>
                                <th className="p-3 text-right">SGST</th>
                            </>
                        )}
                    </>
                )}
                <th className="p-3 text-right last:rounded-tr">Total</th>
            </tr>
        </thead>
        <tbody className="text-sm">
            {invoice.items.map((item, idx) => {
                const taxAmt = item.gstAmount || 0;
                const rate = item.gstRate || 0;
                const isEven = idx % 2 === 0;
                return (
                    <tr key={idx} className={`border-b border-slate-100 ${isEven ? 'bg-white' : 'bg-slate-50'}`}>
                        <td className="p-3 font-medium text-slate-700">
                            {item.name}
                            {item.hsn && <span className="block text-[9px] text-slate-400">HSN: {item.hsn}</span>}
                        </td>
                        <td className="p-3 text-right">{item.price.toFixed(2)}</td>
                        <td className="p-3 text-center">{item.qty}</td>
                        <td className="p-3 text-right text-slate-500">
                            {item.discountType === 'PERCENT' && item.discount > 0 ? `${item.discount}%` : (item.discount > 0 ? item.discount : '-')}
                        </td>
                        { !isNoTax && (
                            <>
                                <td className="p-3 text-right font-mono text-slate-600">{item.taxableValue?.toFixed(2)}</td>
                                {isInterState ? (
                                    <td className="p-3 text-right">
                                        <div>{taxAmt.toFixed(2)}</div>
                                        <div className="text-[9px] text-slate-400">({rate}%)</div>
                                    </td>
                                ) : (
                                    <>
                                        <td className="p-3 text-right">
                                            <div>{(taxAmt/2).toFixed(2)}</div>
                                            <div className="text-[9px] text-slate-400">({rate/2}%)</div>
                                        </td>
                                        <td className="p-3 text-right">
                                            <div>{(taxAmt/2).toFixed(2)}</div>
                                            <div className="text-[9px] text-slate-400">({rate/2}%)</div>
                                        </td>
                                    </>
                                )}
                            </>
                        )}
                        <td className="p-3 text-right font-bold text-slate-800">{item.total.toFixed(2)}</td>
                    </tr>
                );
            })}
        </tbody>
      </table>

      {/* FOOTER TOTALS */}
      <div className="flex justify-end mb-12">
          <div className="w-1/2 lg:w-1/3">
             <div className="space-y-2 text-sm">
                {totalDiscount > 0 && (
                    <div className="flex justify-between text-slate-500">
                        <span>Total Discount</span>
                        <span className="text-green-600 font-medium">- ₹ {totalDiscount.toFixed(2)}</span>
                    </div>
                )}
                { !isNoTax && (
                    <div className="flex justify-between text-slate-500">
                        <span>Total Tax (GST)</span>
                        <span className="font-medium">₹ {totalTaxAmt.toFixed(2)}</span>
                    </div>
                )}
                <div className="flex justify-between items-center py-2 border-t border-b border-slate-300">
                    <span className="font-bold text-lg" style={{ color: themeColor }}>Grand Total</span>
                    <span className="font-bold text-xl" style={{ color: themeColor }}>₹ {invoice.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-500 pt-1">
                    <span>Paid Amount</span>
                    <span className="font-medium">₹ {invoice.paidAmount.toFixed(2)}</span>
                </div>
                {(invoice.totalAmount - invoice.paidAmount) > 0.01 && (
                    <div className="flex justify-between text-red-600 font-bold pt-1">
                        <span>Balance Due</span>
                        <span>₹ {(invoice.totalAmount - invoice.paidAmount).toFixed(2)}</span>
                    </div>
                )}
             </div>
          </div>
      </div>

      {/* TERMS & SIGNATURE */}
      {options.showFooter && (
        <footer className="mt-auto flex flex-col justify-between text-xs text-slate-400">
            <div className="flex justify-between items-end">
                <div className="w-2/3 pr-8">
                     <h4 className="font-bold text-slate-600 mb-1">Terms & Conditions</h4>
                     {settings.footerText ? (
                         <p className="whitespace-pre-wrap leading-relaxed">{settings.footerText}</p>
                     ) : (
                         <ul className="list-disc list-inside space-y-1">
                             <li>Goods once sold will not be taken back.</li>
                             <li>Interest @24% p.a. will be charged if payment is delayed.</li>
                             <li>Subject to local jurisdiction.</li>
                         </ul>
                     )}
                </div>
                <div className="text-center">
                     <div className="h-16 w-32 border-b-2 border-slate-300 mb-2"></div>
                     <span className="font-bold text-slate-600">Authorized Signatory</span>
                </div>
            </div>
            
            <div className="text-center mt-8 pt-4 border-t border-slate-100 text-[10px]">
                Generated by Sakshi ERP Pro
            </div>
        </footer>
      )}
    </div>
  );
};
