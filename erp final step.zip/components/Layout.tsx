
import React, { useState } from 'react';
import { LayoutDashboard, Users, Package, ShoppingCart, CreditCard, FileText, Settings, Bot, Menu, X, Cloud, CloudOff, RefreshCw, LogOut } from 'lucide-react';
import { syncStatus, refreshData } from '../services/db';
import { UserRole } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
  userRole: UserRole;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange, onLogout, userRole }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [syncState, setSyncState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  React.useEffect(() => {
    return syncStatus.subscribe(setSyncState);
  }, []);

  // Define full menu
  const allMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} />, roles: ['ADMIN', 'STAFF'] },
    { id: 'billing', label: 'Billing / Purchase', icon: <ShoppingCart size={20} />, roles: ['ADMIN', 'STAFF'] },
    { id: 'parties', label: 'Parties', icon: <Users size={20} />, roles: ['ADMIN', 'STAFF'] },
    { id: 'products', label: 'Products', icon: <Package size={20} />, roles: ['ADMIN', 'STAFF'] },
    { id: 'payments', label: 'Payments', icon: <CreditCard size={20} />, roles: ['ADMIN', 'STAFF'] },
    { id: 'reports', label: 'Reports', icon: <FileText size={20} />, roles: ['ADMIN'] },
    { id: 'ai', label: 'Ask AI', icon: <Bot size={20} />, roles: ['ADMIN'] },
    { id: 'settings', label: 'Settings', icon: <Settings size={20} />, roles: ['ADMIN'] },
  ];

  // Filter based on role
  const menu = allMenuItems.filter(item => item.roles.includes(userRole));

  const handleNavClick = (id: string) => {
    onTabChange(id);
    setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-full w-full bg-slate-50 dark:bg-slate-900 overflow-hidden relative transition-colors duration-300">
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Fixed Height & Scrollable */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col h-full transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } no-print shadow-2xl md:shadow-none border-r border-slate-800`}
      >
        <div className="p-6 flex justify-between items-center shrink-0">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
              Sakshi ERP
            </h1>
            <p className="text-xs text-slate-400 mt-1">Professional Edition • {userRole}</p>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)} 
            className="md:hidden text-slate-400 hover:text-white bg-slate-800 p-1 rounded"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Navigation */}
        <nav className="flex-1 px-4 space-y-2 overflow-y-auto custom-scrollbar">
          {menu.map(item => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg translate-x-1' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        
        {/* Footer with Logout */}
        <div className="p-4 border-t border-slate-800 shrink-0 bg-slate-900 space-y-4">
          <button 
            onClick={onLogout}
            className="w-full flex items-center gap-2 px-4 py-2 text-red-400 hover:text-white hover:bg-red-900/30 rounded-lg transition"
          >
              <LogOut size={18} /> Logout
          </button>
          <div className="text-center text-xs text-slate-500">
            © 2025 Aapbiti New SRM
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full w-full overflow-hidden relative bg-slate-50 dark:bg-slate-900 transition-colors duration-300">
        <header className="bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 px-4 md:px-8 py-3 sticky top-0 z-30 no-print flex justify-between items-center shadow-sm shrink-0 h-16 transition-colors duration-300">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="md:hidden text-slate-600 dark:text-slate-300 hover:text-blue-600 p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700"
            >
              <Menu size={24} />
            </button>
            <h2 className="text-xl font-bold text-slate-800 dark:text-white capitalize truncate">{activeTab}</h2>
          </div>

          <div className="flex items-center gap-3">
             <button 
                onClick={() => refreshData()}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition"
                title="Force Refresh"
             >
                <RefreshCw size={20} className={syncState === 'saving' ? 'animate-spin' : ''} />
             </button>

             <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 dark:bg-slate-700 border border-slate-200 dark:border-slate-600 text-xs font-medium">
                {syncState === 'saving' && <><RefreshCw size={12} className="animate-spin text-blue-600 dark:text-blue-400" /><span className="text-blue-600 dark:text-blue-400 hidden sm:inline">Saving...</span></>}
                {syncState === 'saved' && <><Cloud size={12} className="text-green-600 dark:text-green-400" /><span className="text-green-600 dark:text-green-400 hidden sm:inline">Saved</span></>}
                {syncState === 'error' && <><CloudOff size={12} className="text-red-500" /><span className="text-red-500 hidden sm:inline">Sync Error</span></>}
                {syncState === 'idle' && <><span className="w-2 h-2 rounded-full bg-green-500"></span><span className="text-slate-600 dark:text-slate-300 hidden sm:inline">Online</span></>}
             </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 custom-scrollbar">
          {children}
        </div>
      </main>
    </div>
  );
};
