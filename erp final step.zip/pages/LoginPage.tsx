
import React, { useState } from 'react';
import { Lock, User } from 'lucide-react';
import * as db from '../services/db';
import { UserAccount } from '../types';

interface Props {
  onLogin: (user: UserAccount) => void;
}

export const LoginPage: React.FC<Props> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Ensure DB is init to get latest users
    await db.initDB();
    
    const user = db.authenticate(username, password);

    if (user) {
        // Persist simple session
        localStorage.setItem('sakshi_erp_user_id', user.id);
        onLogin(user);
    } else {
        setError('Invalid Username or Password');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Sakshi ERP</h1>
            <p className="text-slate-500 text-sm">Professional Edition</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
            <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Username</label>
                <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                        type="text" 
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="Enter username"
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                    />
                </div>
            </div>

            <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Password</label>
                <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                        type="password" 
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="••••••••"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                    />
                </div>
            </div>

            {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}

            <button 
                disabled={loading}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition disabled:opacity-50"
            >
                {loading ? 'Verifying...' : 'Login Securely'}
            </button>
        </form>
        
        <div className="mt-6 text-center">
            <p className="text-xs text-slate-400">Default Logins:</p>
            <p className="text-xs text-slate-500">Admin: admin / 123</p>
            <p className="text-xs text-slate-500">Staff: staff / 123</p>
            <p className="text-xs text-slate-400 mt-2">&copy; 2025 Aapbiti New SRM</p>
        </div>
      </div>
    </div>
  );
};
