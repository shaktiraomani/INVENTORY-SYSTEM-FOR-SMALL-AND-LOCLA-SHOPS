
import React, { useState, useEffect } from 'react';
import { UserSettings, UserAccount } from '../types';
import * as db from '../services/db';
import { User, Lock, Plus, Trash, Palette, Moon, Sun, Users, Shield } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<UserSettings>(db.getSettings());
  const [logoPreview, setLogoPreview] = useState<string>(settings.logo || '');
  const [newGstRate, setNewGstRate] = useState<string>('');
  
  // User Management State
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [newUser, setNewUser] = useState({ username: '', password: '', name: '', role: 'STAFF' as 'STAFF' | 'ADMIN' });
  const [activeTab, setActiveTab] = useState<'general' | 'users'>('general');

  useEffect(() => {
      setUsers(db.getUsers());
  }, []);

  // Define brand colors
  const THEME_COLORS = [
      { name: 'Blue', hex: '#2563eb' },
      { name: 'Purple', hex: '#9333ea' },
      { name: 'Green', hex: '#16a34a' },
      { name: 'Red', hex: '#dc2626' },
      { name: 'Orange', hex: '#ea580c' },
      { name: 'Black', hex: '#1e293b' },
  ];

  // Handle File Upload & Compression
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const maxWidth = 300; 
        const scale = maxWidth / img.width;
        
        canvas.width = maxWidth;
        canvas.height = img.height * scale;

        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7); 
        
        setSettings({ ...settings, logo: compressedBase64 });
        setLogoPreview(compressedBase64);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const url = e.target.value;
      setSettings({ ...settings, logo: url });
      setLogoPreview(url);
  };

  const handleAddGstRate = () => {
      const rate = parseFloat(newGstRate);
      if (isNaN(rate)) return;
      
      const currentRates = Array.isArray(settings.availableGstRates) ? settings.availableGstRates : [];
      if (currentRates.includes(rate)) return;
      
      const newRates = [...currentRates, rate].sort((a,b) => a-b);
      setSettings({...settings, availableGstRates: newRates});
      setNewGstRate('');
  };

  const removeGstRate = (rate: number) => {
      const currentRates = Array.isArray(settings.availableGstRates) ? settings.availableGstRates : [];
      const newRates = currentRates.filter(r => r !== rate);
      setSettings({...settings, availableGstRates: newRates});
  };

  const toggleDarkMode = () => {
    const newVal = !settings.darkMode;
    setSettings({...settings, darkMode: newVal});
    if (newVal) document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  };

  const handleSave = () => {
    db.saveSettings(settings);
    alert('Settings saved! If you changed the logo, please refresh the page to see the new Favicon.');
  };

  // --- USER MANAGEMENT ---
  const handleAddUser = (e: React.FormEvent) => {
      e.preventDefault();
      if (!newUser.username || !newUser.password) return;
      
      db.saveUser({
          id: '',
          username: newUser.username,
          password: newUser.password,
          name: newUser.name || newUser.username,
          role: newUser.role
      });
      
      setUsers(db.getUsers());
      setNewUser({ username: '', password: '', name: '', role: 'STAFF' });
      alert('User added successfully');
  };

  const handleDeleteUser = (id: string) => {
      if(confirm('Are you sure? This user will lose access immediately.')) {
          db.deleteUser(id);
          setUsers(db.getUsers());
      }
  };

  return (
    <div className="max-w-xl mx-auto bg-white dark:bg-slate-800 p-8 rounded-xl shadow-sm border dark:border-slate-700 mb-20 transition-colors">
        
        {/* TABS */}
        <div className="flex border-b dark:border-slate-700 mb-6">
            <button 
                onClick={() => setActiveTab('general')}
                className={`flex-1 py-3 text-sm font-bold border-b-2 transition ${activeTab === 'general' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-slate-500'}`}
            >
                General Settings
            </button>
            <button 
                onClick={() => setActiveTab('users')}
                className={`flex-1 py-3 text-sm font-bold border-b-2 transition ${activeTab === 'users' ? 'border-blue-500 text-blue-600 dark:text-blue-400' : 'border-transparent text-slate-500'}`}
            >
                User Management
            </button>
        </div>

        {activeTab === 'general' ? (
        <div className="space-y-6">
            <h2 className="text-xl font-bold mb-6 text-slate-800 dark:text-white">Business Settings</h2>
            
            {/* LOGO UPLOAD */}
            <div className="border-b dark:border-slate-700 pb-4 mb-4">
                <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">Business Logo & Favicon</label>
                <div className="flex items-start gap-4">
                    <div className="w-24 h-24 border dark:border-slate-600 rounded-lg bg-slate-50 dark:bg-slate-900 flex items-center justify-center overflow-hidden relative">
                        {logoPreview ? (
                            <img src={logoPreview} alt="Logo" className="w-full h-full object-contain" />
                        ) : (
                            <span className="text-xs text-slate-400">No Logo</span>
                        )}
                    </div>
                    <div className="flex-1 space-y-3">
                        <div>
                             <label className="block text-xs font-bold text-slate-500 mb-1">Upload File</label>
                             <input 
                                type="file" 
                                accept="image/*" 
                                onChange={handleLogoUpload}
                                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 dark:file:bg-slate-700 dark:file:text-white"
                            />
                        </div>
                        <div className="text-center text-xs text-slate-400 font-bold">- OR -</div>
                        <div>
                             <label className="block text-xs font-bold text-slate-500 mb-1">Direct Image URL</label>
                             <input 
                                type="text"
                                placeholder="https://example.com/logo.png"
                                className="w-full border p-2 rounded text-sm dark:bg-slate-900 dark:border-slate-600 dark:text-white"
                                value={settings.logo?.startsWith('data:') ? '' : settings.logo || ''}
                                onChange={handleLogoUrlChange}
                             />
                        </div>
                    </div>
                </div>
            </div>

            {/* THEME SETTINGS */}
            <div className="pt-4 border-t dark:border-slate-700">
                <h3 className="font-bold text-slate-800 dark:text-white mb-2 flex items-center gap-2"><Palette size={18} /> Theme & Branding</h3>
                
                <div className="flex justify-between items-center mb-4">
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Dark Mode</label>
                    <button 
                        onClick={toggleDarkMode}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-sm transition ${settings.darkMode ? 'bg-slate-700 text-white border border-slate-600' : 'bg-slate-100 text-slate-800 border'}`}
                    >
                        {settings.darkMode ? <Moon size={16} /> : <Sun size={16} />}
                        {settings.darkMode ? 'Dark On' : 'Light Mode'}
                    </button>
                </div>

                <label className="block text-sm font-medium mb-2 text-slate-700 dark:text-slate-300">Brand Color</label>
                <div className="flex gap-3">
                    {THEME_COLORS.map(color => (
                        <button 
                            key={color.hex}
                            onClick={() => setSettings({ ...settings, themeColor: color.hex })}
                            className={`w-8 h-8 rounded-full border-2 transition hover:scale-110 ${settings.themeColor === color.hex ? 'border-slate-800 dark:border-white ring-2 ring-offset-2 ring-slate-300 dark:ring-slate-600' : 'border-transparent'}`}
                            style={{ backgroundColor: color.hex }}
                            title={color.name}
                        />
                    ))}
                </div>
                <p className="text-xs text-slate-400 mt-2">This color will be used for Invoice Headers, Tables, and Buttons.</p>
            </div>

            <div className="pt-4 border-t dark:border-slate-700">
                 <div>
                    <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Business Name</label>
                    <input className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={settings.businessName} onChange={e => setSettings({...settings, businessName: e.target.value})} />
                </div>
            </div>
            
            {/* GST Rates Configuration */}
            <div className="pt-4 border-t dark:border-slate-700">
                <h3 className="font-bold text-slate-800 dark:text-white mb-2">Tax Configuration</h3>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">GSTIN (Tax ID)</label>
                <input 
                    className="w-full border p-2 rounded uppercase mb-3 dark:bg-slate-900 dark:border-slate-600 dark:text-white" 
                    placeholder="22AAAAA0000A1Z5"
                    value={settings.gstin || ''} 
                    onChange={e => setSettings({...settings, gstin: e.target.value.toUpperCase()})} 
                />

                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Available GST Rates (%)</label>
                <div className="flex flex-wrap gap-2 mb-2">
                    {Array.isArray(settings.availableGstRates) && settings.availableGstRates.map(rate => (
                        <span key={rate} className="px-3 py-1 bg-slate-100 dark:bg-slate-700 rounded-full text-sm flex items-center gap-2 border dark:border-slate-600 dark:text-slate-200">
                            {rate}%
                            <button onClick={() => removeGstRate(rate)} className="text-slate-400 hover:text-red-500"><Trash size={12} /></button>
                        </span>
                    ))}
                </div>
                <div className="flex gap-2">
                    <input 
                        type="number" 
                        className="w-24 border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" 
                        placeholder="Rate" 
                        value={newGstRate} 
                        onChange={e => setNewGstRate(e.target.value)}
                    />
                    <button onClick={handleAddGstRate} className="bg-slate-800 dark:bg-slate-600 text-white px-3 py-2 rounded text-sm flex items-center gap-1">
                        <Plus size={16} /> Add
                    </button>
                </div>
            </div>

            <div className="pt-4 border-t dark:border-slate-700">
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Address</label>
                <textarea className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={settings.address} onChange={e => setSettings({...settings, address: e.target.value})}></textarea>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Phone</label>
                <input className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={settings.phone} onChange={e => setSettings({...settings, phone: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">UPI ID (For QR Code)</label>
                <input className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={settings.upiId} onChange={e => setSettings({...settings, upiId: e.target.value})} />
                <p className="text-xs text-slate-400 mt-1">e.g. 9876543210@upi (Required for Invoice QR Code)</p>
            </div>
            
            {/* Invoice Configuration Section */}
            <div className="pt-4 border-t dark:border-slate-700">
                <h3 className="font-bold text-slate-800 dark:text-white mb-2">Invoice Configuration</h3>
                <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Invoice Prefix</label>
                        <input 
                            className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" 
                            placeholder="INV-" 
                            value={settings.invoicePrefix || ''}
                            onChange={e => setSettings({...settings, invoicePrefix: e.target.value})}
                        />
                        <p className="text-xs text-slate-400 mt-1">e.g. "GST/24-25/" or "INV-"</p>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Start Sequence</label>
                        <input 
                            type="number"
                            className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" 
                            placeholder="1001" 
                            value={settings.invoiceStartSequence || ''}
                            onChange={e => setSettings({...settings, invoiceStartSequence: parseInt(e.target.value)})}
                        />
                        <p className="text-xs text-slate-400 mt-1">Next invoice will be (Max Existing + 1)</p>
                    </div>
                </div>

                <div>
                    <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Invoice Footer Text / Declaration</label>
                    <textarea 
                        className="w-full border p-2 rounded dark:bg-slate-900 dark:border-slate-600 dark:text-white" 
                        rows={3}
                        placeholder="e.g. Thank you for your business! Goods once sold will not be taken back."
                        value={settings.footerText || ''}
                        onChange={e => setSettings({...settings, footerText: e.target.value})}
                    ></textarea>
                    <p className="text-xs text-slate-400 mt-1">This text appears at the bottom of the invoice if "Show Footer" is enabled.</p>
                </div>
            </div>

            <button onClick={handleSave} className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700 mt-4 font-bold text-lg shadow-lg">Save Configuration</button>
        </div>
        ) : (
            <div className="space-y-6">
                <div className="flex justify-between items-center">
                    <h2 className="text-xl font-bold text-slate-800 dark:text-white">Staff & Admins</h2>
                </div>
                
                <form onSubmit={handleAddUser} className="bg-slate-50 dark:bg-slate-900 p-4 rounded-lg border dark:border-slate-700">
                    <h3 className="font-bold mb-3 text-sm uppercase text-slate-500">Create New User</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div>
                            <label className="block text-xs font-bold mb-1 dark:text-slate-300">Display Name</label>
                            <input className="w-full border p-2 rounded text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" placeholder="e.g. John Doe" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} />
                        </div>
                        <div>
                            <label className="block text-xs font-bold mb-1 dark:text-slate-300">Role</label>
                            <select className="w-full border p-2 rounded text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" value={newUser.role} onChange={e => setNewUser({...newUser, role: e.target.value as 'ADMIN' | 'STAFF'})}>
                                <option value="STAFF">Staff (Restricted)</option>
                                <option value="ADMIN">Admin (Full Access)</option>
                            </select>
                        </div>
                         <div>
                            <label className="block text-xs font-bold mb-1 dark:text-slate-300">Username</label>
                            <input required className="w-full border p-2 rounded text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" placeholder="login_id" value={newUser.username} onChange={e => setNewUser({...newUser, username: e.target.value})} />
                        </div>
                         <div>
                            <label className="block text-xs font-bold mb-1 dark:text-slate-300">Password</label>
                            <input required className="w-full border p-2 rounded text-sm dark:bg-slate-800 dark:border-slate-600 dark:text-white" placeholder="******" value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} />
                        </div>
                    </div>
                    <button className="bg-green-600 text-white px-4 py-2 rounded text-sm font-bold flex items-center gap-2">
                        <Plus size={16} /> Create User
                    </button>
                </form>

                <div className="space-y-3">
                    {users.map(u => (
                        <div key={u.id} className="flex items-center justify-between p-4 bg-white dark:bg-slate-800 border dark:border-slate-700 rounded-lg shadow-sm">
                            <div className="flex items-center gap-3">
                                <div className={`p-2 rounded-full ${u.role === 'ADMIN' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'}`}>
                                    {u.role === 'ADMIN' ? <Shield size={20} /> : <User size={20} />}
                                </div>
                                <div>
                                    <p className="font-bold text-slate-800 dark:text-white">{u.name}</p>
                                    <p className="text-xs text-slate-500">@{u.username} • {u.role}</p>
                                </div>
                            </div>
                            {users.length > 1 && (
                                <button onClick={() => handleDeleteUser(u.id)} className="text-slate-400 hover:text-red-500">
                                    <Trash size={18} />
                                </button>
                            )}
                        </div>
                    ))}
                </div>
            </div>
        )}
    </div>
  );
};
