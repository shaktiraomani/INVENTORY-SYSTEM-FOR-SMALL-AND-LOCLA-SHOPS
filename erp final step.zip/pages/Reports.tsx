
import React, { useState, useEffect } from 'react';
import { Printer, CreditCard, Receipt, Edit, Mail, Download, FileDown, PieChart, TrendingUp, TrendingDown, Trash2, Share2, FileText, Calendar, Filter, Image as ImageIcon, X, Sparkles, Loader2, AlertCircle } from 'lucide-react';
import { Invoice, PrintOptions, Transaction, Party, Product } from '../types';
import * as db from '../services/db';
import { askAI } from '../services/aiService';
import { InvoiceTemplate } from '../components/InvoiceTemplate';

interface ReportsPageProps {
  onEdit?: (invoice: Invoice) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ onEdit }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  
  const [activeTab, setActiveTab] = useState<'invoices' | 'transactions' | 'financials' | 'tax'>('invoices');
  const [filterType, setFilterType] = useState<'ALL' | 'SALE' | 'PURCHASE'>('ALL');
  
  // Date Filter State
  const [dateFilter, setDateFilter] = useState<'ALL' | 'TODAY' | 'MONTH' | 'CUSTOM'>('ALL');
  const [customDate, setCustomDate] = useState(new Date().toISOString().split('T')[0]);

  const [printingInvoice, setPrintingInvoice] = useState<Invoice | null>(null);
  const [printConfig, setPrintConfig] = useState<PrintOptions>({
    template: 'standard',
    showQr: true,
    showTerms: true,
    showHeader: true,
    showFooter: true,
    logoSize: 'md',
    font: 'sans'
  });
  
  // PAYMENT HISTORY MODAL STATE
  const [selectedInvoiceForHistory, setSelectedInvoiceForHistory] = useState<Invoice | null>(null);

  // AI Insights State
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [settings] = useState(db.getSettings());

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setInvoices(db.getInvoices());
    setTransactions(db.getTransactions());
    setParties(db.getParties());
    setProducts(db.getProducts());
  };

  const handleEmail = (invoice: Invoice) => {
    const party = parties.find(p => p.id === invoice.partyId);
    if (!party?.email) {
      alert('No email address found for this party.');
      return;
    }
    const subject = `${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} - ${settings.businessName}`;
    const body = `Dear ${party.name},\n\nPlease find the details below for ${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} dated ${invoice.date}.\n\nTotal Amount: ${invoice.totalAmount}\nPaid Amount: ${invoice.paidAmount}\n\nThank you,\n${settings.businessName}`;
    window.open(`mailto:${party.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  const handleShare = (invoice: Invoice) => {
    const text = `*${settings.businessName}*\nInvoice #${invoice.id.substring(0,6)}\nDate: ${invoice.date}\nParty: ${invoice.partyName}\n\n*Amount Due: ₹ ${invoice.totalAmount - invoice.paidAmount}*\nTotal Amount: ₹ ${invoice.totalAmount}\n\nPlease pay at your earliest convenience.`;
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleDeleteInvoice = (id: string) => {
    if (confirm('Are you sure you want to delete this invoice?\n\nThis will REVERSE the stock changes and adjust the party balance automatically.')) {
        db.deleteInvoice(id);
        loadData();
    }
  };

  const handleEditClick = (inv: Invoice) => {
      if (onEdit && confirm(`Edit Invoice #${inv.id.substring(0,6)}?\n\nThis will reverse previous Stock and Party Balance.`)) {
          onEdit(inv);
      }
  };

  // FILTER LOGIC
  const checkDateMatch = (dateStr: string) => {
      if (dateFilter === 'ALL') return true;
      
      const targetDate = new Date(dateStr);
      const today = new Date();
      
      if (dateFilter === 'TODAY') {
          return dateStr === today.toISOString().split('T')[0];
      }
      
      if (dateFilter === 'MONTH') {
          return targetDate.getMonth() === today.getMonth() && targetDate.getFullYear() === today.getFullYear();
      }
      
      if (dateFilter === 'CUSTOM') {
          return dateStr === customDate;
      }
      
      return true;
  };

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = inv.partyName.toLowerCase().includes(search.toLowerCase()) || 
                          inv.id.includes(search) ||
                          (inv.referenceNo && inv.referenceNo.includes(search));
    const matchesType = filterType === 'ALL' || inv.type === filterType;
    const matchesDate = checkDateMatch(inv.date);

    return matchesSearch && matchesType && matchesDate;
  });

  const filteredTransactions = transactions.filter(t => {
    const matchesSearch = t.partyName.toLowerCase().includes(search.toLowerCase()) ||
                          (t.note && t.note.toLowerCase().includes(search.toLowerCase()));
    const matchesDate = checkDateMatch(t.date);
    return matchesSearch && matchesDate;
  });

  const handleExport = () => {
    let headers: string[] = [];
    let data: (string | number)[][] = [];
    let filename = '';

    if (activeTab === 'invoices') {
      headers = ['Date', 'Due Date', 'Invoice ID', 'Reference', 'Party Name', 'Type', 'Total Amount', 'Paid Amount', 'Due Amount'];
      data = filteredInvoices.map(inv => [
        inv.date,
        inv.dueDate || '',
        inv.id,
        inv.referenceNo || '',
        inv.partyName,
        inv.type,
        inv.totalAmount,
        inv.paidAmount,
        (inv.totalAmount - inv.paidAmount)
      ]);
      filename = `Invoices_${dateFilter}_${new Date().toISOString().split('T')[0]}.csv`;
    } else if (activeTab === 'transactions') {
      headers = ['Date', 'Party Name', 'Type', 'Note', 'Amount'];
      data = filteredTransactions.map(t => [
        t.date,
        t.partyName,
        t.type,
        t.note || '',
        t.amount
      ]);
      filename = `Transactions_${dateFilter}_${new Date().toISOString().split('T')[0]}.csv`;
    } else if (activeTab === 'tax') {
        const report = getTaxReport();
        headers = ['Date', 'Invoice', 'Party', 'GSTIN', 'Taxable', 'CGST', 'SGST', 'IGST', 'Total Tax'];
        data = report.map(r => [r.date, r.id, r.partyName, r.gstin||'', r.taxable, r.cgst, r.sgst, r.igst, r.taxAmt]);
        filename = `GSTR_Report_${dateFilter}.csv`;
    } else {
        return; 
    }

    const csvContent = [
      headers.join(','),
      ...data.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadPdf = () => {
    const element = document.getElementById('print-area');
    if (!element || !printingInvoice) return;

    let jsPdfFormat: any = 'a4';
    if (printConfig.template === 'thermal') {
        jsPdfFormat = [80, 297];
    }

    const opt = {
      margin: 2,
      filename: `Invoice_${printingInvoice.id}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: jsPdfFormat, orientation: 'portrait' }
    };

    // @ts-ignore
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert('PDF library not loaded.');
    }
  };

  const handleDownloadJpg = async () => {
    const element = document.getElementById('print-area');
    if (!element || !printingInvoice) return;

    try {
        // @ts-ignore
        if (!window.html2canvas) {
            alert('Image generator is loading, please try again in a few seconds.');
            return;
        }
        
        // @ts-ignore
        const canvas = await window.html2canvas(element, { 
            scale: 2, 
            useCORS: true,
            backgroundColor: '#ffffff'
        });
        
        const link = document.createElement('a');
        link.download = `Invoice_${printingInvoice.id}.jpg`;
        link.href = canvas.toDataURL('image/jpeg', 0.9);
        link.click();
    } catch (e) {
        console.error(e);
        alert('Error generating JPG image.');
    }
  };

  // --- FINANCIAL CALCULATIONS (EXACT LOGIC) ---
  
  // 1. Balance Sheet Items
  const inventoryValue = products.reduce((acc, p) => acc + (p.stock * (p.buyPrice || 0)), 0);
  const receivablesList = parties.filter(p => p.balance > 0);
  const totalReceivables = receivablesList.reduce((acc, p) => acc + p.balance, 0);
  const payablesList = parties.filter(p => p.balance < 0);
  const totalPayables = payablesList.reduce((acc, p) => acc + Math.abs(p.balance), 0);
  
  const totalAssets = inventoryValue + totalReceivables;
  const totalLiabilities = totalPayables;

  // 2. Gross Profit (Revenue - Cost of Goods Sold)
  const salesInvoices = filteredInvoices.filter(i => i.type === 'SALE');
  
  const calculateGrossProfit = (invs: Invoice[]) => {
      return invs.reduce((totalProfit, inv) => {
          const invProfit = inv.items.reduce((itemAcc, item) => {
              const revenue = item.taxableValue || ((item.price * item.qty) - (item.discountType==='AMOUNT'?item.discount : (item.price*item.qty*item.discount/100)));
              const cost = (item.buyPrice || 0) * item.qty;
              return itemAcc + (revenue - cost);
          }, 0);
          return totalProfit + invProfit;
      }, 0);
  };

  const grossProfit = calculateGrossProfit(salesInvoices);
  const totalRevenue = salesInvoices.reduce((acc, i) => acc + i.totalAmount, 0); // Gross Revenue (Inc Tax)

  // 3. Cash Flow
  const totalCashCollected = filteredInvoices.filter(i => i.type === 'SALE').reduce((acc, i) => acc + i.paidAmount, 0);
  const totalCashPaidOut = filteredInvoices.filter(i => i.type === 'PURCHASE').reduce((acc, i) => acc + i.paidAmount, 0);
  const netCashFlow = totalCashCollected - totalCashPaidOut;

  // 4. Total Due (Filtered)
  const totalDue = filteredInvoices.reduce((acc, inv) => acc + (inv.totalAmount - inv.paidAmount), 0);


  // TAX REPORT CALCULATION
  const getTaxReport = () => {
      return filteredInvoices.map(inv => {
          const taxable = inv.items.reduce((acc, item) => acc + (item.taxableValue || 0), 0);
          const taxAmt = inv.items.reduce((acc, item) => acc + (item.gstAmount || 0), 0);
          
          let cgst = 0, sgst = 0, igst = 0;
          if (inv.taxType === 'INTER') {
              igst = taxAmt;
          } else if (inv.taxType !== 'NONE') {
              cgst = taxAmt / 2;
              sgst = taxAmt / 2;
          }
          
          return {
              ...inv,
              taxable,
              taxAmt,
              cgst, sgst, igst
          };
      });
  };
  
  const taxReportData = getTaxReport();
  const totalTaxable = taxReportData.reduce((acc, i) => acc + i.taxable, 0);
  const totalIGST = taxReportData.reduce((acc, i) => acc + i.igst, 0);
  const totalCGST = taxReportData.reduce((acc, i) => acc + i.cgst, 0);
  const totalSGST = taxReportData.reduce((acc, i) => acc + i.sgst, 0);

  // --- HELPERS FOR MODAL ---
  const getInvoiceTransactions = (invId: string) => {
      return transactions.filter(t => t.invoiceId === invId);
  };

  // --- AI ANALYSIS HANDLER ---
  const handleAnalyzeFinancials = async () => {
      setIsAnalyzing(true);
      const dataSummary = {
          inventoryValue,
          totalReceivables,
          totalPayables,
          totalAssets,
          totalLiabilities,
          grossRevenue: totalRevenue,
          grossProfit,
          cashCollected: totalCashCollected,
          cashPaidOut: totalCashPaidOut,
          netCashFlow
      };

      const prompt = `Analyze this financial data for my small business: ${JSON.stringify(dataSummary)}. 
      Provide 3 brief, actionable insights or warnings. Focus on cash flow and profitability.`;

      const result = await askAI(prompt);
      setAiAnalysis(result);
      setIsAnalyzing(false);
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border dark:border-slate-700 shadow-sm transition-colors">
              <h4 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase">Total Sales ({dateFilter.toLowerCase()})</h4>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-2">
                  ₹ {totalRevenue.toLocaleString()}
              </p>
              <div className="text-xs text-slate-400 mt-1">Gross Revenue (Invoiced)</div>
          </div>
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border dark:border-slate-700 shadow-sm transition-colors">
              <h4 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase">Cash Collected</h4>
               <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-2">
                  ₹ {totalCashCollected.toLocaleString()}
              </p>
              <div className="text-xs text-slate-400 mt-1">Realized Payments</div>
          </div>
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border dark:border-slate-700 shadow-sm transition-colors">
              <h4 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase">Pending / Due</h4>
               <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 mt-2">
                  ₹ {totalDue.toLocaleString()}
              </p>
              <div className="text-xs text-slate-400 mt-1">Total Unpaid Amount</div>
          </div>
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl border dark:border-slate-700 shadow-sm transition-colors">
              <h4 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase">Gross Profit</h4>
               <p className={`text-2xl font-bold mt-2 ${grossProfit >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                  ₹ {grossProfit.toLocaleString()}
              </p>
              <div className="text-xs text-slate-400 mt-1">Net Sales - Cost of Goods</div>
          </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border dark:border-slate-700 overflow-hidden transition-colors">
        <div className="p-4 border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex flex-col xl:flex-row justify-between items-center gap-4">
            {/* Tabs */}
            <div className="flex space-x-2 bg-slate-200 dark:bg-slate-800 p-1 rounded-lg shrink-0 overflow-x-auto max-w-full">
                <button onClick={() => setActiveTab('invoices')} className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'invoices' ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-300 shadow' : 'text-slate-500 dark:text-slate-400'}`}><Receipt size={16} /> Invoices</button>
                <button onClick={() => setActiveTab('transactions')} className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'transactions' ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-300 shadow' : 'text-slate-500 dark:text-slate-400'}`}><CreditCard size={16} /> Payments</button>
                <button onClick={() => setActiveTab('financials')} className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'financials' ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-300 shadow' : 'text-slate-500 dark:text-slate-400'}`}><PieChart size={16} /> Financials</button>
                <button onClick={() => setActiveTab('tax')} className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'tax' ? 'bg-white dark:bg-slate-600 text-blue-600 dark:text-blue-300 shadow' : 'text-slate-500 dark:text-slate-400'}`}><FileText size={16} /> Tax / GST</button>
            </div>

            {/* Filters & Actions */}
            <div className="flex flex-col md:flex-row items-center gap-2 w-full xl:w-auto">
                {/* DATE FILTER */}
                <div className="flex items-center bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded-lg p-1">
                    <Filter size={16} className="text-slate-400 ml-2" />
                    <select 
                        className="p-1.5 text-sm bg-transparent outline-none text-slate-700 dark:text-slate-300 font-medium"
                        value={dateFilter}
                        onChange={(e) => setDateFilter(e.target.value as any)}
                    >
                        <option value="ALL" className="dark:bg-slate-800">All Time</option>
                        <option value="TODAY" className="dark:bg-slate-800">Today</option>
                        <option value="MONTH" className="dark:bg-slate-800">This Month</option>
                        <option value="CUSTOM" className="dark:bg-slate-800">Custom Date</option>
                    </select>
                    {dateFilter === 'CUSTOM' && (
                        <input 
                            type="date" 
                            className="text-sm border-l ml-2 pl-2 outline-none dark:bg-slate-800 dark:text-white dark:border-slate-600"
                            value={customDate}
                            onChange={(e) => setCustomDate(e.target.value)}
                        />
                    )}
                </div>

                {(activeTab === 'invoices' || activeTab === 'tax') && (
                    <div className="flex bg-slate-100 dark:bg-slate-900 rounded-lg p-1 border dark:border-slate-700 shrink-0">
                        <button onClick={() => setFilterType('ALL')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'ALL' ? 'bg-white dark:bg-slate-700 shadow text-slate-800 dark:text-white' : 'text-slate-400'}`}>All</button>
                        <button onClick={() => setFilterType('SALE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'SALE' ? 'bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300' : 'text-slate-400'}`}>Sales</button>
                        <button onClick={() => setFilterType('PURCHASE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'PURCHASE' ? 'bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300' : 'text-slate-400'}`}>Pur</button>
                    </div>
                )}

                {activeTab !== 'financials' && (
                    <div className="flex gap-2 w-full md:w-auto">
                        <input 
                            type="text" 
                            placeholder="Search..."
                            className="flex-1 border dark:border-slate-600 dark:bg-slate-800 dark:text-white p-2 rounded-lg text-sm outline-none focus:ring-1 focus:ring-blue-500 w-32"
                            value={search}
                            onChange={e => setSearch(e.target.value)}
                        />
                        <button 
                            onClick={handleExport}
                            className="bg-slate-800 dark:bg-slate-700 text-white p-2 rounded-lg hover:bg-black dark:hover:bg-slate-600 transition"
                            title="Export Filtered Data"
                        >
                            <Download size={20} />
                        </button>
                    </div>
                )}
            </div>
        </div>

        {activeTab === 'invoices' && (
          <table className="w-full text-left text-sm dark:text-slate-300">
              <thead className="bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Due Date</th>
                      <th className="p-4">Invoice #</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4 text-right">Total</th>
                      <th className="p-4 text-right">Paid</th>
                      <th className="p-4 text-right">Due</th>
                      <th className="p-4 text-center">Action</th>
                  </tr>
              </thead>
              <tbody className="divide-y dark:divide-slate-700">
                  {filteredInvoices.map(inv => {
                      const dueAmount = inv.totalAmount - inv.paidAmount;
                      const hasPayments = inv.paidAmount > 0;
                      return (
                      <tr key={inv.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                          <td className="p-4">{inv.date}</td>
                          <td className="p-4 text-slate-500 text-xs">{inv.dueDate || '-'}</td>
                          <td className="p-4 font-mono text-xs text-slate-500">{inv.id.substring(0, 10)}</td>
                          <td className="p-4 font-medium dark:text-white">{inv.partyName}</td>
                           <td className="p-4">
                               <span className={`text-xs px-2 py-1 rounded font-bold ${inv.type === 'SALE' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' : 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300'}`}>
                                   {inv.type === 'SALE' ? 'SALE' : 'PURCHASE'}
                               </span>
                           </td>
                          <td className="p-4 text-right font-medium">₹ {inv.totalAmount.toFixed(2)}</td>
                          <td className="p-4 text-right">
                               <button 
                                onClick={() => setSelectedInvoiceForHistory(inv)}
                                className={`font-bold transition hover:underline cursor-pointer ${hasPayments ? 'text-green-600 dark:text-green-400' : 'text-slate-400'}`}
                                title={'Click to view payment details'}
                               >
                                   ₹ {inv.paidAmount.toFixed(2)}
                               </button>
                          </td>
                          <td className="p-4 text-right font-bold">
                              {dueAmount > 0.01 ? (
                                  <span className="text-red-500 dark:text-red-400">₹ {dueAmount.toFixed(2)}</span>
                              ) : (
                                  <span className="text-slate-300 dark:text-slate-600">-</span>
                              )}
                          </td>
                          <td className="p-4 text-center flex justify-center gap-2">
                              {onEdit && (
                                <button onClick={() => handleEditClick(inv)} className="text-slate-500 hover:text-blue-600 dark:text-slate-400 dark:hover:text-blue-400" title="Edit">
                                    <Edit size={18} />
                                </button>
                              )}
                              <button onClick={() => handleShare(inv)} className="text-slate-500 hover:text-green-600 dark:text-slate-400 dark:hover:text-green-400" title="Share via WhatsApp">
                                  <Share2 size={18} />
                              </button>
                              <button onClick={() => handleEmail(inv)} className="text-slate-500 hover:text-indigo-600 dark:text-slate-400 dark:hover:text-indigo-400" title="Email Invoice">
                                  <Mail size={18} />
                              </button>
                              <button onClick={() => setPrintingInvoice(inv)} className="text-slate-500 hover:text-black dark:text-slate-400 dark:hover:text-white" title="Print">
                                  <Printer size={18} />
                              </button>
                              <button 
                                onClick={() => handleDeleteInvoice(inv.id)} 
                                className="text-slate-500 hover:text-red-600 dark:text-slate-400 dark:hover:text-red-400" 
                                title="Delete Invoice"
                              >
                                  <Trash2 size={18} />
                              </button>
                          </td>
                      </tr>
                  )})}
                  {filteredInvoices.length === 0 && (
                    <tr><td colSpan={8} className="p-8 text-center text-slate-400">
                        {dateFilter === 'TODAY' ? "No invoices found for today." : "No records found."}
                    </td></tr>
                  )}
              </tbody>
          </table>
        )}

        {/* --- TRANSACTIONS TAB --- */}
        {activeTab === 'transactions' && (
          <table className="w-full text-left text-sm dark:text-slate-300">
              <thead className="bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4">Linked Bill</th>
                      <th className="p-4 text-right">Amount</th>
                  </tr>
              </thead>
              <tbody className="divide-y dark:divide-slate-700">
                  {filteredTransactions.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                          <td className="p-4 text-slate-500 dark:text-slate-400">{t.date}</td>
                          <td className="p-4 font-medium dark:text-white">{t.partyName}</td>
                          <td className="p-4">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'}`}>
                                  {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                              </span>
                          </td>
                          <td className="p-4 text-slate-500 dark:text-slate-400">
                              {t.invoiceId ? (
                                  <span className="text-xs font-mono bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">#{t.invoiceId.substring(0,8)}</span>
                              ) : (
                                  <span className="text-xs text-slate-300 dark:text-slate-600">On Account</span>
                              )}
                          </td>
                          <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                              {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                          </td>
                      </tr>
                  ))}
                  {filteredTransactions.length === 0 && (
                    <tr><td colSpan={5} className="p-8 text-center text-slate-400">No transactions found for this period.</td></tr>
                  )}
              </tbody>
          </table>
        )}
        
        {/* --- TAX TAB --- */}
        {activeTab === 'tax' && (
            <div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-center dark:text-slate-300">
                    <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold">Total Taxable</p>
                        <p className="font-bold dark:text-white">₹ {totalTaxable.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold">Total CGST</p>
                        <p className="font-bold text-blue-600 dark:text-blue-400">₹ {totalCGST.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold">Total SGST</p>
                        <p className="font-bold text-blue-600 dark:text-blue-400">₹ {totalSGST.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-bold">Total IGST</p>
                        <p className="font-bold text-indigo-600 dark:text-indigo-400">₹ {totalIGST.toFixed(2)}</p>
                    </div>
                </div>
                <div className="overflow-auto">
                    <table className="w-full text-left text-sm dark:text-slate-300">
                        <thead className="bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-b dark:border-slate-700">
                            <tr>
                                <th className="p-3">Date</th>
                                <th className="p-3">Invoice</th>
                                <th className="p-3">Party</th>
                                <th className="p-3">GSTIN</th>
                                <th className="p-3 text-right">Taxable</th>
                                <th className="p-3 text-right">CGST</th>
                                <th className="p-3 text-right">SGST</th>
                                <th className="p-3 text-right">IGST</th>
                                <th className="p-3 text-right">Total Tax</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y dark:divide-slate-700">
                            {taxReportData.map(row => (
                                <tr key={row.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                                    <td className="p-3 text-slate-500 dark:text-slate-400">{row.date}</td>
                                    <td className="p-3 font-mono text-xs text-slate-400">{row.id.substring(0,10)}</td>
                                    <td className="p-3 font-medium dark:text-white">{row.partyName}</td>
                                    <td className="p-3 text-xs uppercase text-slate-500">{row.gstin || '-'}</td>
                                    <td className="p-3 text-right">₹{row.taxable.toFixed(2)}</td>
                                    <td className="p-3 text-right text-slate-500 dark:text-slate-400">{row.cgst > 0 ? row.cgst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right text-slate-500 dark:text-slate-400">{row.sgst > 0 ? row.sgst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right text-slate-500 dark:text-slate-400">{row.igst > 0 ? row.igst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right font-bold">₹ {row.taxAmt.toFixed(2)}</td>
                                </tr>
                            ))}
                            {taxReportData.length === 0 && <tr><td colSpan={9} className="p-8 text-center text-slate-400">No records found.</td></tr>}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* --- FINANCIALS TAB --- */}
        {activeTab === 'financials' && (
            <div className="p-6 space-y-8">
                {/* AI INSIGHTS SECTION */}
                <div className="bg-gradient-to-r from-violet-50 to-indigo-50 dark:from-slate-800 dark:to-slate-800 border border-violet-100 dark:border-slate-600 rounded-xl p-6">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                            <div className="p-2 bg-white dark:bg-slate-700 rounded-full shadow-sm">
                                <Sparkles size={20} className="text-violet-600 dark:text-violet-400" />
                            </div>
                            <div>
                                <h3 className="font-bold text-lg text-slate-800 dark:text-white">AI Financial Insights</h3>
                                <p className="text-xs text-slate-500 dark:text-slate-400">Powered by Gemini AI</p>
                            </div>
                        </div>
                        <button 
                            onClick={handleAnalyzeFinancials}
                            disabled={isAnalyzing}
                            className="px-4 py-2 bg-violet-600 text-white rounded-lg text-sm font-bold shadow-md hover:bg-violet-700 disabled:opacity-50 flex items-center gap-2"
                        >
                            {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
                            {isAnalyzing ? 'Analyzing...' : 'Analyze Financial Health'}
                        </button>
                    </div>
                    
                    {aiAnalysis ? (
                        <div className="bg-white dark:bg-slate-700 p-4 rounded-lg border border-violet-100 dark:border-slate-600 prose prose-sm max-w-none text-slate-700 dark:text-slate-200">
                             <p className="whitespace-pre-wrap">{aiAnalysis}</p>
                        </div>
                    ) : (
                        <div className="text-center py-8 text-slate-400 text-sm border-2 border-dashed border-violet-200 dark:border-slate-600 rounded-lg">
                            Click "Analyze Financial Health" to generate actionable insights based on your current data.
                        </div>
                    )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div>
                        <h3 className="font-bold text-lg mb-4 text-slate-700 dark:text-white">Assets & Liabilities</h3>
                        <div className="space-y-4">
                            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-100 dark:border-green-800">
                                <h4 className="font-bold text-green-800 dark:text-green-400">Total Assets</h4>
                                <div className="flex justify-between mt-2 text-sm dark:text-slate-300">
                                    <span>Inventory Value (at cost):</span>
                                    <span className="font-bold">₹ {inventoryValue.toLocaleString()}</span>
                                </div>
                                <div className="flex justify-between mt-1 text-sm dark:text-slate-300">
                                    <span>Market Receivables:</span>
                                    <span className="font-bold">₹ {totalReceivables.toLocaleString()}</span>
                                </div>
                                <div className="border-t border-green-200 dark:border-green-800 mt-2 pt-2 flex justify-between font-bold text-lg text-green-900 dark:text-green-300">
                                    <span>Total:</span>
                                    <span>₹ {totalAssets.toLocaleString()}</span>
                                </div>
                            </div>
                            
                            <div className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg border border-red-100 dark:border-red-800">
                                <h4 className="font-bold text-red-800 dark:text-red-400">Total Liabilities</h4>
                                <div className="flex justify-between mt-2 text-sm dark:text-slate-300">
                                    <span>Market Payables:</span>
                                    <span className="font-bold">₹ {totalPayables.toLocaleString()}</span>
                                </div>
                                <div className="border-t border-red-200 dark:border-red-800 mt-2 pt-2 flex justify-between font-bold text-lg text-red-900 dark:text-red-300">
                                    <span>Total:</span>
                                    <span>₹ {totalLiabilities.toLocaleString()}</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div>
                        <h3 className="font-bold text-lg mb-4 text-slate-700 dark:text-white">Cash Flow (Estimated)</h3>
                        <div className="bg-white dark:bg-slate-700 border dark:border-slate-600 rounded-lg p-4 space-y-3">
                            <div className="flex justify-between">
                                <span className="text-slate-600 dark:text-slate-300">Total Cash In (Sales):</span>
                                <span className="font-bold text-green-600 dark:text-green-400">+ ₹ {totalCashCollected.toLocaleString()}</span>
                            </div>
                            <div className="flex justify-between">
                                <span className="text-slate-600 dark:text-slate-300">Total Cash Out (Purchases):</span>
                                <span className="font-bold text-red-600 dark:text-red-400">- ₹ {totalCashPaidOut.toLocaleString()}</span>
                            </div>
                             <div className="flex justify-between pt-2 border-t dark:border-slate-600">
                                <span className="text-slate-600 dark:text-slate-300 font-bold">Net Cash Flow:</span>
                                <span className={`font-bold ${netCashFlow >= 0 ? 'text-blue-600 dark:text-blue-400' : 'text-orange-600 dark:text-orange-400'}`}>
                                    ₹ {netCashFlow.toLocaleString()}
                                </span>
                            </div>
                            <p className="text-xs text-slate-400 mt-2 italic">
                                * Based on sum of 'Paid Amount' in invoices. For precise cash reconciliation, always check your bank/cash book.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- PRINT MODAL --- */}
        {printingInvoice && (
            <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
                <div className="bg-slate-100 dark:bg-slate-900 rounded-xl w-full max-w-6xl h-[90vh] flex overflow-hidden">
                    <div className="w-80 bg-white dark:bg-slate-800 border-r dark:border-slate-700 p-6 flex flex-col overflow-y-auto no-print">
                        <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800 dark:text-white"><Printer /> Print Preview</h2>
                        <div className="space-y-4 flex-1">
                             <button onClick={() => window.print()} className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-blue-700">
                                <Printer size={20} /> Print Now
                            </button>
                            <button onClick={handleDownloadPdf} className="w-full bg-green-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-green-700">
                                <FileDown size={20} /> Save PDF
                            </button>
                            <button onClick={handleDownloadJpg} className="w-full bg-orange-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-orange-700">
                                <ImageIcon size={20} /> Save JPG
                            </button>
                        </div>
                        <button onClick={() => setPrintingInvoice(null)} className="mt-4 w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-white py-3 rounded-lg font-bold hover:bg-slate-50 dark:hover:bg-slate-600">
                            Close
                        </button>
                    </div>
                    <div className="flex-1 bg-slate-500 dark:bg-slate-900 overflow-auto p-8 flex justify-center">
                        <div className="shadow-2xl h-fit">
                            <div id="print-area" className="bg-white text-black">
                                <InvoiceTemplate invoice={printingInvoice} settings={settings} options={printConfig} />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- PAYMENT HISTORY MODAL --- */}
        {selectedInvoiceForHistory && (
             <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
                 <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-md overflow-hidden dark:text-white">
                     <div className="p-4 border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex justify-between items-center">
                         <h3 className="font-bold text-slate-700 dark:text-white">Payment History</h3>
                         <button onClick={() => setSelectedInvoiceForHistory(null)} className="text-slate-400 hover:text-black dark:hover:text-white">
                             <X size={20} />
                         </button>
                     </div>
                     <div className="p-4">
                         <div className="mb-4">
                             <p className="text-xs text-slate-500 uppercase">Invoice</p>
                             <p className="font-bold">#{selectedInvoiceForHistory.id}</p>
                             <p className="text-sm text-slate-600 dark:text-slate-300">{selectedInvoiceForHistory.partyName}</p>
                         </div>
                         <div className="space-y-2 max-h-60 overflow-y-auto custom-scrollbar">
                             {getInvoiceTransactions(selectedInvoiceForHistory.id).map(t => (
                                 <div key={t.id} className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-700/50 rounded border border-slate-100 dark:border-slate-700">
                                     <div>
                                         <p className="text-sm font-medium">{t.date}</p>
                                         <p className="text-xs text-slate-500 dark:text-slate-400">{t.note || 'Payment'}</p>
                                     </div>
                                     <span className="font-bold text-green-600 dark:text-green-400">+ ₹{t.amount}</span>
                                 </div>
                             ))}
                             {getInvoiceTransactions(selectedInvoiceForHistory.id).length === 0 && (
                                 <p className="text-center text-slate-400 text-sm py-4">No specific transactions linked.</p>
                             )}
                         </div>
                         
                         <div className="mt-4 pt-4 border-t dark:border-slate-700 space-y-2">
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 dark:text-slate-400">Total Invoice Amount</span>
                                <span className="font-bold dark:text-white">₹ {selectedInvoiceForHistory.totalAmount.toFixed(2)}</span>
                            </div>
                            <div className="flex justify-between items-center text-sm">
                                <span className="text-slate-500 dark:text-slate-400">Total Paid</span>
                                <span className="font-bold text-green-600 dark:text-green-400">₹ {selectedInvoiceForHistory.paidAmount.toFixed(2)}</span>
                            </div>
                             <div className="flex justify-between items-center text-base border-t dark:border-slate-700 pt-2">
                                <span className="font-bold text-slate-700 dark:text-slate-300">Balance Due</span>
                                <span className="font-bold text-red-600 dark:text-red-400">₹ {(selectedInvoiceForHistory.totalAmount - selectedInvoiceForHistory.paidAmount).toFixed(2)}</span>
                            </div>
                        </div>
                     </div>
                 </div>
             </div>
        )}
      </div>
    </div>
  );
};
