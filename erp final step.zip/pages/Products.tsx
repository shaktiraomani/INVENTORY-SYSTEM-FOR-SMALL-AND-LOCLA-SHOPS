
import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Edit2, Search, Package, AlertTriangle, ClipboardList, ArrowUp, ArrowDown, History, X, Layers, UploadCloud, FileSpreadsheet, Filter } from 'lucide-react';
import { Product, StockAdjustment, ProductVariant, UserRole } from '../types';
import * as db from '../services/db';

interface ProductsPageProps {
    userRole?: UserRole;
}

export const ProductsPage: React.FC<ProductsPageProps> = ({ userRole = 'ADMIN' }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Edit State
  const [editing, setEditing] = useState<Product | null>(null);
  
  // Stock Adjustment State
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<string>(''); 
  const [adjForm, setAdjForm] = useState({ type: 'INCREASE' as 'INCREASE'|'DECREASE', qty: 0, reason: '' });

  // Stock History State
  const [historyProduct, setHistoryProduct] = useState<Product | null>(null);
  const [historyData, setHistoryData] = useState<StockAdjustment[]>([]);
  const [historyFilter, setHistoryFilter] = useState({
    startDate: '',
    endDate: '',
    type: 'ALL',
    reason: ''
  });

  // Import State
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [csvText, setCsvText] = useState('');
  const [importPreview, setImportPreview] = useState<any[]>([]);

  // Page Filters
  const [search, setSearch] = useState('');
  const [stockStatusFilter, setStockStatusFilter] = useState<'ALL' | 'IN' | 'LOW' | 'OUT'>('ALL');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  
  const [form, setForm] = useState<Partial<Product>>({ name: '', category: '', unit: 'PCS', buyPrice: 0, price: 0, stock: 0, variants: [] });
  const [hasVariants, setHasVariants] = useState(false);
  
  // Variant Form State
  const [variantForm, setVariantForm] = useState<Partial<ProductVariant>>({ name: '', price: 0, buyPrice: 0, stock: 0 });

  const load = () => setProducts(db.getProducts());
  useEffect(() => { load(); }, []);

  const isAdmin = userRole === 'ADMIN';

  // Get unique categories for filter
  const categories = Array.from(new Set(products.map(p => p.category).filter(c => !!c))).sort();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    db.saveProduct({ id: editing ? editing.id : '', ...form } as Product);
    setIsModalOpen(false);
    resetForm();
    load();
  };

  const resetForm = () => {
    setForm({ name: '', category: '', unit: 'PCS', buyPrice: 0, price: 0, stock: 0, variants: [] });
    setEditing(null);
    setHasVariants(false);
    setVariantForm({ name: '', price: 0, buyPrice: 0, stock: 0 });
  };

  const handleAddVariant = () => {
    if (!variantForm.name || !variantForm.price) return alert("Name and Sale Price are required for variant");
    
    const newVariant: ProductVariant = {
        id: db.generateId(),
        name: variantForm.name,
        price: Number(variantForm.price),
        buyPrice: Number(variantForm.buyPrice),
        stock: Number(variantForm.stock)
    };

    const updatedVariants = [...(form.variants || []), newVariant];
    setForm({ ...form, variants: updatedVariants });
    setVariantForm({ name: '', price: 0, buyPrice: 0, stock: 0 });
  };

  const removeVariant = (idx: number) => {
      const updated = [...(form.variants || [])];
      updated.splice(idx, 1);
      setForm({ ...form, variants: updated });
  };

  const handleStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;
    if (adjForm.qty <= 0) return alert("Quantity must be greater than 0");
    if (!adjForm.reason.trim()) return alert("Reason is mandatory for audit purposes");

    let variantName = '';
    if (selectedVariantId) {
        const v = adjustingProduct.variants?.find(x => x.id === selectedVariantId);
        variantName = v ? v.name : '';
    }

    db.adjustStock({
      productId: adjustingProduct.id,
      productName: adjustingProduct.name,
      variantId: selectedVariantId || undefined,
      variantName: variantName || undefined,
      type: adjForm.type,
      qty: adjForm.qty,
      reason: adjForm.reason
    });

    setAdjustingProduct(null);
    setSelectedVariantId('');
    setAdjForm({ type: 'INCREASE', qty: 0, reason: '' });
    load();
    alert('Stock adjusted successfully');
  };

  const handleViewHistory = (product: Product) => {
      const allAdjustments = db.getStockAdjustments();
      const filtered = allAdjustments.filter(a => a.productId === product.id);
      filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setHistoryData(filtered);
      setHistoryProduct(product);
      setHistoryFilter({ startDate: '', endDate: '', type: 'ALL', reason: '' });
  };

  const openEdit = (p: Product) => {
      setEditing(p);
      setForm(p);
      setHasVariants(!!(p.variants && p.variants.length > 0));
      setIsModalOpen(true);
  };

  const filtered = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          (p.category && p.category.toLowerCase().includes(search.toLowerCase()));
    
    const matchesCategory = categoryFilter === 'ALL' || p.category === categoryFilter;
    
    let matchesStock = true;
    if (stockStatusFilter === 'LOW') matchesStock = p.stock > 0 && p.stock < 10;
    else if (stockStatusFilter === 'OUT') matchesStock = p.stock <= 0;
    else if (stockStatusFilter === 'IN') matchesStock = p.stock >= 10;

    return matchesSearch && matchesCategory && matchesStock;
  });

  const lowStockCount = db.getLowStockProducts(10).length;

  // --- IMPORT LOGIC ---
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (evt) => {
          const text = evt.target?.result as string;
          setCsvText(text);
          parseCSV(text);
      };
      reader.readAsText(file);
  };

  const parseCSV = (text: string) => {
      // Simple CSV Parse: Name, Category, Unit, BuyPrice, SellPrice, Stock
      const lines = text.split('\n').filter(l => l.trim() !== '');
      if (lines.length < 2) return;
      
      const parsed = lines.slice(1).map(line => {
          const cols = line.split(',');
          // Assuming CSV Format: Name, Category, Unit, Cost, Price, Stock
          return {
              name: cols[0]?.trim(),
              category: cols[1]?.trim() || '',
              unit: cols[2]?.trim() || 'PCS',
              buyPrice: parseFloat(cols[3]?.trim()) || 0,
              price: parseFloat(cols[4]?.trim()) || 0,
              stock: parseFloat(cols[5]?.trim()) || 0
          };
      }).filter(p => p.name);
      
      setImportPreview(parsed);
  };

  const confirmImport = () => {
      if (importPreview.length === 0) return;
      importPreview.forEach(p => {
          db.saveProduct({
              id: '',
              name: p.name,
              category: p.category,
              unit: p.unit,
              buyPrice: p.buyPrice,
              price: p.price,
              stock: p.stock,
              variants: []
          });
      });
      setIsImportModalOpen(false);
      setImportPreview([]);
      setCsvText('');
      load();
      alert(`Successfully imported ${importPreview.length} products.`);
  };

  // Filter Logic for History
  const filteredHistory = historyData.filter(item => {
      const matchesType = historyFilter.type === 'ALL' || item.type === historyFilter.type;
      const matchesReason = item.reason.toLowerCase().includes(historyFilter.reason.toLowerCase());
      
      let matchesDate = true;
      if (historyFilter.startDate) {
          matchesDate = matchesDate && item.date >= historyFilter.startDate;
      }
      if (historyFilter.endDate) {
          matchesDate = matchesDate && item.date <= historyFilter.endDate;
      }

      return matchesType && matchesReason && matchesDate;
  });

  return (
    <div>
      {/* HEADER & FILTERS */}
      <div className="flex flex-col xl:flex-row justify-between items-center mb-6 gap-4">
         <div className="flex flex-1 gap-2 w-full xl:w-auto">
            <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                <input 
                    type="text" 
                    placeholder="Search products..." 
                    className="pl-10 pr-4 py-2 border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 dark:text-white rounded-lg focus:ring-2 focus:ring-blue-500 outline-none w-full"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
            </div>
            {/* Category Filter */}
            <select 
                className="border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 dark:text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
            >
                <option value="ALL">All Categories</option>
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {/* Stock Status Filter */}
            <select 
                className="border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 dark:text-white rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-500"
                value={stockStatusFilter}
                onChange={e => setStockStatusFilter(e.target.value as any)}
            >
                <option value="ALL">All Stock Status</option>
                <option value="IN">In Stock</option>
                <option value="LOW">Low Stock ({'<'} 10)</option>
                <option value="OUT">Out of Stock</option>
            </select>
         </div>

        <div className="flex gap-2 w-full xl:w-auto overflow-x-auto">
            <div className={`px-4 py-2 rounded-lg flex items-center gap-2 border whitespace-nowrap ${lowStockCount > 0 ? 'bg-red-50 text-red-700 border-red-100 dark:bg-red-900/20 dark:border-red-800 dark:text-red-400' : 'bg-green-50 text-green-700 border-green-100 dark:bg-green-900/20 dark:border-green-800 dark:text-green-400'}`}>
                <AlertTriangle size={18} />
                <span className="text-sm font-bold">{lowStockCount} Low Items</span>
            </div>

            {isAdmin && (
                <>
                <button 
                    onClick={() => setIsImportModalOpen(true)}
                    className="bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-slate-300 border border-slate-300 text-slate-700 px-3 py-2 rounded-lg flex items-center gap-2 hover:bg-slate-50 dark:hover:bg-slate-700 whitespace-nowrap"
                    title="Bulk Import"
                >
                    <UploadCloud size={20} />
                    <span className="hidden md:inline">Import</span>
                </button>
                <button 
                    onClick={() => { resetForm(); setIsModalOpen(true); }}
                    className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 whitespace-nowrap"
                >
                    <Plus size={20} /> <span className="hidden md:inline">Add Product</span><span className="md:hidden">Add</span>
                </button>
                </>
            )}
        </div>
      </div>

      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden transition-colors">
        <div className="overflow-x-auto">
            <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-sm uppercase">
                <tr>
                <th className="p-4">Product Name</th>
                <th className="p-4">Unit</th>
                {isAdmin && <th className="p-4 text-right">Buy Price</th>}
                <th className="p-4 text-right">Sale Price</th>
                <th className="p-4 text-center">Stock</th>
                <th className="p-4 text-right">Actions</th>
                </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                {filtered.map(p => (
                <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 dark:text-slate-300">
                    <td className="p-4 font-medium text-slate-800 dark:text-white">
                    <div className="flex items-center gap-2">
                        <div className="p-2 bg-slate-100 dark:bg-slate-700 rounded-lg text-slate-400">
                            <Package size={20} /> 
                        </div>
                        <div>
                            <div>{p.name}</div>
                            {p.category && <div className="text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wider font-bold">{p.category}</div>}
                        </div>
                    </div>
                    {p.variants && p.variants.length > 0 && (
                        <div className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 mt-1 ml-11">
                            <Layers size={12} /> {p.variants.length} Variants
                        </div>
                    )}
                    </td>
                    <td className="p-4 text-slate-600 dark:text-slate-400">{p.unit}</td>
                    {isAdmin && <td className="p-4 text-slate-500 text-right">₹ {p.buyPrice ? p.buyPrice.toFixed(2) : '0.00'}</td>}
                    <td className="p-4 font-medium text-blue-600 dark:text-blue-400 text-right">₹ {p.price.toFixed(2)}</td>
                    <td className="p-4 text-center">
                    <span className={`px-2 py-1 rounded text-xs font-bold ${p.stock < 10 ? 'bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400' : 'bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400'}`}>
                        {p.stock} {p.stock < 10 && 'Low'}
                    </span>
                    </td>
                    <td className="p-4 text-right flex justify-end gap-2">
                    <button 
                        onClick={() => handleViewHistory(p)}
                        className="text-slate-400 hover:text-slate-700 dark:hover:text-white"
                        title="View Stock History"
                    >
                        <History size={18} />
                    </button>
                    {isAdmin && (
                        <>
                            <button 
                                onClick={() => { setAdjustingProduct(p); setAdjForm({ type: 'INCREASE', qty: 0, reason: '' }) }} 
                                className="text-slate-400 hover:text-purple-600 dark:hover:text-purple-400"
                                title="Adjust Stock"
                            >
                                <ClipboardList size={18} />
                            </button>
                            <button onClick={() => openEdit(p)} className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"><Edit2 size={18} /></button>
                            <button onClick={() => { if(confirm('Delete?')) { db.deleteProduct(p.id); load(); } }} className="text-slate-400 hover:text-red-600 dark:hover:text-red-400"><Trash2 size={18} /></button>
                        </>
                    )}
                    </td>
                </tr>
                ))}
                {filtered.length === 0 && (
                    <tr>
                        <td colSpan={6} className="p-8 text-center text-slate-400">No products found.</td>
                    </tr>
                )}
            </tbody>
            </table>
        </div>
      </div>

      {/* Add/Edit Product Modal */}
      {isModalOpen && isAdmin && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto dark:text-white border dark:border-slate-700">
            <h3 className="text-xl font-bold mb-4">{editing ? 'Edit' : 'Add'} Product</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input required className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Category</label>
                    <input 
                        list="categoryList"
                        className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" 
                        value={form.category || ''} 
                        onChange={e => setForm({...form, category: e.target.value})} 
                        placeholder="e.g. Apparel"
                    />
                    <datalist id="categoryList">
                        {categories.map(c => <option key={c} value={c} />)}
                    </datalist>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Unit</label>
                    <select className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" value={form.unit} onChange={e => setForm({...form, unit: e.target.value})}>
                    <option>PCS</option><option>KG</option><option>BOX</option><option>MTR</option>
                    <option>LTR</option><option>SET</option><option>DOZEN</option>
                    </select>
                  </div>
              </div>

              {/* VARIANTS TOGGLE */}
              <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-700 p-3 rounded">
                  <input 
                    type="checkbox" 
                    id="hasVariants" 
                    className="w-4 h-4"
                    checked={hasVariants} 
                    onChange={e => {
                        setHasVariants(e.target.checked);
                        // If turning off, maybe warn? For now we just hide.
                    }} 
                  />
                  <label htmlFor="hasVariants" className="text-sm font-bold text-slate-700 dark:text-slate-200 select-none cursor-pointer">
                      This product has variants (Sizes, Colors, etc.)
                  </label>
              </div>
              
              {!hasVariants ? (
                // NORMAL PRODUCT INPUTS
                <>
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                            <label className="block text-sm font-medium mb-1 text-slate-500 dark:text-slate-400">Buy Price (Cost)</label>
                            <input type="number" step="0.01" className="w-full border dark:border-slate-600 p-2 rounded bg-slate-50 dark:bg-slate-900" value={form.buyPrice} onChange={e => setForm({...form, buyPrice: parseFloat(e.target.value)})} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1 text-blue-600 dark:text-blue-400">Sale Price (MRP)</label>
                            <input type="number" step="0.01" required className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" value={form.price} onChange={e => setForm({...form, price: parseFloat(e.target.value)})} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">Stock</label>
                        <input type="number" required className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" value={form.stock} onChange={e => setForm({...form, stock: parseFloat(e.target.value)})} />
                    </div>
                </>
              ) : (
                // VARIANT MANAGER
                <div className="border dark:border-slate-600 rounded p-4 bg-slate-50 dark:bg-slate-900">
                    <div className="space-y-3 mb-4 border-b dark:border-slate-700 pb-4">
                        <label className="block text-xs font-bold uppercase text-slate-500 dark:text-slate-400">Add Variant</label>
                        <input 
                            placeholder="Variant Name (e.g. Red / XL)" 
                            className="w-full border dark:border-slate-600 p-2 rounded text-sm dark:bg-slate-800"
                            value={variantForm.name}
                            onChange={e => setVariantForm({...variantForm, name: e.target.value})}
                        />
                        <div className="grid grid-cols-3 gap-2">
                            <input type="number" placeholder="Cost" className="border dark:border-slate-600 p-2 rounded text-sm dark:bg-slate-800" value={variantForm.buyPrice} onChange={e => setVariantForm({...variantForm, buyPrice: parseFloat(e.target.value)})} />
                            <input type="number" placeholder="MRP" className="border dark:border-slate-600 p-2 rounded text-sm dark:bg-slate-800" value={variantForm.price} onChange={e => setVariantForm({...variantForm, price: parseFloat(e.target.value)})} />
                            <input type="number" placeholder="Stock" className="border dark:border-slate-600 p-2 rounded text-sm dark:bg-slate-800" value={variantForm.stock} onChange={e => setVariantForm({...variantForm, stock: parseFloat(e.target.value)})} />
                        </div>
                        <button type="button" onClick={handleAddVariant} className="w-full bg-slate-800 dark:bg-slate-700 text-white py-2 rounded text-sm hover:bg-black dark:hover:bg-slate-600">Add Variant</button>
                    </div>

                    <div className="max-h-40 overflow-y-auto">
                        <table className="w-full text-xs text-left bg-white dark:bg-slate-800">
                            <thead className="bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                                <tr>
                                    <th className="p-2">Name</th>
                                    <th className="p-2">Price</th>
                                    <th className="p-2">Stock</th>
                                    <th className="p-2 w-8"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y dark:divide-slate-700 dark:text-slate-300">
                                {form.variants?.map((v, i) => (
                                    <tr key={i}>
                                        <td className="p-2">{v.name}</td>
                                        <td className="p-2">₹{v.price}</td>
                                        <td className="p-2">{v.stock}</td>
                                        <td className="p-2 cursor-pointer text-red-500" onClick={() => removeVariant(i)}><Trash2 size={14} /></td>
                                    </tr>
                                ))}
                                {(!form.variants || form.variants.length === 0) && <tr><td colSpan={4} className="p-2 text-center dark:text-slate-500">No variants added</td></tr>}
                            </tbody>
                        </table>
                    </div>
                </div>
              )}
              
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-slate-200 dark:bg-slate-700 py-2 rounded hover:bg-slate-300 dark:hover:bg-slate-600">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save Product</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* IMPORT CSV MODAL */}
      {isImportModalOpen && isAdmin && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl flex flex-col max-h-[85vh] dark:text-white border dark:border-slate-700">
                  <div className="p-6 border-b dark:border-slate-700 flex justify-between items-center">
                      <h3 className="text-xl font-bold flex items-center gap-2"><FileSpreadsheet className="text-green-600" /> Import Products via CSV</h3>
                      <button onClick={() => { setIsImportModalOpen(false); setImportPreview([]); setCsvText(''); }} className="text-slate-400 hover:text-black dark:hover:text-white"><X size={24} /></button>
                  </div>
                  
                  <div className="p-6 flex-1 overflow-y-auto">
                      <div className="bg-blue-50 dark:bg-blue-900/30 p-4 rounded-lg mb-6 text-sm text-blue-800 dark:text-blue-300 border border-blue-100 dark:border-blue-800">
                          <p className="font-bold mb-2">Instructions:</p>
                          <ul className="list-disc list-inside space-y-1">
                              <li>Prepare a CSV file with columns: <b>Name, Category, Unit, Buy Price, Sell Price, Stock</b></li>
                              <li>The first row should be headers (ignored by import).</li>
                          </ul>
                      </div>

                      {!csvText ? (
                        <div className="border-2 border-dashed border-slate-300 dark:border-slate-600 rounded-xl p-12 text-center hover:bg-slate-50 dark:hover:bg-slate-700 transition relative">
                            <input 
                                type="file" 
                                accept=".csv"
                                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                                onChange={handleFileChange}
                            />
                            <UploadCloud size={48} className="mx-auto text-slate-300 dark:text-slate-500 mb-4" />
                            <p className="font-bold text-slate-600 dark:text-slate-300">Click to upload CSV file</p>
                            <p className="text-sm text-slate-400">or drag and drop here</p>
                        </div>
                      ) : (
                          <div>
                              <div className="flex justify-between items-center mb-4">
                                  <h4 className="font-bold text-slate-700 dark:text-slate-200">Preview ({importPreview.length} items)</h4>
                                  <button onClick={() => { setCsvText(''); setImportPreview([]); }} className="text-sm text-red-500 hover:underline">Remove File</button>
                              </div>
                              <div className="border dark:border-slate-600 rounded-lg overflow-hidden">
                                  <table className="w-full text-sm text-left">
                                      <thead className="bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-300">
                                          <tr>
                                              <th className="p-2">Name</th>
                                              <th className="p-2">Cat</th>
                                              <th className="p-2">Unit</th>
                                              <th className="p-2 text-right">Cost</th>
                                              <th className="p-2 text-right">Price</th>
                                              <th className="p-2 text-center">Stock</th>
                                          </tr>
                                      </thead>
                                      <tbody className="divide-y dark:divide-slate-600 dark:text-slate-300">
                                          {importPreview.slice(0, 10).map((p, i) => (
                                              <tr key={i}>
                                                  <td className="p-2 font-medium">{p.name}</td>
                                                  <td className="p-2 font-medium">{p.category}</td>
                                                  <td className="p-2 text-slate-500 dark:text-slate-400">{p.unit}</td>
                                                  <td className="p-2 text-right">{p.buyPrice}</td>
                                                  <td className="p-2 text-right">{p.price}</td>
                                                  <td className="p-2 text-center">{p.stock}</td>
                                              </tr>
                                          ))}
                                          {importPreview.length > 10 && (
                                              <tr><td colSpan={6} className="p-2 text-center text-slate-400 italic">...and {importPreview.length - 10} more</td></tr>
                                          )}
                                      </tbody>
                                  </table>
                              </div>
                          </div>
                      )}
                  </div>
                  
                  <div className="p-6 border-t dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex justify-end gap-3">
                      <button onClick={() => setIsImportModalOpen(false)} className="px-6 py-2 rounded-lg border dark:border-slate-600 bg-white dark:bg-slate-700 hover:bg-slate-50 dark:hover:bg-slate-600">Cancel</button>
                      <button 
                        onClick={confirmImport} 
                        disabled={importPreview.length === 0}
                        className="px-6 py-2 rounded-lg bg-green-600 text-white font-bold hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                          Import {importPreview.length} Products
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustingProduct && isAdmin && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-slate-800 p-6 rounded-xl w-96 shadow-2xl dark:text-white border dark:border-slate-700">
            <h3 className="text-xl font-bold mb-1">Adjust Stock</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">Product: {adjustingProduct.name}</p>
            
            <form onSubmit={handleStockAdjustment} className="space-y-4">
              
              {/* VARIANT SELECTOR FOR ADJUSTMENT */}
              {adjustingProduct.variants && adjustingProduct.variants.length > 0 ? (
                  <div>
                      <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Select Variant</label>
                      <select 
                        className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900"
                        value={selectedVariantId}
                        onChange={e => setSelectedVariantId(e.target.value)}
                        required
                      >
                          <option value="">-- Select Variant --</option>
                          {adjustingProduct.variants.map(v => (
                              <option key={v.id} value={v.id}>{v.name} (Stk: {v.stock})</option>
                          ))}
                      </select>
                  </div>
              ) : (
                  <p className="text-xs bg-slate-100 dark:bg-slate-700 p-2 rounded">Current Stock: <b>{adjustingProduct.stock}</b></p>
              )}

              <div className="flex bg-slate-100 dark:bg-slate-700 p-1 rounded">
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'INCREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'INCREASE' ? 'bg-green-500 text-white shadow' : 'text-slate-500 dark:text-slate-400'}`}
                >
                  <ArrowUp size={16} /> Add Stock
                </button>
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'DECREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'DECREASE' ? 'bg-red-500 text-white shadow' : 'text-slate-500 dark:text-slate-400'}`}
                >
                   <ArrowDown size={16} /> Reduce Stock
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input required type="number" min="0" className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" value={adjForm.qty} onChange={e => setAdjForm({...adjForm, qty: parseFloat(e.target.value)})} />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Reason</label>
                <textarea 
                  required 
                  className="w-full border dark:border-slate-600 p-2 rounded dark:bg-slate-900" 
                  value={adjForm.reason} 
                  onChange={e => setAdjForm({...adjForm, reason: e.target.value})}
                  rows={2}
                ></textarea>
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => { setAdjustingProduct(null); setSelectedVariantId(''); }} className="flex-1 bg-slate-200 dark:bg-slate-700 py-2 rounded hover:bg-slate-300 dark:hover:bg-slate-600">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyProduct && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col dark:text-white border dark:border-slate-700">
                  <div className="p-4 border-b dark:border-slate-700 flex justify-between items-center">
                      <div>
                        <h3 className="text-lg font-bold">Stock History</h3>
                        <p className="text-sm text-slate-500 dark:text-slate-400">{historyProduct.name}</p>
                      </div>
                      <button onClick={() => setHistoryProduct(null)} className="text-slate-400 hover:text-black dark:hover:text-white">
                          <X size={20} />
                      </button>
                  </div>

                  {/* FILTER BAR */}
                  <div className="p-4 bg-slate-50 dark:bg-slate-900 border-b dark:border-slate-700 space-y-3">
                      <div className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 font-medium">
                          <Filter size={16} /> Filters
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
                          <input 
                              type="date" 
                              className="border dark:border-slate-600 p-2 rounded text-sm bg-white dark:bg-slate-800 dark:text-white" 
                              placeholder="Start Date"
                              value={historyFilter.startDate}
                              onChange={e => setHistoryFilter({...historyFilter, startDate: e.target.value})}
                          />
                          <input 
                              type="date" 
                              className="border dark:border-slate-600 p-2 rounded text-sm bg-white dark:bg-slate-800 dark:text-white" 
                              placeholder="End Date"
                              value={historyFilter.endDate}
                              onChange={e => setHistoryFilter({...historyFilter, endDate: e.target.value})}
                          />
                          <select 
                              className="border dark:border-slate-600 p-2 rounded text-sm bg-white dark:bg-slate-800 dark:text-white"
                              value={historyFilter.type}
                              onChange={e => setHistoryFilter({...historyFilter, type: e.target.value})}
                          >
                              <option value="ALL">All Types</option>
                              <option value="INCREASE">Increase</option>
                              <option value="DECREASE">Decrease</option>
                          </select>
                          <input 
                              type="text" 
                              placeholder="Search Reason..."
                              className="border dark:border-slate-600 p-2 rounded text-sm bg-white dark:bg-slate-800 dark:text-white"
                              value={historyFilter.reason}
                              onChange={e => setHistoryFilter({...historyFilter, reason: e.target.value})}
                          />
                      </div>
                  </div>
                  
                  <div className="p-0 overflow-auto flex-1">
                      <table className="w-full text-left text-sm dark:text-slate-300">
                          <thead className="bg-slate-50 dark:bg-slate-900 text-slate-500 dark:text-slate-400 sticky top-0 shadow-sm">
                              <tr>
                                  <th className="p-4">Date</th>
                                  <th className="p-4">Variant</th>
                                  <th className="p-4">Type</th>
                                  <th className="p-4 text-center">Qty</th>
                                  <th className="p-4">Reason</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y dark:divide-slate-700">
                              {filteredHistory.map(adj => (
                                  <tr key={adj.id}>
                                      <td className="p-4 text-slate-500 dark:text-slate-400">{adj.date}</td>
                                      <td className="p-4 text-xs font-mono">{adj.variantName || '-'}</td>
                                      <td className="p-4">
                                          <span className={`px-2 py-1 rounded-full text-xs font-bold ${adj.type === 'INCREASE' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300' : 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300'}`}>
                                              {adj.type}
                                          </span>
                                      </td>
                                      <td className="p-4 text-center font-medium">{adj.qty}</td>
                                      <td className="p-4 text-slate-600 dark:text-slate-400">{adj.reason}</td>
                                  </tr>
                              ))}
                              {filteredHistory.length === 0 && (
                                  <tr><td colSpan={5} className="p-8 text-center text-slate-400">No stock adjustment history found.</td></tr>
                              )}
                          </tbody>
                      </table>
                  </div>
                  
                  <div className="p-4 border-t dark:border-slate-700 text-right bg-slate-50 dark:bg-slate-900">
                      <button onClick={() => setHistoryProduct(null)} className="px-4 py-2 bg-white dark:bg-slate-800 border dark:border-slate-600 rounded hover:bg-slate-50 dark:hover:bg-slate-700 font-medium">Close</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
    