import React, { useState } from 'react';
import { UserSettings } from '../types';
import * as db from '../services/db';
import { AlertTriangle } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<UserSettings>(db.getSettings());
  const [logoPreview, setLogoPreview] = useState<string>(settings.logo || '');

  // Handle File Upload & Compression
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        const maxWidth = 300; // Limit width to 300px for Google Sheet safety
        const scale = maxWidth / img.width;
        
        canvas.width = maxWidth;
        canvas.height = img.height * scale;

        ctx?.drawImage(img, 0, 0, canvas.width, canvas.height);
        
        // Convert to Base64 JPEG (lower size than PNG)
        const compressedBase64 = canvas.toDataURL('image/jpeg', 0.7); 
        
        setSettings({ ...settings, logo: compressedBase64 });
        setLogoPreview(compressedBase64);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const url = e.target.value;
      setSettings({ ...settings, logo: url });
      setLogoPreview(url);
  };

  const handleSave = () => {
    db.saveSettings(settings);
    alert('Settings saved!');
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-xl shadow-sm border">
        <h2 className="text-xl font-bold mb-6">Business Settings</h2>
        <div className="space-y-4">
            
            {/* LOGO UPLOAD */}
            <div className="border-b pb-4 mb-4">
                <label className="block text-sm font-medium mb-2">Business Logo</label>
                <div className="flex items-start gap-4">
                    <div className="w-24 h-24 border rounded-lg bg-slate-50 flex items-center justify-center overflow-hidden relative">
                        {logoPreview ? (
                            <img src={logoPreview} alt="Logo" className="w-full h-full object-contain" />
                        ) : (
                            <span className="text-xs text-slate-400">No Logo</span>
                        )}
                    </div>
                    <div className="flex-1 space-y-3">
                        <div>
                             <label className="block text-xs font-bold text-slate-500 mb-1">Upload File</label>
                             <input 
                                type="file" 
                                accept="image/*" 
                                onChange={handleLogoUpload}
                                className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                            />
                        </div>
                        <div className="text-center text-xs text-slate-400 font-bold">- OR -</div>
                        <div>
                             <label className="block text-xs font-bold text-slate-500 mb-1">Direct Image URL</label>
                             <input 
                                type="text"
                                placeholder="https://example.com/logo.png"
                                className="w-full border p-2 rounded text-sm"
                                value={settings.logo?.startsWith('data:') ? '' : settings.logo || ''}
                                onChange={handleLogoUrlChange}
                             />
                        </div>
                    </div>
                </div>
            </div>

            <div>
                <label className="block text-sm font-medium mb-1">Business Name</label>
                <input className="w-full border p-2 rounded" value={settings.businessName} onChange={e => setSettings({...settings, businessName: e.target.value})} />
            </div>
            
            <div>
                <label className="block text-sm font-medium mb-1">GSTIN (Tax ID)</label>
                <input 
                    className="w-full border p-2 rounded uppercase" 
                    placeholder="22AAAAA0000A1Z5"
                    value={settings.gstin || ''} 
                    onChange={e => setSettings({...settings, gstin: e.target.value.toUpperCase()})} 
                />
            </div>

            <div>
                <label className="block text-sm font-medium mb-1">Address</label>
                <textarea className="w-full border p-2 rounded" value={settings.address} onChange={e => setSettings({...settings, address: e.target.value})}></textarea>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Phone</label>
                <input className="w-full border p-2 rounded" value={settings.phone} onChange={e => setSettings({...settings, phone: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">UPI ID (For QR Code)</label>
                <input className="w-full border p-2 rounded" value={settings.upiId} onChange={e => setSettings({...settings, upiId: e.target.value})} />
                <p className="text-xs text-slate-400 mt-1">e.g. 9876543210@upi</p>
            </div>
            
            <div className="pt-4 border-t mt-4">
                <h3 className="font-bold text-slate-800 mb-2">AI Configuration</h3>
                <label className="block text-sm font-medium mb-1">Gemini API Key</label>
                <input 
                    type="password"
                    placeholder="AIza..."
                    className="w-full border p-2 rounded" 
                    value={settings.apiKey || ''} 
                    onChange={e => setSettings({...settings, apiKey: e.target.value})} 
                />
                
                {/* Security Note */}
                <div className="bg-amber-50 border border-amber-200 rounded p-3 mt-2 flex items-start gap-2">
                   <AlertTriangle className="text-amber-600 shrink-0 mt-0.5" size={16} />
                   <div className="text-xs text-amber-800">
                     <strong>Security Warning:</strong> Your API Key is stored directly in your Google Sheet ('Settings' tab). 
                     <ul className="list-disc pl-4 mt-1 space-y-1">
                        <li>Do not share your Google Sheet with unauthorized people.</li>
                        <li>Anyone with access to the sheet can view this key.</li>
                        <li>The key is used directly by your browser to communicate with Google AI.</li>
                     </ul>
                   </div>
                </div>
            </div>

            <button onClick={handleSave} className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 mt-4">Save Configuration</button>
        </div>
    </div>
  );
};