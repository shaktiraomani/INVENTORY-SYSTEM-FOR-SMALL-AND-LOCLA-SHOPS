import React, { useState, useEffect } from 'react';
import { ArrowDownLeft, ArrowUpRight, Wallet } from 'lucide-react';
import { Party, Transaction } from '../types';
import * as db from '../services/db';

export const PaymentsPage: React.FC = () => {
  const [parties, setParties] = useState<Party[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  
  // Form State
  const [type, setType] = useState<'PAYMENT_IN' | 'PAYMENT_OUT'>('PAYMENT_IN');
  const [partyId, setPartyId] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');

  // Filter State
  const [filter, setFilter] = useState<'ALL' | 'PAYMENT_IN' | 'PAYMENT_OUT'>('ALL');

  const load = () => {
    setParties(db.getParties());
    setTransactions(db.getTransactions());
  };
  
  useEffect(() => { load(); }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parties.find(x => x.id === partyId);
    if (!p) return;

    db.createTransaction({
      id: '',
      date: new Date().toISOString().split('T')[0],
      partyId,
      partyName: p.name,
      amount: parseFloat(amount),
      type,
      note
    });
    
    setAmount('');
    setNote('');
    load(); // Reloads parties to update balance
  };

  const selectedParty = parties.find(p => p.id === partyId);

  const filteredTransactions = transactions.filter(t => {
    if (filter === 'ALL') return true;
    return t.type === filter;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Form */}
      <div className="bg-white p-6 rounded-xl shadow-sm border h-fit">
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
            {type === 'PAYMENT_IN' ? <ArrowDownLeft className="text-green-500" /> : <ArrowUpRight className="text-red-500" />}
            Record Payment
        </h3>
        
        <div className="flex bg-slate-100 p-1 rounded mb-4">
            <button onClick={() => setType('PAYMENT_IN')} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_IN' ? 'bg-green-500 text-white shadow' : 'text-slate-500'}`}>Receive (In)</button>
            <button onClick={() => setType('PAYMENT_OUT')} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_OUT' ? 'bg-red-500 text-white shadow' : 'text-slate-500'}`}>Pay (Out)</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
             <div>
                <label className="block text-sm font-medium mb-1">Party Name</label>
                <select required className="w-full border p-2 rounded" value={partyId} onChange={e => setPartyId(e.target.value)}>
                    <option value="">Select Party</option>
                    {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
             </div>
             
             {/* Current Balance Display */}
             {selectedParty && (
                <div className={`p-3 rounded-lg flex items-center justify-between text-sm ${selectedParty.balance > 0 ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
                    <span className="flex items-center gap-2 font-medium"><Wallet size={16}/> Current Balance:</span>
                    <span className="font-bold text-lg">
                        ₹ {Math.abs(selectedParty.balance).toFixed(2)} {selectedParty.balance > 0 ? 'Dr (Receivable)' : 'Cr (Payable)'}
                    </span>
                </div>
             )}

             <div>
                <label className="block text-sm font-medium mb-1">Amount</label>
                <input required type="number" className="w-full border p-2 rounded" value={amount} onChange={e => setAmount(e.target.value)} />
             </div>
             <div>
                <label className="block text-sm font-medium mb-1">Note / Reference</label>
                <textarea className="w-full border p-2 rounded" value={note} onChange={e => setNote(e.target.value)} rows={3}></textarea>
             </div>
             <button className={`w-full py-2 rounded text-white font-bold ${type === 'PAYMENT_IN' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}>
                 Save Transaction
             </button>
        </form>
      </div>

      {/* History */}
      <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-50 flex flex-col sm:flex-row justify-between items-center gap-3">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
                Recently Transactions
            </h3>
            <div className="flex bg-slate-200 rounded-lg p-1 text-xs font-bold">
                <button 
                    onClick={() => setFilter('ALL')} 
                    className={`px-3 py-1 rounded-md transition ${filter === 'ALL' ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    All
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_IN')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_IN' ? 'bg-white shadow text-green-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <ArrowDownLeft size={12} /> Received
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_OUT')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_OUT' ? 'bg-white shadow text-red-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <ArrowUpRight size={12} /> Paid
                </button>
            </div>
        </div>
        <table className="w-full text-left text-sm">
            <thead className="text-slate-500 border-b">
                <tr>
                    <th className="p-4">Date</th>
                    <th className="p-4">Party</th>
                    <th className="p-4">Type</th>
                    <th className="p-4 text-right">Amount</th>
                </tr>
            </thead>
            <tbody className="divide-y">
                {filteredTransactions.map(t => (
                    <tr key={t.id}>
                        <td className="p-4 text-slate-500">{t.date}</td>
                        <td className="p-4 font-medium">{t.partyName}</td>
                        <td className="p-4">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                            </span>
                        </td>
                        <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600' : 'text-red-600'}`}>
                            {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                        </td>
                    </tr>
                ))}
                {filteredTransactions.length === 0 && <tr><td colSpan={4} className="p-8 text-center text-slate-400">No transactions found</td></tr>}
            </tbody>
        </table>
      </div>
    </div>
  );
};