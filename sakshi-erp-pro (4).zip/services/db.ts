import { Party, Product, Invoice, Transaction, UserSettings, StockAdjustment } from '../types';

// ==========================================
// CONFIGURATION
// ==========================================
const GOOGLE_SCRIPT_URL = 'PASTE_YOUR_WEB_APP_URL_HERE'; 

const defaultSettings: UserSettings = {
  businessName: 'Sakshi Enterprises',
  address: '123 Market Road, City Center',
  phone: '9876543210',
  upiId: 'merchant@upi',
  apiKey: 'AIzaSyBHliQdpqiWVnUNLztJUZrK9PWXRD2F9_8', // Pre-configured Gemini API Key
  gstin: '',
  logo: ''
};

// ==========================================
// IN-MEMORY CACHE (State Management)
// ==========================================
let _parties: Party[] = [];
let _products: Product[] = [];
let _invoices: Invoice[] = [];
let _transactions: Transaction[] = [];
let _settings: UserSettings = defaultSettings;
let _stockAdjustments: StockAdjustment[] = [];

// ==========================================
// CONNECTION LAYER (Hybrid: GAS vs Fetch)
// ==========================================

const isGasEnvironment = () => {
  return typeof window !== 'undefined' && window.google && window.google.script;
};

// Wrapper to call Backend Functions
const backendCall = async (functionName: string, payload?: any): Promise<any> => {
  if (isGasEnvironment()) {
    // Native Google Apps Script Call
    return new Promise((resolve, reject) => {
      // @ts-ignore
      window.google.script.run
        .withSuccessHandler((response: any) => {
            // ROBUST PARSING: Check if response is stringified JSON
            try {
                if (typeof response === 'string') {
                    resolve(JSON.parse(response));
                } else {
                    resolve(response);
                }
            } catch (e) {
                console.error("JSON Parse Error from Backend:", e);
                // If parse fails, assume it was meant to be raw
                resolve(response);
            }
        })
        .withFailureHandler((err: any) => {
            console.error("GAS Failure:", err);
            reject(err);
        })
        [functionName](payload ? JSON.stringify(payload) : undefined);
    });
  } else {
    // Standard HTTP Call (Localhost)
    if (!GOOGLE_SCRIPT_URL || GOOGLE_SCRIPT_URL.includes('PASTE_YOUR')) {
      console.warn("API URL missing. Running in offline mode.");
      if (functionName === 'apiPostData') return { status: 'success' };
      return null;
    }
    
    const isPost = functionName === 'apiPostData';
    const url = isPost ? GOOGLE_SCRIPT_URL : `${GOOGLE_SCRIPT_URL}?op=getData`;
    
    const options: RequestInit = isPost ? {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    } : { method: 'GET' };

    try {
        const res = await fetch(url, options);
        if (isPost) return { status: 'success' };
        return await res.json();
    } catch (e) {
        console.error("Fetch Error:", e);
        return null;
    }
  }
};

// ==========================================
// SYNC STATUS FOR UI
// ==========================================
export const syncStatus = {
    listeners: [] as ((status: 'idle' | 'saving' | 'saved' | 'error') => void)[],
    subscribe(fn: (status: 'idle' | 'saving' | 'saved' | 'error') => void) {
        this.listeners.push(fn);
        return () => { this.listeners = this.listeners.filter(l => l !== fn); };
    },
    notify(status: 'idle' | 'saving' | 'saved' | 'error') {
        this.listeners.forEach(fn => fn(status));
    }
};

const syncToSheet = async (payload: any) => {
  syncStatus.notify('saving');
  try {
    await backendCall('apiPostData', payload);
    syncStatus.notify('saved');
    setTimeout(() => syncStatus.notify('idle'), 2000);
  } catch (error) {
    console.error("Failed to sync to Google Sheet", error);
    syncStatus.notify('error');
  }
};

// Initialize App: Load ALL data
export const initDB = async (): Promise<boolean> => {
  try {
    const data = await backendCall('apiGetData');
    
    // If data is null or empty, we keep defaults but return true to stop loading spinner
    if (!data) return true;

    _parties = data.parties || [];
    _products = data.products || [];
    
    // Ensure invoice items are parsed correctly
    _invoices = (data.invoices || []).map((inv: any) => {
        let items = [];
        try {
            items = typeof inv.items === 'string' ? JSON.parse(inv.items) : inv.items;
        } catch(e) { console.error("Error parsing invoice items", e); }
        
        return { ...inv, items: items || [] };
    });
    
    _transactions = data.transactions || [];
    
    // INTELLIGENT SETTINGS MERGE
    const fetchedSettings = data.settings || {};
    _settings = { ...defaultSettings, ...fetchedSettings };

    // Fallback: If the saved settings have an empty API key (common on first deploy), 
    // use the default hardcoded key so AI works immediately.
    if (!_settings.apiKey && defaultSettings.apiKey) {
        _settings.apiKey = defaultSettings.apiKey;
    }
    
    return true;
  } catch (error) {
    console.error("Error loading data", error);
    return false;
  }
};

// ==========================================
// GETTERS
// ==========================================
const generateId = () => Math.random().toString(36).substr(2, 9);

export const getSettings = (): UserSettings => _settings;
export const getParties = (): Party[] => [..._parties];
export const getProducts = (): Product[] => [..._products];
export const getInvoices = (): Invoice[] => [..._invoices];
export const getTransactions = (): Transaction[] => [..._transactions];
export const getStockAdjustments = (): StockAdjustment[] => [..._stockAdjustments];

export const getLowStockProducts = (threshold: number = 10): Product[] => {
  return _products.filter(p => p.stock < threshold);
};

// ==========================================
// SETTERS
// ==========================================

export const saveSettings = (s: UserSettings) => {
  _settings = s;
  
  // Clean payload for sync (ensure we don't drop fields)
  syncToSheet({ type: 'setting', action: 'update', payload: s });
};

// --- PARTY ---
export const saveParty = (party: Party) => {
  const isNew = !party.id;
  const p = { ...party, id: party.id || generateId() };
  
  const idx = _parties.findIndex(x => x.id === p.id);
  if (idx >= 0) _parties[idx] = p;
  else _parties.push(p);

  syncToSheet({ type: 'party', action: isNew ? 'create' : 'update', payload: p });
};

export const deleteParty = (id: string) => {
  _parties = _parties.filter(p => p.id !== id);
  syncToSheet({ type: 'party', action: 'delete', payload: { id } });
};

// --- PRODUCT ---
export const saveProduct = (product: Product) => {
  const isNew = !product.id;
  const p = { ...product, id: product.id || generateId() };

  const idx = _products.findIndex(x => x.id === p.id);
  if (idx >= 0) _products[idx] = p;
  else _products.push(p);

  syncToSheet({ type: 'product', action: isNew ? 'create' : 'update', payload: p });
};

export const deleteProduct = (id: string) => {
  _products = _products.filter(p => p.id !== id);
  syncToSheet({ type: 'product', action: 'delete', payload: { id } });
};

// --- STOCK ADJUSTMENT ---
export const adjustStock = (adjustment: Omit<StockAdjustment, 'id' | 'date'>) => {
  const newAdj: StockAdjustment = {
    ...adjustment,
    id: generateId(),
    date: new Date().toISOString().split('T')[0]
  };
  _stockAdjustments.unshift(newAdj);

  // Update Local Product
  const pIdx = _products.findIndex(p => p.id === adjustment.productId);
  if (pIdx >= 0) {
    if (adjustment.type === 'INCREASE') _products[pIdx].stock += adjustment.qty;
    else _products[pIdx].stock -= adjustment.qty;
    
    // Sync Product Update
    syncToSheet({ type: 'product', action: 'update', payload: _products[pIdx] });
  }
};

// --- INVOICE ---
export const createInvoice = (invoice: Invoice) => {
  const newInvoice = { ...invoice, id: generateId() };
  _invoices.unshift(newInvoice);

  // Update Stock
  newInvoice.items.forEach(item => {
    const pIdx = _products.findIndex(p => p.id === item.id);
    if (pIdx >= 0) {
      if (newInvoice.type === 'SALE') _products[pIdx].stock -= item.qty;
      else _products[pIdx].stock += item.qty;
      // Sync Product Stock
      syncToSheet({ type: 'product', action: 'update', payload: _products[pIdx] });
    }
  });

  // Update Party Balance
  const partyIdx = _parties.findIndex(p => p.id === newInvoice.partyId);
  if (partyIdx >= 0) {
    const due = newInvoice.totalAmount - newInvoice.paidAmount;
    if (newInvoice.type === 'SALE') _parties[partyIdx].balance += due;
    else _parties[partyIdx].balance -= due;
    // Sync Party Balance
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  // Flatten items for sheet storage
  const sheetPayload = {
    ...newInvoice,
    items: JSON.stringify(newInvoice.items)
  };
  syncToSheet({ type: 'invoice', action: 'create', payload: sheetPayload });
};

export const updateInvoice = (updatedInvoice: Invoice) => {
  const idx = _invoices.findIndex(i => i.id === updatedInvoice.id);
  if (idx === -1) return;
  
  _invoices[idx] = updatedInvoice;
  
  const sheetPayload = {
    ...updatedInvoice,
    items: JSON.stringify(updatedInvoice.items)
  };
  syncToSheet({ type: 'invoice', action: 'update', payload: sheetPayload }); 
};

// --- DELETE INVOICE ---
export const deleteInvoice = (id: string) => {
  const invoice = _invoices.find(i => i.id === id);
  if (!invoice) return;

  // 1. REVERSE STOCK CHANGES
  invoice.items.forEach(item => {
    const pIdx = _products.findIndex(p => p.id === item.id);
    if (pIdx >= 0) {
      if (invoice.type === 'SALE') {
        // Was Sale (Stock -), so now Add Stock (+)
        _products[pIdx].stock += item.qty;
      } else {
        // Was Purchase (Stock +), so now Remove Stock (-)
        _products[pIdx].stock -= item.qty;
      }
      syncToSheet({ type: 'product', action: 'update', payload: _products[pIdx] });
    }
  });

  // 2. REVERSE PARTY BALANCE
  const partyIdx = _parties.findIndex(p => p.id === invoice.partyId);
  if (partyIdx >= 0) {
    const due = invoice.totalAmount - invoice.paidAmount;
    if (invoice.type === 'SALE') {
      // Was Sale (Party owed us +), so now reduce debt (-)
      _parties[partyIdx].balance -= due;
    } else {
      // Was Purchase (We owed party -), so now reduce our debt (+)
      _parties[partyIdx].balance += due;
    }
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  // 3. REMOVE INVOICE
  _invoices = _invoices.filter(i => i.id !== id);
  syncToSheet({ type: 'invoice', action: 'delete', payload: { id } });
};

// --- TRANSACTIONS ---
export const createTransaction = (transaction: Transaction) => {
  const newTx = { ...transaction, id: generateId() };
  _transactions.unshift(newTx);

  const partyIdx = _parties.findIndex(p => p.id === transaction.partyId);
  if (partyIdx >= 0) {
    if (transaction.type === 'PAYMENT_IN') _parties[partyIdx].balance -= transaction.amount;
    else _parties[partyIdx].balance += transaction.amount;
    
    syncToSheet({ type: 'party', action: 'update', payload: _parties[partyIdx] });
  }

  syncToSheet({ type: 'transaction', action: 'create', payload: newTx });
};