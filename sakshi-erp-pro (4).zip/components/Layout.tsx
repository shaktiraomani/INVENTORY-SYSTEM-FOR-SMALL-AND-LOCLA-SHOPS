import React, { useState } from 'react';
import { LayoutDashboard, Users, Package, ShoppingCart, CreditCard, FileText, Settings, Bot, Menu, X, Cloud, CloudOff, RefreshCw } from 'lucide-react';
import { syncStatus } from '../services/db';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, activeTab, onTabChange }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [syncState, setSyncState] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  React.useEffect(() => {
    return syncStatus.subscribe(setSyncState);
  }, []);

  const menu = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { id: 'billing', label: 'Billing / Purchase', icon: <ShoppingCart size={20} /> },
    { id: 'parties', label: 'Parties', icon: <Users size={20} /> },
    { id: 'products', label: 'Products', icon: <Package size={20} /> },
    { id: 'payments', label: 'Payments', icon: <CreditCard size={20} /> },
    { id: 'reports', label: 'Reports', icon: <FileText size={20} /> },
    { id: 'ai', label: 'Ask AI', icon: <Bot size={20} /> },
    { id: 'settings', label: 'Settings', icon: <Settings size={20} /> },
  ];

  const handleNavClick = (id: string) => {
    onTabChange(id);
    setIsSidebarOpen(false);
  };

  return (
    <div className="flex h-full w-full bg-slate-50 overflow-hidden relative">
      
      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Fixed Height & Scrollable */}
      <div 
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-white flex flex-col h-full transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } no-print shadow-2xl md:shadow-none`}
      >
        <div className="p-6 flex justify-between items-center shrink-0">
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
              Sakshi ERP
            </h1>
            <p className="text-xs text-slate-400 mt-1">Professional Edition</p>
          </div>
          <button 
            onClick={() => setIsSidebarOpen(false)} 
            className="md:hidden text-slate-400 hover:text-white bg-slate-800 p-1 rounded"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Navigation */}
        <nav className="flex-1 px-4 space-y-2 overflow-y-auto custom-scrollbar pb-6">
          {menu.map(item => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                activeTab === item.id 
                  ? 'bg-blue-600 text-white shadow-lg translate-x-1' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {item.icon}
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        
        <div className="p-4 text-center text-xs text-slate-500 border-t border-slate-800 shrink-0 bg-slate-900">
          © 2025 Aapbiti New SRM | Cloud Sync Active
        </div>
      </div>

      {/* Main Content - Takes remaining width & full height */}
      <main className="flex-1 flex flex-col h-full w-full overflow-hidden relative bg-slate-50">
        
        {/* Header */}
        <header className="bg-white border-b border-slate-200 px-4 md:px-8 py-3 sticky top-0 z-30 no-print flex justify-between items-center shadow-sm shrink-0 h-16">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="md:hidden text-slate-600 hover:text-blue-600 p-2 rounded-lg hover:bg-slate-100"
            >
              <Menu size={24} />
            </button>
            <h2 className="text-xl font-bold text-slate-800 capitalize truncate">{activeTab}</h2>
          </div>

          <div className="flex items-center gap-3">
             {/* Sync Status Indicator */}
             <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-100 border border-slate-200 text-xs font-medium">
                {syncState === 'saving' && (
                    <>
                        <RefreshCw size={12} className="animate-spin text-blue-600" />
                        <span className="text-blue-600 hidden sm:inline">Saving...</span>
                    </>
                )}
                {syncState === 'saved' && (
                    <>
                        <Cloud size={12} className="text-green-600" />
                        <span className="text-green-600 hidden sm:inline">Saved</span>
                    </>
                )}
                {syncState === 'error' && (
                    <>
                        <CloudOff size={12} className="text-red-500" />
                        <span className="text-red-500 hidden sm:inline">Sync Error</span>
                    </>
                )}
                {syncState === 'idle' && (
                    <>
                        <span className="w-2 h-2 rounded-full bg-green-500"></span>
                        <span className="text-slate-600 hidden sm:inline">Online</span>
                    </>
                )}
             </div>
          </div>
        </header>

        {/* Scrollable Content Area */}
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 custom-scrollbar">
          {children}
        </div>
      </main>
    </div>
  );
};