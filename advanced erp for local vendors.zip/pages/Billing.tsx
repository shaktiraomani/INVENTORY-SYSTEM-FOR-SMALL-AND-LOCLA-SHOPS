
import React, { useState, useEffect } from 'react';
import { Plus, Trash, Printer, Save, ShoppingBag, ShoppingCart, FileDown, ToggleLeft, ToggleRight, UserPlus, X, Ban, Percent, IndianRupee, Image as ImageIcon, Type, Layout, Calendar } from 'lucide-react';
import { Party, Product, CartItem, PaymentMethod, Invoice, UserSettings, PrintOptions, PartyType } from '../types';
import * as db from '../services/db';
import { InvoiceTemplate } from '../components/InvoiceTemplate';

interface BillingPageProps {
  initialInvoice?: Invoice | null;
  onClear?: () => void;
}

export const BillingPage: React.FC<BillingPageProps> = ({ initialInvoice, onClear }) => {
  const [parties, setParties] = useState<Party[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [settings] = useState<UserSettings>(db.getSettings());
  
  // Invoice State
  const [billType, setBillType] = useState<'SALE' | 'PURCHASE'>('SALE');
  const [selectedParty, setSelectedParty] = useState<string>('');
  const [referenceNo, setReferenceNo] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [billDate, setBillDate] = useState(new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState(new Date().toISOString().split('T')[0]); 
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.CASH);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [taxType, setTaxType] = useState<'INTRA' | 'INTER' | 'NONE'>('INTRA');
  const [note, setNote] = useState('');
  
  // Product Add State
  const [selectedProdId, setSelectedProdId] = useState('');
  const [selectedVariantId, setSelectedVariantId] = useState(''); 
  const [qty, setQty] = useState(1);
  const [discountVal, setDiscountVal] = useState(0); 
  const [discountType, setDiscountType] = useState<'PERCENT' | 'AMOUNT'>('PERCENT');
  
  // Print & UI State
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState<Invoice | null>(null);
  
  // Initialize Print Config from Global Settings or Defaults
  const [printConfig, setPrintConfig] = useState<PrintOptions>(settings.defaultPrintOptions || {
    template: 'standard',
    showQr: true,
    showTerms: true,
    showHeader: true,
    showFooter: true,
    logoSize: 'md',
    font: 'sans'
  });

  // QUICK ADD PARTY STATE
  const [showPartyModal, setShowPartyModal] = useState(false);
  const [newParty, setNewParty] = useState({ name: '', phone: '', address: '', gstin: '' });

  useEffect(() => {
    setParties(db.getParties());
    setProducts(db.getProducts());
  }, []);

  useEffect(() => {
    if (initialInvoice) {
      setBillType(initialInvoice.type);
      setSelectedParty(initialInvoice.partyId);
      setReferenceNo(initialInvoice.referenceNo || '');
      setCart(initialInvoice.items);
      setBillDate(initialInvoice.date);
      setDueDate(initialInvoice.dueDate || initialInvoice.date);
      setPaymentMethod(initialInvoice.paymentMethod);
      setPaidAmount(initialInvoice.paidAmount);
      setTaxType(initialInvoice.taxType || 'INTRA');
      setNote(initialInvoice.note || ''); 
    } else {
      resetForm();
    }
  }, [initialInvoice]);

  // --- CALCULATIONS ---
  const subTotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
  const totalTax = cart.reduce((sum, item) => sum + (item.gstAmount || 0), 0);
  const totalBill = cart.reduce((sum, item) => sum + item.total, 0);
  const totalDiscount = cart.reduce((sum, item) => {
    const gross = item.price * item.qty;
    const discAmt = item.discountType === 'PERCENT' 
        ? (gross * item.discount) / 100 
        : item.discount; 
    return sum + discAmt;
  }, 0);

  // --- SMART PAYMENT LOGIC ---
  useEffect(() => {
      if (!initialInvoice) {
          if (paymentMethod === PaymentMethod.CREDIT) {
              setPaidAmount(0);
          } else {
              setPaidAmount(totalBill);
          }
      }
  }, [totalBill, paymentMethod]);

  const resetForm = () => {
    setCart([]);
    setPaidAmount(0);
    setSelectedParty('');
    setReferenceNo('');
    const today = new Date().toISOString().split('T')[0];
    setBillDate(today);
    setDueDate(today);
    setPaymentMethod(PaymentMethod.CASH);
    setNote('');
  };

  const handleClear = () => {
    resetForm();
    if (onClear) onClear();
  };

  const handleModeSwitch = (type: 'SALE' | 'PURCHASE') => {
      if (cart.length > 0) {
          if (!confirm("Switching modes will clear your current cart. Continue?")) return;
      }
      setBillType(type);
      setCart([]);
      setSelectedParty('');
  };

  const handleQuickAddParty = (e: React.FormEvent) => {
      e.preventDefault();
      if(!newParty.name) return;

      const p: Party = {
          id: '', 
          name: newParty.name,
          phone: newParty.phone,
          address: newParty.address,
          gstin: newParty.gstin,
          type: billType === 'SALE' ? PartyType.CUSTOMER : PartyType.SUPPLIER,
          balance: 0
      };

      db.saveParty(p);
      const updatedParties = db.getParties();
      setParties(updatedParties);
      const created = updatedParties.find(x => x.name === p.name && x.phone === p.phone);
      if(created) setSelectedParty(created.id);

      setNewParty({ name: '', phone: '', address: '', gstin: '' });
      setShowPartyModal(false);
  };

  const selectedProduct = products.find(p => p.id === selectedProdId);

  const addToCart = () => {
    if (!selectedProduct) return;

    let priceToUse = 0;
    let finalName = selectedProduct.name;
    let variantId: string | undefined = undefined;

    if (selectedProduct.variants && selectedProduct.variants.length > 0) {
        if (!selectedVariantId) return alert("Please select a variant (Size/Color)");
        const variant = selectedProduct.variants.find(v => v.id === selectedVariantId);
        if (!variant) return;
        variantId = variant.id;
        priceToUse = billType === 'PURCHASE' ? variant.buyPrice : variant.price;
        finalName = `${selectedProduct.name} - ${variant.name}`;
    } else {
        priceToUse = billType === 'PURCHASE' ? (selectedProduct.buyPrice || 0) : selectedProduct.price;
    }
    
    const existingIdx = cart.findIndex(c => c.id === selectedProduct.id && c.variantId === variantId);
    let newCart = [...cart];

    if (existingIdx >= 0) {
        const item = newCart[existingIdx];
        item.qty += qty;
        if (discountVal > 0) {
            item.discount = discountVal;
            item.discountType = discountType;
        }
    } else {
        newCart.push({ 
            ...selectedProduct, 
            name: finalName,
            price: priceToUse, 
            qty, 
            discount: discountVal,
            discountType, 
            total: 0,
            variantId
        });
    }

    newCart = recalculateCart(newCart, taxType);
    setCart(newCart);
    setSelectedProdId('');
    setSelectedVariantId('');
    setQty(1);
    setDiscountVal(0); 
  };

  const recalculateCart = (currentCart: CartItem[], currentTaxType: 'INTRA' | 'INTER' | 'NONE') => {
      return currentCart.map(item => {
        const gross = item.price * item.qty;
        let discAmt = item.discountType === 'PERCENT' ? (gross * item.discount) / 100 : item.discount; 
        if (discAmt > gross) discAmt = gross;
        const taxable = gross - discAmt;
        let gstAmt = 0;
        if (currentTaxType !== 'NONE') {
            gstAmt = (taxable * (item.gstRate || 0)) / 100;
        }
        return {
            ...item,
            total: taxable + gstAmt,
            taxableValue: taxable,
            gstAmount: gstAmt
        };
    });
  };

  useEffect(() => {
      setCart(prev => recalculateCart(prev, taxType));
  }, [taxType]);

  const updateCartItem = (idx: number, field: keyof CartItem, value: any) => {
    const newCart = [...cart];
    const item = newCart[idx];
    
    if (field === 'discountType') {
        item.discountType = value;
    } else {
        let numValue = parseFloat(value);
        if (isNaN(numValue)) numValue = 0;
        // @ts-ignore
        item[field] = numValue;
    }
    setCart(recalculateCart(newCart, taxType));
  };

  const removeFromCart = (idx: number) => {
    setCart(cart.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!selectedParty || cart.length === 0) return alert("Select party and add items");
    
    const party = parties.find(p => p.id === selectedParty);
    const invoiceId = initialInvoice?.id || ''; 

    // Final sanity check for Credit
    let finalPaidAmount = paidAmount;
    if (paymentMethod === PaymentMethod.CREDIT && paidAmount === totalBill) {
        finalPaidAmount = 0;
    }

    const invoice: Invoice = {
      id: invoiceId, 
      date: billDate,
      dueDate: dueDate,
      partyId: selectedParty,
      partyName: party?.name || 'Unknown',
      items: cart,
      totalAmount: totalBill,
      paidAmount: finalPaidAmount,
      paymentMethod,
      type: billType,
      referenceNo,
      gstin: party?.gstin,
      taxType,
      note
    };

    if (initialInvoice?.id) {
        db.updateInvoice(invoice);
        alert('Invoice updated successfully! Stock and Balance adjusted.');
    } else {
        db.createInvoice(invoice);
    }
    
    setCurrentInvoice(invoice);
    setPaidAmount(finalPaidAmount); 
    // Reload settings to ensure fresh print defaults
    const currentSettings = db.getSettings();
    if(currentSettings.defaultPrintOptions) setPrintConfig(currentSettings.defaultPrintOptions);
    
    setShowPrintModal(true);
    if (!initialInvoice) resetForm();
  };

  const handleDownloadPdf = () => {
    const element = document.getElementById('print-area');
    if (!element || !currentInvoice) return;

    let jsPdfFormat: any = 'a4';
    if (printConfig.template === 'thermal') {
        jsPdfFormat = [80, 297]; // Fixed width, arbitrary long height
    }

    const opt = {
      margin: printConfig.template === 'thermal' ? 0 : 5,
      filename: `Invoice_${currentInvoice.id}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: jsPdfFormat, orientation: 'portrait' }
    };

    // @ts-ignore
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert('PDF library not loaded.');
    }
  };

  const handleDownloadJpg = async () => {
    const element = document.getElementById('print-area');
    if (!element || !currentInvoice) return;

    try {
        // @ts-ignore
        if (!window.html2canvas) {
            alert('Image generator is loading, please try again in a few seconds.');
            return;
        }
        
        // @ts-ignore
        const canvas = await window.html2canvas(element, { 
            scale: 2, 
            useCORS: true,
            backgroundColor: '#ffffff'
        });
        
        const link = document.createElement('a');
        link.download = `Invoice_${currentInvoice.id}.jpg`;
        link.href = canvas.toDataURL('image/jpeg', 0.9);
        link.click();
    } catch (e) {
        console.error(e);
        alert('Error generating JPG image.');
    }
  };

  const filteredParties = parties.filter(p => {
      if (billType === 'SALE') return p.type === PartyType.CUSTOMER;
      return p.type === PartyType.SUPPLIER;
  });

  return (
    <div className="flex flex-col gap-6 pb-32">
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-sm border dark:border-slate-700 p-4 lg:p-6 flex flex-col relative transition-colors">
        <div className="flex gap-4 mb-4">
            <button 
                onClick={() => handleModeSwitch('SALE')}
                className={`flex-1 py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition ${billType === 'SALE' ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'}`}
            >
                <ShoppingBag size={20} /> SALE
            </button>
            <button 
                onClick={() => handleModeSwitch('PURCHASE')}
                className={`flex-1 py-3 rounded-lg font-bold flex items-center justify-center gap-2 transition ${billType === 'PURCHASE' ? 'bg-purple-600 text-white shadow-lg' : 'bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400'}`}
            >
                <ShoppingCart size={20} /> PURCHASE
            </button>
        </div>

        <div className="grid grid-cols-12 gap-4 mb-4">
             <div className="col-span-12 md:col-span-6">
                 <label className="block text-xs font-bold uppercase text-slate-400 mb-1">
                     {billType === 'SALE' ? 'Customer' : 'Supplier'}
                 </label>
                 <div className="flex gap-2">
                     <select 
                        className="w-full border-b-2 border-slate-200 dark:border-slate-600 bg-transparent py-2 outline-none focus:border-blue-500 dark:text-white" 
                        value={selectedParty} 
                        onChange={e => setSelectedParty(e.target.value)}
                    >
                        <option value="" className="text-slate-500">Select {billType === 'SALE' ? 'Customer' : 'Supplier'}</option>
                        {filteredParties.map(p => <option key={p.id} value={p.id} className="dark:bg-slate-800">{p.name}</option>)}
                     </select>
                     <button 
                        onClick={() => setShowPartyModal(true)}
                        className="bg-slate-800 dark:bg-slate-700 text-white p-2 rounded hover:bg-black dark:hover:bg-slate-600"
                        title="Add New Party"
                     >
                         <UserPlus size={18} />
                     </button>
                 </div>
             </div>
             
             <div className="col-span-12 md:col-span-3">
                 <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Bill Date</label>
                 <div className="flex items-center gap-2 border-b-2 border-slate-200 dark:border-slate-600">
                    <Calendar size={16} className="text-slate-400"/>
                    <input type="date" className="w-full bg-transparent py-2 outline-none dark:text-white" value={billDate} onChange={e => setBillDate(e.target.value)} />
                 </div>
             </div>
             
             <div className="col-span-12 md:col-span-3">
                 <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Due Date</label>
                 <div className="flex items-center gap-2 border-b-2 border-slate-200 dark:border-slate-600">
                    <Calendar size={16} className="text-red-400"/>
                    <input type="date" className="w-full bg-transparent py-2 outline-none dark:text-white" value={dueDate} onChange={e => setDueDate(e.target.value)} />
                 </div>
             </div>

             <div className="col-span-12 flex flex-wrap items-center gap-2 mt-1 bg-slate-50 dark:bg-slate-900 p-2 rounded">
                 <span className="text-xs font-bold text-slate-500 uppercase mr-2">GST Mode:</span>
                 <button onClick={() => setTaxType('INTRA')} className={`text-xs px-3 py-2 rounded-full flex items-center gap-1 font-medium transition ${taxType === 'INTRA' ? 'bg-slate-800 text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-600 text-slate-600 dark:text-slate-300'}`}>
                    <ToggleLeft size={14} /> Intra (CGST+SGST)
                 </button>
                 <button onClick={() => setTaxType('INTER')} className={`text-xs px-3 py-2 rounded-full flex items-center gap-1 font-medium transition ${taxType === 'INTER' ? 'bg-slate-800 text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-600 text-slate-600 dark:text-slate-300'}`}>
                    <ToggleRight size={14} /> Inter (IGST)
                 </button>
                 <button onClick={() => setTaxType('NONE')} className={`text-xs px-3 py-2 rounded-full flex items-center gap-1 font-medium transition ${taxType === 'NONE' ? 'bg-red-600 text-white shadow' : 'bg-white dark:bg-slate-800 border dark:border-slate-600 text-slate-600 dark:text-slate-300'}`}>
                    <Ban size={14} /> Without GST
                 </button>
             </div>
             {billType === 'PURCHASE' && (
                 <div className="col-span-12">
                     <label className="block text-xs font-bold uppercase text-slate-400 mb-1">Supplier Ref / Invoice #</label>
                     <input 
                        type="text" 
                        placeholder="Enter Supplier Invoice Number"
                        className="w-full border-b-2 border-slate-200 dark:border-slate-600 bg-transparent py-2 outline-none dark:text-white" 
                        value={referenceNo} 
                        onChange={e => setReferenceNo(e.target.value)} 
                    />
                 </div>
             )}
        </div>

        <div className="bg-slate-100 dark:bg-slate-900 p-4 rounded-lg flex flex-col md:flex-row gap-4 mb-4 items-end border border-transparent dark:border-slate-700">
             <div className="flex-1 w-full">
                 <label className="text-xs font-bold text-slate-400 block mb-1">Product</label>
                 <select 
                    className="w-full p-2 border rounded bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white text-sm" 
                    value={selectedProdId} 
                    onChange={e => {
                        setSelectedProdId(e.target.value);
                        setSelectedVariantId(''); 
                    }}
                 >
                     <option value="">Search Product...</option>
                     {products.map(p => (
                         <option key={p.id} value={p.id}>{p.name} {(!p.variants || p.variants.length === 0) && `(Stk: ${p.stock})`}</option>
                     ))}
                 </select>
             </div>
             {selectedProduct && selectedProduct.variants && selectedProduct.variants.length > 0 && (
                 <div className="flex-1 w-full">
                     <label className="text-xs font-bold text-slate-400 block mb-1">Variant</label>
                     <select 
                        className="w-full p-2 border rounded bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white text-sm" 
                        value={selectedVariantId} 
                        onChange={e => setSelectedVariantId(e.target.value)}
                     >
                         <option value="">Select Variant</option>
                         {selectedProduct.variants.map(v => (
                             <option key={v.id} value={v.id}>{v.name} (Stk: {v.stock}) - ₹{v.price}</option>
                         ))}
                     </select>
                 </div>
             )}
             <div className="w-20">
                 <label className="text-xs font-bold text-slate-400 block mb-1">Qty</label>
                 <input type="number" min="1" className="w-full p-2 border rounded text-sm text-center bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white" value={qty} onChange={e => setQty(parseInt(e.target.value))} />
             </div>
             <div className="flex flex-col w-32">
                 <label className="text-xs font-bold text-slate-400 block mb-1 flex justify-between">
                     Disc
                     <button 
                        onClick={() => setDiscountType(discountType === 'PERCENT' ? 'AMOUNT' : 'PERCENT')}
                        className="text-[10px] bg-slate-200 dark:bg-slate-700 px-1 rounded flex items-center hover:bg-slate-300 dark:hover:bg-slate-600 dark:text-slate-300"
                        title="Toggle % or ₹"
                     >
                         {discountType === 'PERCENT' ? '%' : '₹'} <ToggleLeft size={10} className="ml-1"/>
                     </button>
                 </label>
                 <input 
                    type="number" min="0" 
                    className="w-full p-2 border rounded text-sm text-center bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white" 
                    value={discountVal} 
                    onChange={e => setDiscountVal(parseFloat(e.target.value) || 0)} 
                    placeholder={discountType === 'PERCENT' ? '%' : '₹'}
                 />
             </div>
             <button onClick={addToCart} className="bg-slate-800 dark:bg-slate-700 text-white p-2 rounded hover:bg-black dark:hover:bg-slate-600 w-full md:w-auto flex justify-center items-center h-[38px]">
                 <Plus size={20} />
             </button>
        </div>

        <div className="overflow-x-auto border dark:border-slate-700 rounded-lg mb-6 bg-white dark:bg-slate-800">
            <table className="w-full text-left text-sm min-w-[600px]">
                <thead className="bg-slate-50 dark:bg-slate-900 text-slate-600 dark:text-slate-400">
                    <tr>
                        <th className="p-3">Item</th>
                        <th className="p-3 w-16 text-center">Qty</th>
                        <th className="p-3 w-24 text-right">Price</th>
                        <th className="p-3 w-28 text-center">Discount</th>
                        <th className="p-3 w-16 text-right text-[10px]">{taxType === 'NONE' ? '' : 'GST%'}</th>
                        <th className="p-3 text-right">Total</th>
                        <th className="p-3 w-10"></th>
                    </tr>
                </thead>
                <tbody className="divide-y dark:divide-slate-700 dark:text-slate-300">
                    {cart.map((item, idx) => (
                        <tr key={idx}>
                            <td className="p-3 font-medium">
                                <div className="truncate max-w-[150px]" title={item.name}>{item.name}</div>
                                {billType === 'PURCHASE' && item.buyPrice !== item.price && (
                                    <span className="block text-[10px] text-slate-400">Buying Rate</span>
                                )}
                            </td>
                            <td className="p-3">
                                <input 
                                    type="number" className="w-full text-center border rounded p-1 bg-transparent dark:border-slate-600" 
                                    value={item.qty} 
                                    onChange={e => updateCartItem(idx, 'qty', e.target.value)}
                                />
                            </td>
                            <td className="p-3">
                                 <input 
                                    type="number" className="w-full text-right border rounded p-1 bg-transparent dark:border-slate-600" 
                                    value={item.price} 
                                    onChange={e => updateCartItem(idx, 'price', e.target.value)}
                                />
                            </td>
                            <td className="p-3">
                                <div className="flex items-center gap-1">
                                    <input 
                                        type="number" min="0" className="w-full text-right border rounded p-1 bg-transparent dark:border-slate-600" 
                                        value={item.discount} 
                                        onChange={e => updateCartItem(idx, 'discount', e.target.value)}
                                    />
                                    <button 
                                        onClick={() => updateCartItem(idx, 'discountType', item.discountType === 'PERCENT' ? 'AMOUNT' : 'PERCENT')}
                                        className="text-xs bg-slate-100 dark:bg-slate-700 p-1 rounded border dark:border-slate-600 hover:bg-slate-200 dark:hover:bg-slate-600"
                                    >
                                        {item.discountType === 'PERCENT' ? <Percent size={12}/> : <IndianRupee size={12}/>}
                                    </button>
                                </div>
                            </td>
                            <td className="p-3 text-right text-xs text-slate-500">
                                {taxType === 'NONE' ? '-' : `${item.gstRate}%`}
                            </td>
                            <td className="p-3 text-right font-bold">₹ {item.total.toFixed(2)}</td>
                            <td className="p-3 text-center">
                                <button onClick={() => removeFromCart(idx)} className="text-red-500 hover:text-red-700"><Trash size={16} /></button>
                            </td>
                        </tr>
                    ))}
                    {cart.length === 0 && (
                        <tr><td colSpan={7} className="p-12 text-center text-slate-400">Cart is empty. Add products above.</td></tr>
                    )}
                </tbody>
            </table>
        </div>

        <div className="bg-slate-50 dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-700">
             <div className="flex flex-col md:flex-row justify-between items-start mb-4 gap-4">
                 <div className="flex-1">
                      <span className="text-slate-500 text-sm font-medium">Total Items: {cart.length}</span>
                 </div>
                 
                 <div className="w-full md:w-72 space-y-2 p-3 bg-white dark:bg-slate-800 rounded border dark:border-slate-600">
                      <div className="flex justify-between text-sm text-slate-600 dark:text-slate-400">
                          <span>Subtotal</span>
                          <span>₹ {subTotal.toFixed(2)}</span>
                      </div>
                      {totalDiscount > 0 && (
                         <div className="flex justify-between text-sm text-green-600 dark:text-green-400">
                             <span>Discount</span>
                             <span>- ₹ {totalDiscount.toFixed(2)}</span>
                         </div>
                      )}
                      {taxType !== 'NONE' && (
                         <div className="flex justify-between text-sm text-slate-600 dark:text-slate-400">
                             <span>Tax (GST)</span>
                             <span>₹ {totalTax.toFixed(2)}</span>
                         </div>
                      )}
                      <div className="flex justify-between items-center border-t dark:border-slate-600 pt-2 mt-2">
                         <span className="font-bold text-slate-800 dark:text-white">Grand Total</span>
                         <span className={`text-2xl font-bold ${billType === 'SALE' ? 'text-blue-600 dark:text-blue-400' : 'text-purple-600 dark:text-purple-400'}`}>
                             ₹ {totalBill.toFixed(2)}
                         </span>
                      </div>
                 </div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                 <div className="md:col-span-2">
                     <label className="block text-xs font-bold text-slate-400 mb-1">Note / Remark</label>
                     <input type="text" placeholder="Optional remark..." className="w-full border p-2 rounded bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white" value={note} onChange={e => setNote(e.target.value)} />
                 </div>
                 <div>
                     <label className="block text-xs font-bold text-slate-400 mb-1">Paid Amount</label>
                     <input type="number" className="w-full border p-2 rounded font-bold text-lg bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white" value={paidAmount} onChange={e => setPaidAmount(parseFloat(e.target.value))} />
                 </div>
                 <div>
                     <label className="block text-xs font-bold text-slate-400 mb-1">Payment Method</label>
                     <select className="w-full border p-2 rounded h-[46px] bg-white dark:bg-slate-800 dark:border-slate-600 dark:text-white" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as PaymentMethod)}>
                         <option value={PaymentMethod.CASH}>Cash</option>
                         <option value={PaymentMethod.ONLINE}>Online / UPI</option>
                         <option value={PaymentMethod.CREDIT}>Credit (Unpaid)</option>
                     </select>
                 </div>
             </div>

             <div className="flex gap-3">
                 <button onClick={handleClear} className="flex-1 py-4 border border-slate-300 dark:border-slate-600 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 font-bold">Clear</button>
                 <button onClick={handleSave} className={`flex-[2] py-4 text-white rounded-lg flex justify-center items-center gap-2 font-bold shadow-md ${billType === 'SALE' ? 'bg-blue-600 hover:bg-blue-700' : 'bg-purple-600 hover:bg-purple-700'}`}>
                     <Save size={20} /> {initialInvoice ? 'Update Invoice' : (billType === 'SALE' ? 'Save Invoice' : 'Save Order')}
                 </button>
             </div>
        </div>
      </div> 
      
      {showPartyModal && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
              <div className="bg-white dark:bg-slate-800 rounded-xl shadow-2xl p-6 w-96 relative border dark:border-slate-700">
                  <button onClick={() => setShowPartyModal(false)} className="absolute right-4 top-4 text-slate-400 hover:text-black dark:hover:text-white">
                      <X size={20} />
                  </button>
                  <h3 className="text-lg font-bold mb-4 text-slate-800 dark:text-white">Quick Add {billType === 'SALE' ? 'Customer' : 'Supplier'}</h3>
                  <form onSubmit={handleQuickAddParty} className="space-y-3">
                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Name *</label>
                          <input required type="text" className="w-full border p-2 rounded bg-white dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={newParty.name} onChange={e => setNewParty({...newParty, name: e.target.value})} />
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Phone</label>
                          <input type="text" className="w-full border p-2 rounded bg-white dark:bg-slate-900 dark:border-slate-600 dark:text-white" value={newParty.phone} onChange={e => setNewParty({...newParty, phone: e.target.value})} />
                      </div>
                      <button className="w-full bg-blue-600 text-white py-2 rounded font-bold hover:bg-blue-700">Save & Select</button>
                  </form>
              </div>
          </div>
      )}

      {showPrintModal && currentInvoice && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-100 dark:bg-slate-900 rounded-xl w-full max-w-6xl h-[90vh] flex overflow-hidden">
                <div className="w-80 bg-white dark:bg-slate-800 border-r dark:border-slate-700 p-6 flex flex-col overflow-y-auto no-print">
                    <h2 className="text-xl font-bold mb-6 flex items-center gap-2 text-slate-800 dark:text-white"><Printer /> Print Settings</h2>
                    <div className="space-y-6 flex-1">
                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block flex items-center gap-2">
                                <Layout size={14} /> Template Layout
                            </label>
                            <div className="grid grid-cols-1 gap-2">
                                {(['standard', 'thermal', 'modern'] as const).map(t => (
                                    <button 
                                        key={t}
                                        onClick={() => setPrintConfig({...printConfig, template: t})}
                                        className={`px-4 py-3 rounded text-left capitalize border transition ${printConfig.template === t ? 'bg-blue-50 dark:bg-blue-900/30 border-blue-500 text-blue-700 dark:text-blue-300 ring-1 ring-blue-500' : 'bg-white dark:bg-slate-700 dark:border-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-600'}`}
                                    >
                                        {t} Layout
                                    </button>
                                ))}
                            </div>
                        </div>

                        {/* FONT & SIZE SETTINGS */}
                         <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block flex items-center gap-2">
                                <Type size={14} /> Font Style
                            </label>
                            <div className="flex bg-slate-100 dark:bg-slate-700 rounded p-1">
                                {(['sans', 'serif', 'mono'] as const).map(f => (
                                    <button 
                                        key={f}
                                        onClick={() => setPrintConfig({...printConfig, font: f})}
                                        className={`flex-1 py-2 text-xs font-bold rounded capitalize ${printConfig.font === f ? 'bg-white dark:bg-slate-600 shadow text-slate-800 dark:text-white' : 'text-slate-400'}`}
                                    >
                                        {f}
                                    </button>
                                ))}
                            </div>
                        </div>

                         <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block flex items-center gap-2">
                                <ImageIcon size={14} /> Logo Size
                            </label>
                            <div className="flex bg-slate-100 dark:bg-slate-700 rounded p-1">
                                {(['sm', 'md', 'lg'] as const).map(s => (
                                    <button 
                                        key={s}
                                        onClick={() => setPrintConfig({...printConfig, logoSize: s})}
                                        className={`flex-1 py-2 text-xs font-bold rounded uppercase ${printConfig.logoSize === s ? 'bg-white dark:bg-slate-600 shadow text-slate-800 dark:text-white' : 'text-slate-400'}`}
                                    >
                                        {s}
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block">Toggle Sections</label>
                            <div className="space-y-3 text-slate-700 dark:text-slate-300">
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showHeader} onChange={e => setPrintConfig({...printConfig, showHeader: e.target.checked})} />
                                    <span>Show Header</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showFooter} onChange={e => setPrintConfig({...printConfig, showFooter: e.target.checked})} />
                                    <span>Show Footer</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showQr} onChange={e => setPrintConfig({...printConfig, showQr: e.target.checked})} />
                                    <span>Show UPI QR</span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <div className="mt-6 pt-6 border-t dark:border-slate-700 space-y-3">
                        <button onClick={() => window.print()} className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-blue-700">
                            <Printer size={20} /> Print Invoice
                        </button>
                        <button onClick={handleDownloadPdf} className="w-full bg-green-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-green-700">
                            <FileDown size={20} /> Save as PDF
                        </button>
                        <button onClick={handleDownloadJpg} className="w-full bg-orange-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-orange-700">
                            <ImageIcon size={20} /> Save as JPG
                        </button>
                        <button onClick={() => setShowPrintModal(false)} className="w-full bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-white py-3 rounded-lg font-bold hover:bg-slate-50 dark:hover:bg-slate-600">
                            Close
                        </button>
                    </div>
                </div>
                <div className="flex-1 bg-slate-500 dark:bg-slate-900 overflow-auto p-8 flex justify-center">
                    <div className="shadow-2xl h-fit">
                        {/* KEEP INVOICE BG WHITE FOR PRINTING */}
                        <div id="print-area" className="bg-white">
                            <InvoiceTemplate invoice={currentInvoice} settings={settings} options={printConfig} />
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
