
import React, { useState, useEffect } from 'react';
import { ArrowDownLeft, ArrowUpRight, Wallet, Receipt, Trash2, Edit2, X, AlertCircle } from 'lucide-react';
import { Party, Transaction, Invoice } from '../types';
import * as db from '../services/db';

export const PaymentsPage: React.FC = () => {
  const [parties, setParties] = useState<Party[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  
  // Form State
  const [type, setType] = useState<'PAYMENT_IN' | 'PAYMENT_OUT'>('PAYMENT_IN');
  const [partyId, setPartyId] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  
  // Edit State
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Filter State
  const [filter, setFilter] = useState<'ALL' | 'PAYMENT_IN' | 'PAYMENT_OUT'>('ALL');

  const load = () => {
    setParties(db.getParties());
    setTransactions(db.getTransactions());
    setInvoices(db.getInvoices());
  };
  
  useEffect(() => { load(); }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parties.find(x => x.id === partyId);
    if (!p) return;

    const isOpening = selectedInvoiceId === 'OPENING_BALANCE';
    
    const txData: Transaction = {
      id: editingTx ? editingTx.id : '',
      date: editingTx ? editingTx.date : new Date().toISOString().split('T')[0],
      partyId,
      partyName: p.name,
      amount: parseFloat(amount),
      type,
      note,
      invoiceId: isOpening ? undefined : (selectedInvoiceId || undefined),
      isOpeningBalance: isOpening
    };

    if (editingTx) {
        db.updateTransaction(txData);
        alert('Transaction updated successfully. Balances adjusted.');
    } else {
        db.createTransaction(txData);
    }
    
    resetForm();
    load(); 
  };

  const resetForm = () => {
      setAmount('');
      setNote('');
      setSelectedInvoiceId('');
      setEditingTx(null);
      // We keep partyId and type for convenience unless cleared
  };

  const handleEdit = (tx: Transaction) => {
      setEditingTx(tx);
      setType(tx.type);
      setPartyId(tx.partyId);
      setAmount(tx.amount.toString());
      setNote(tx.note);
      if (tx.isOpeningBalance) setSelectedInvoiceId('OPENING_BALANCE');
      else setSelectedInvoiceId(tx.invoiceId || '');
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
      if(confirm("Are you sure? This will reverse the effect on Party Balance and Invoice Paid Amount.")) {
          db.deleteTransaction(id);
          load();
      }
  };

  const selectedParty = parties.find(p => p.id === partyId);

  // Filter Pending Invoices for selected party
  const pendingInvoices = selectedParty ? invoices.filter(inv => {
      const dueAmount = inv.totalAmount - inv.paidAmount;
      const isPending = dueAmount > 0.5; // Tolerance
      const matchParty = inv.partyId === selectedParty.id;
      const matchType = type === 'PAYMENT_IN' ? inv.type === 'SALE' : inv.type === 'PURCHASE';
      const isCurrentlySelected = editingTx && editingTx.invoiceId === inv.id;
      
      return matchParty && (isPending || isCurrentlySelected) && matchType;
  }) : [];

  const handleInvoiceSelect = (invId: string) => {
      setSelectedInvoiceId(invId);
      
      if (!invId) {
          if (!editingTx) setNote('');
          return;
      }

      if (invId === 'OPENING_BALANCE') {
          if (!note) setNote('Payment for Opening Balance / Previous Dues');
          // For opening balance, we don't autofill amount as it varies
          return;
      }

      const inv = pendingInvoices.find(i => i.id === invId);
      if (inv) {
          const due = inv.totalAmount - inv.paidAmount;
          setAmount(due.toFixed(2));
          if (!note || note.startsWith('Payment for')) {
             setNote(`Payment for ${inv.type === 'SALE' ? 'Invoice' : 'Bill'} #${inv.id}`);
          }
      }
  };

  const filteredTransactions = transactions.filter(t => {
    if (filter === 'ALL') return true;
    return t.type === filter;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Form */}
      <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-sm border dark:border-slate-700 h-fit transition-colors">
        <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg flex items-center gap-2 text-slate-800 dark:text-white">
                {type === 'PAYMENT_IN' ? <ArrowDownLeft className="text-green-500" /> : <ArrowUpRight className="text-red-500" />}
                {editingTx ? 'Edit Transaction' : 'Record Payment'}
            </h3>
            {editingTx && (
                <button onClick={resetForm} className="text-xs text-red-500 flex items-center gap-1 bg-red-50 dark:bg-red-900/30 px-2 py-1 rounded">
                    <X size={12} /> Cancel Edit
                </button>
            )}
        </div>
        
        <div className="flex bg-slate-100 dark:bg-slate-700 p-1 rounded mb-4">
            <button onClick={() => { setType('PAYMENT_IN'); setPartyId(''); }} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_IN' ? 'bg-green-500 text-white shadow' : 'text-slate-500 dark:text-slate-300'}`}>Receive (In)</button>
            <button onClick={() => { setType('PAYMENT_OUT'); setPartyId(''); }} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_OUT' ? 'bg-red-500 text-white shadow' : 'text-slate-500 dark:text-slate-300'}`}>Pay (Out)</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
             <div>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Party Name</label>
                <select required className="w-full border dark:border-slate-600 p-2 rounded bg-white dark:bg-slate-900 dark:text-white" value={partyId} onChange={e => { setPartyId(e.target.value); setSelectedInvoiceId(''); }}>
                    <option value="">Select Party</option>
                    {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
             </div>
             
             {/* Current Balance Display */}
             {selectedParty && (
                <div className={`p-3 rounded-lg flex items-center justify-between text-sm ${selectedParty.balance > 0 ? 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400' : 'bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400'}`}>
                    <span className="flex items-center gap-2 font-medium"><Wallet size={16}/> Total Balance:</span>
                    <span className="font-bold text-lg">
                        ₹ {Math.abs(selectedParty.balance).toFixed(2)} {selectedParty.balance > 0 ? 'Dr' : 'Cr'}
                    </span>
                </div>
             )}

             {/* Link Invoice Selector */}
             {selectedParty && (
                 <div className="bg-blue-50 dark:bg-blue-900/20 p-3 rounded border border-blue-100 dark:border-blue-800">
                     <label className="block text-xs font-bold text-blue-700 dark:text-blue-400 mb-1 flex items-center gap-1">
                        <Receipt size={12} /> Allocation (Optional)
                     </label>
                     <select 
                        className="w-full border dark:border-slate-600 p-2 rounded text-sm bg-white dark:bg-slate-900 dark:text-white" 
                        value={selectedInvoiceId} 
                        onChange={e => handleInvoiceSelect(e.target.value)}
                     >
                        <option value="">-- General / On Account --</option>
                        {selectedParty.openingBalance !== undefined && selectedParty.openingBalance !== 0 && (
                            <option value="OPENING_BALANCE" className="font-bold text-purple-600">
                                ⟲ Opening Balance (Old Dues)
                            </option>
                        )}
                        <optgroup label="Pending Bills">
                            {pendingInvoices.map(inv => (
                                <option key={inv.id} value={inv.id}>
                                    #{inv.id} - {inv.date} (Due: ₹{(inv.totalAmount - inv.paidAmount).toFixed(2)})
                                </option>
                            ))}
                        </optgroup>
                     </select>
                 </div>
             )}

             <div>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Amount</label>
                <input required type="number" step="0.01" className="w-full border dark:border-slate-600 p-2 rounded font-bold bg-white dark:bg-slate-900 dark:text-white" value={amount} onChange={e => setAmount(e.target.value)} />
             </div>
             <div>
                <label className="block text-sm font-medium mb-1 text-slate-700 dark:text-slate-300">Note / Reference</label>
                <textarea className="w-full border dark:border-slate-600 p-2 rounded bg-white dark:bg-slate-900 dark:text-white" value={note} onChange={e => setNote(e.target.value)} rows={3}></textarea>
             </div>
             <button className={`w-full py-2 rounded text-white font-bold ${type === 'PAYMENT_IN' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}>
                 {editingTx ? 'Update Transaction' : 'Save Transaction'}
             </button>
        </form>
      </div>

      {/* History */}
      <div className="lg:col-span-2 bg-white dark:bg-slate-800 rounded-xl shadow-sm border dark:border-slate-700 overflow-hidden transition-colors">
        <div className="p-4 border-b dark:border-slate-700 bg-slate-50 dark:bg-slate-900 flex flex-col sm:flex-row justify-between items-center gap-3">
            <h3 className="font-bold text-slate-700 dark:text-white flex items-center gap-2">
                Recent Transactions
            </h3>
            <div className="flex bg-slate-200 dark:bg-slate-700 rounded-lg p-1 text-xs font-bold">
                <button 
                    onClick={() => setFilter('ALL')} 
                    className={`px-3 py-1 rounded-md transition ${filter === 'ALL' ? 'bg-white dark:bg-slate-600 shadow text-slate-800 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                >
                    All
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_IN')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_IN' ? 'bg-white dark:bg-slate-600 shadow text-green-700 dark:text-green-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                >
                    <ArrowDownLeft size={12} /> Received
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_OUT')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_OUT' ? 'bg-white dark:bg-slate-600 shadow text-red-700 dark:text-red-400' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}
                >
                    <ArrowUpRight size={12} /> Paid
                </button>
            </div>
        </div>
        <table className="w-full text-left text-sm">
            <thead className="text-slate-500 dark:text-slate-400 border-b dark:border-slate-700">
                <tr>
                    <th className="p-4">Date</th>
                    <th className="p-4">Party</th>
                    <th className="p-4">Type</th>
                    <th className="p-4">Reference</th>
                    <th className="p-4 text-right">Amount</th>
                    <th className="p-4 text-center">Action</th>
                </tr>
            </thead>
            <tbody className="divide-y dark:divide-slate-700 dark:text-slate-300">
                {filteredTransactions.map(t => (
                    <tr key={t.id} className={editingTx?.id === t.id ? "bg-blue-50 dark:bg-blue-900/20" : ""}>
                        <td className="p-4 text-slate-500 dark:text-slate-400">{t.date}</td>
                        <td className="p-4 font-medium dark:text-white">{t.partyName}</td>
                        <td className="p-4">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400' : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'}`}>
                                {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                            </span>
                        </td>
                        <td className="p-4">
                              {t.isOpeningBalance ? (
                                  <span className="text-xs font-bold bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 px-2 py-1 rounded">Previous Due</span>
                              ) : t.invoiceId ? (
                                  <span className="text-xs font-mono bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">Inv #{t.invoiceId.substring(0,8)}</span>
                              ) : (
                                  <span className="text-xs text-slate-300 dark:text-slate-600">On Account</span>
                              )}
                              {t.note && <div className="text-xs text-slate-500 mt-1 max-w-xs truncate">{t.note}</div>}
                        </td>
                        <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                            {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                        </td>
                        <td className="p-4 text-center flex justify-center gap-2">
                            <button onClick={() => handleEdit(t)} className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"><Edit2 size={16} /></button>
                            <button onClick={() => handleDelete(t.id)} className="text-slate-400 hover:text-red-600 dark:hover:text-red-400"><Trash2 size={16} /></button>
                        </td>
                    </tr>
                ))}
                {filteredTransactions.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-slate-400">No transactions found</td></tr>}
            </tbody>
        </table>
      </div>
    </div>
  );
};
