
import React, { useState } from 'react';
import { Lock, User, RefreshCw } from 'lucide-react';
import * as db from '../services/db';
import { UserAccount } from '../types';

interface Props {
  onLogin: (user: UserAccount) => void;
}

export const LoginPage: React.FC<Props> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    // Try to authenticate directly first (uses cached data if initialized)
    // If failed, we might want to trigger a refresh implicitly, 
    // but explicit refresh button is safer for UX.
    let user = db.authenticate(username, password);
    
    // If not found, maybe data isn't loaded yet?
    if (!user) {
        await db.initDB();
        user = db.authenticate(username, password);
    }

    if (user) {
        // Persist simple session
        localStorage.setItem('sakshi_erp_user_id', user.id);
        onLogin(user);
    } else {
        setError('Invalid Username or Password. Please check Google Sheet.');
    }
    setLoading(false);
  };

  const handleRefreshData = async () => {
    setRefreshing(true);
    setError('');
    const success = await db.initDB();
    setRefreshing(false);
    if (success) {
        alert("Data refreshed from Google Sheet! Try logging in now.");
    } else {
        setError("Failed to connect to Google Sheet.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
        <div className="text-center mb-8">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Sakshi ERP</h1>
            <p className="text-slate-500 text-sm">Professional Edition</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
            <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Username</label>
                <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                        type="text" 
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="Enter username"
                        value={username}
                        onChange={e => setUsername(e.target.value)}
                    />
                </div>
            </div>

            <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Password</label>
                <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                    <input 
                        type="password" 
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
                        placeholder="••••••••"
                        value={password}
                        onChange={e => setPassword(e.target.value)}
                    />
                </div>
            </div>

            {error && <p className="text-red-500 text-sm text-center font-medium">{error}</p>}

            <button 
                disabled={loading || refreshing}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 transition disabled:opacity-50"
            >
                {loading ? 'Verifying...' : 'Login Securely'}
            </button>
            
            <button
                type="button"
                onClick={handleRefreshData}
                disabled={refreshing}
                className="w-full flex items-center justify-center gap-2 text-slate-500 py-2 hover:bg-slate-50 rounded-lg transition text-sm"
            >
                <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
                {refreshing ? 'Syncing...' : 'Refresh Data from Sheet'}
            </button>
        </form>
        
        <div className="mt-6 text-center border-t border-slate-100 pt-4">
            <p className="text-xs text-slate-400 font-bold mb-1">DATA SOURCE: Google Sheet &gt; Users Tab</p>
            <p className="text-xs text-slate-400">Default: admin / admin123</p>
            <p className="text-xs text-slate-400 mt-2">&copy; 2025 Aapbiti New SRM</p>
        </div>
      </div>
    </div>
  );
};
