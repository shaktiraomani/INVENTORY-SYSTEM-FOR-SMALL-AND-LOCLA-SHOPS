
/**
 * SAKSHI ERP PRO - GOOGLE APPS SCRIPT BACKEND
 * 
 * INSTRUCTIONS:
 * 1. Copy the content of this file into 'Code.gs' in your Apps Script project.
 * 2. Create a file named 'index.html' in Apps Script.
 * 3. Copy the content of your local 'dist/index.html' into the Apps Script 'index.html'.
 */

const SHEET_MAPPING = {
  'party': 'Parties',
  'product': 'Products',
  'invoice': 'Invoices',
  'transaction': 'Transactions',
  'setting': 'Settings',
  'user': 'Users'
};

/**
 * SERVES THE FRONTEND WEB APP
 */
function doGet(e) {
  try {
    return HtmlService.createTemplateFromFile('index')
      .evaluate()
      .setTitle('Sakshi ERP Pro')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return ContentService.createTextOutput("Error: 'index.html' not found. Please create 'index.html' in the script editor and paste your built HTML code there.");
  }
}

/**
 * API: GET DATA (Called from React via google.script.run)
 * Returns a JSON String containing all application data.
 */
function apiGetData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Create sheets if missing
  Object.keys(SHEET_MAPPING).forEach(key => {
    const name = SHEET_MAPPING[key];
    let sheet = ss.getSheetByName(name);
    if (!sheet) {
      sheet = ss.insertSheet(name);
      // Initialize headers for key sheets
      if (key === 'user') {
         sheet.appendRow(['id', 'username', 'password', 'name', 'role']);
         // Add default admin if empty
         sheet.appendRow(['u1', 'admin', 'admin123', 'System Admin', 'ADMIN']);
      } else if (key === 'setting') {
         sheet.appendRow(['businessName', 'address', 'phone', 'invoicePrefix', 'invoiceStartSequence']);
      } else {
         sheet.appendRow(['id', 'date', 'name']); // Generic fallback header
      }
    }
  });

  const payload = {
    parties: getSheetData(ss, SHEET_MAPPING['party']),
    products: getSheetData(ss, SHEET_MAPPING['product']),
    invoices: getSheetData(ss, SHEET_MAPPING['invoice']),
    transactions: getSheetData(ss, SHEET_MAPPING['transaction']),
    settings: getSheetData(ss, SHEET_MAPPING['setting'])[0] || {},
    users: getSheetData(ss, SHEET_MAPPING['user'])
  };

  // Return as string to avoid GAS object serialization issues
  return JSON.stringify(payload);
}

/**
 * API: POST DATA (Called from React via google.script.run)
 * Receives a JSON string, parses it, and updates the sheet.
 */
function apiPostData(payloadString) {
  const lock = LockService.getScriptLock();
  // Wait up to 30 seconds for other processes to finish
  lock.waitLock(30000); 

  try {
    const data = JSON.parse(payloadString);
    const type = data.type; 
    const action = data.action;
    const payload = data.payload;

    const sheetName = SHEET_MAPPING[type] || capitalize(type + 's');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(sheetName);

    if (!sheet) {
        sheet = ss.insertSheet(sheetName);
    }

    // Dynamic Header Management: 
    // If the sheet is empty or new columns are added in the payload, update headers.
    let headers = [];
    if (sheet.getLastRow() === 0) {
       headers = Object.keys(payload);
       sheet.appendRow(headers);
    } else {
       headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
       const newColumns = Object.keys(payload).filter(k => !headers.includes(k));
       if (newColumns.length > 0) {
         // Add new columns to the header row
         sheet.getRange(1, headers.length + 1, 1, newColumns.length).setValues([newColumns]);
         headers = [...headers, ...newColumns];
       }
    }

    // Helper to map object to array based on header order
    const objToRow = (obj) => headers.map(h => {
      let val = obj[h];
      if (val === undefined || val === null) return '';
      if (typeof val === 'object') return JSON.stringify(val); // Serialize nested objects (arrays, etc)
      return val;
    });

    // Find the row to update/delete based on ID
    const idIndex = headers.indexOf('id');
    let rowIndex = -1;

    if (action !== 'create' && idIndex !== -1 && sheet.getLastRow() > 1) {
       const ids = sheet.getRange(2, idIndex + 1, sheet.getLastRow() - 1, 1).getValues().flat();
       rowIndex = ids.indexOf(payload.id);
    }

    // PERFORM ACTION
    if (action === 'create') {
      sheet.appendRow(objToRow(payload));
    } 
    else if (action === 'update') {
      if (rowIndex !== -1) {
        // Update existing row (row index is 0-based from data range, so +2 for 1-based index + header)
        const newRowData = objToRow(payload);
        sheet.getRange(rowIndex + 2, 1, 1, newRowData.length).setValues([newRowData]);
      } else {
        // Fallback: If ID not found, treat as create
        sheet.appendRow(objToRow(payload));
      }
    } 
    else if (action === 'delete') {
      if (rowIndex !== -1) {
        sheet.deleteRow(rowIndex + 2);
      }
    }

    return { status: "success" };
  } catch (e) {
    Logger.log("Error in apiPostData: " + e);
    // Return error status to frontend
    return { status: "error", message: e.toString() };
  } finally {
    lock.releaseLock();
  }
}

/**
 * UTILITIES
 */
function getSheetData(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() <= 1) return [];
  
  const rows = sheet.getDataRange().getValues();
  const headers = rows[0];
  const data = rows.slice(1);
  
  return data.map(row => {
    let obj = {};
    headers.forEach((h, i) => {
      let val = row[i];
      // Convert Dates to clean Strings
      if (val instanceof Date) {
        val = Utilities.formatDate(val, ss.getSpreadsheetTimeZone(), "yyyy-MM-dd");
      }
      // Try parsing JSON for items (arrays stored as strings)
      if (typeof val === 'string' && (val.startsWith('[') || val.startsWith('{'))) {
         try { val = JSON.parse(val); } catch(e) {}
      }
      obj[h] = val;
    });
    return obj;
  });
}

function capitalize(s) { 
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1); 
}
