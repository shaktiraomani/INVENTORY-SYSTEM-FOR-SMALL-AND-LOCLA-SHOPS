
import { GoogleGenAI } from "@google/genai";
import { getInvoices, getParties, getProducts, getTransactions, getSettings } from "./db";

// ==========================================
// OFFLINE / LOCAL INTELLIGENCE (FREE MODE)
// ==========================================
const generateOfflineAnalysis = (prompt: string, context: any): string => {
    const { sales_summary, products, transactions } = context;

    const totalSales = sales_summary.reduce((acc: number, cur: any) => acc + (cur.type === 'SALE' ? cur.total : 0), 0);
    const totalDue = sales_summary.reduce((acc: number, cur: any) => acc + (cur.total - cur.paid), 0);
    const lowStockItems = products.filter((p: any) => p.stock < 10);
    
    let response = "📢 **Offline Assistant Analysis** (No API Key Detected)\n\n";

    // Detect Intent based on simple keywords
    const p = prompt.toLowerCase();

    if (p.includes('sale') || p.includes('revenue') || p.includes('income')) {
        response += `💰 **Sales Overview:**\nYour total recorded sales amount to **₹${totalSales.toLocaleString()}**.\n`;
        response += `You have generated ${sales_summary.filter((i:any) => i.type === 'SALE').length} sales invoices so far.`;
    } 
    else if (p.includes('due') || p.includes('pending') || p.includes('outstanding')) {
        response += `⚠️ **Payment Alerts:**\nTotal outstanding amount from market is **₹${totalDue.toLocaleString()}**.\n`;
        const topDefaulters = sales_summary
            .filter((i: any) => (i.total - i.paid) > 0)
            .sort((a: any, b: any) => (b.total - b.paid) - (a.total - a.paid))
            .slice(0, 3);
        
        if (topDefaulters.length > 0) {
            response += "\n**Top Unpaid Invoices:**\n";
            topDefaulters.forEach((inv: any) => {
                response += `- ${inv.party}: ₹${(inv.total - inv.paid).toFixed(2)} due\n`;
            });
        }
    }
    else if (p.includes('stock') || p.includes('product') || p.includes('inventory')) {
        response += `📦 **Inventory Status:**\nYou have ${products.length} unique products listed.\n`;
        if (lowStockItems.length > 0) {
            response += `\n🔴 **Low Stock Warning:**\n${lowStockItems.length} items are below reorder level (10 qty).\n`;
            lowStockItems.slice(0, 5).forEach((item: any) => {
                response += `- ${item.name}: ${item.stock} left\n`;
            });
        } else {
            response += "✅ All stock levels appear healthy.";
        }
    }
    else if (p.includes('supplier') || p.includes('purchase')) {
        const purchases = sales_summary.filter((i:any) => i.type === 'PURCHASE');
        const totalPurchase = purchases.reduce((acc: number, cur: any) => acc + cur.total, 0);
        response += `🚚 **Purchase Summary:**\nTotal purchases made: **₹${totalPurchase.toLocaleString()}** via ${purchases.length} bills.`;
    }
    else {
        // General Summary
        response += `Here is a quick snapshot of your business:\n`;
        response += `- **Total Revenue:** ₹${totalSales.toLocaleString()}\n`;
        response += `- **Pending Collection:** ₹${totalDue.toLocaleString()}\n`;
        response += `- **Low Stock Items:** ${lowStockItems.length}\n`;
        response += `\n*Tip: Ask specific questions like "Who has pending payments?" or "Show low stock".*`;
    }

    return response;
};

export const askAI = async (prompt: string): Promise<string> => {
  // 1. Check Settings First
  const settings = getSettings();
  let apiKey = settings.apiKey;

  // 2. Fallback to Environment Variable
  if (!apiKey || apiKey.trim() === '') {
      apiKey = process.env.API_KEY;
  }

  // Gather Context
  const context = {
    sales_summary: getInvoices().map(i => ({ date: i.date, total: i.totalAmount, paid: i.paidAmount, party: i.partyName, type: i.type })),
    products: getProducts().map(p => ({ name: p.name, stock: p.stock })),
    transactions: getTransactions().slice(0, 20)
  };

  // === FREE OFFLINE MODE ===
  if (!apiKey) {
    console.log("No API Key found. Using Offline Logic.");
    // Simulate a short delay to feel like "processing"
    await new Promise(resolve => setTimeout(resolve, 800));
    return generateOfflineAnalysis(prompt, context);
  }

  // === ONLINE GEMINI MODE ===
  const ai = new GoogleGenAI({ apiKey: apiKey });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Analyze the following business data JSON: ${JSON.stringify(context)}. User Query: ${prompt}`,
      config: {
        systemInstruction: "You are the AI assistant for 'Sakshi ERP Pro'. Keep the answer concise, professional, and actionable. If asking about sales, calculate totals from the provided JSON. Do not mention 'JSON' or technical terms.",
      }
    });
    return response.text || "No response generated.";
  } catch (e: any) {
    console.error("AI Error:", e);
    
    // Fallback to offline mode even if Key exists but fails (e.g. Quota exceeded)
    console.warn("Falling back to Offline Analysis due to API Error.");
    return generateOfflineAnalysis(prompt, context) + "\n\n*(Note: Switched to offline mode due to connection error)*";
  }
};
