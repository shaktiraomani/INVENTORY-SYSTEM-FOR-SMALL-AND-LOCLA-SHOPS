
import React, { useEffect, useState } from 'react';
import { Invoice, UserSettings, PrintOptions } from '../types';
import QRCode from 'qrcode';

interface Props {
  invoice: Invoice;
  settings: UserSettings;
  options: PrintOptions;
}

export const InvoiceTemplate: React.FC<Props> = ({ invoice, settings, options }) => {
  const [qrUrl, setQrUrl] = useState('');

  const isSale = invoice.type === 'SALE';
  const docTitle = isSale ? 'INVOICE' : 'PURCHASE ORDER';
  const partyLabel = isSale ? 'Billed To' : 'Vendor / Supplier';
  const isInterState = invoice.taxType === 'INTER';
  const isNoTax = invoice.taxType === 'NONE';
  const themeColor = settings.themeColor || '#2563eb';

  const totalDiscount = invoice.items.reduce((acc, item) => {
    const gross = item.price * item.qty;
    let discAmt = item.discountType === 'PERCENT' ? (gross * item.discount) / 100 : item.discount;
    return acc + discAmt;
  }, 0);

  const totalTaxAmt = invoice.items.reduce((acc, item) => acc + (item.gstAmount || 0), 0);

  // Font Classes
  const fontClass = {
      'sans': 'font-sans',
      'serif': 'font-serif',
      'mono': 'font-mono'
  }[options.font || 'sans'];

  useEffect(() => {
    if (isSale && settings.upiId && options.showQr) {
      const upiId = settings.upiId.trim();
      if (!upiId) return;
      const upiString = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(settings.businessName)}&am=${invoice.totalAmount.toFixed(2)}&tr=${invoice.id}&tn=Inv-${invoice.id}`;
      QRCode.toDataURL(upiString, { margin: 0 }).then(setQrUrl).catch(console.error);
    } else {
        setQrUrl('');
    }
  }, [invoice, settings, options.showQr, isSale]);

  // ==========================================
  // 1. THERMAL PRINTER LAYOUT (80mm)
  // ==========================================
  if (options.template === 'thermal') {
    return (
      <div className={`w-[80mm] p-2 text-slate-900 bg-white text-xs ${fontClass} mx-auto`}>
        {/* Header */}
        <div className="text-center mb-2">
            {options.logoSize !== 'sm' && settings.logo && (
                <img src={settings.logo} className="h-10 mx-auto mb-1 grayscale" alt="Logo" />
            )}
            <h1 className="font-bold text-sm uppercase">{settings.businessName}</h1>
            <div className="text-[10px] whitespace-pre-line leading-tight">{settings.address}</div>
            <div className="text-[10px] mt-1">Ph: {settings.phone}</div>
            {settings.gstin && <div className="text-[10px]">GSTIN: {settings.gstin}</div>}
        </div>

        <div className="border-b border-dashed border-slate-800 my-2"></div>
        
        {/* Meta */}
        <div className="flex justify-between font-bold">
            <span>{docTitle}</span>
            <span>#{invoice.id}</span>
        </div>
        <div className="flex justify-between">
            <span>Date: {invoice.date}</span>
        </div>
        <div className="mt-1">
             <span className="font-bold block">{partyLabel}:</span>
             <span>{invoice.partyName}</span>
        </div>

        <div className="border-b border-dashed border-slate-800 my-2"></div>

        {/* Items */}
        <table className="w-full text-left">
            <thead>
                <tr className="uppercase text-[9px] border-b border-slate-300">
                    <th className="py-1">Item</th>
                    <th className="py-1 text-center">Qty</th>
                    <th className="py-1 text-right">Price</th>
                    <th className="py-1 text-right">Total</th>
                </tr>
            </thead>
            <tbody>
                {invoice.items.map((item, i) => (
                    <tr key={i}>
                        <td className="py-1 pr-1">
                            <div className="font-bold">{item.name}</div>
                            {item.discount > 0 && <div className="text-[9px]">Disc: {item.discount}</div>}
                        </td>
                        <td className="py-1 text-center align-top">{item.qty}</td>
                        <td className="py-1 text-right align-top">{item.price}</td>
                        <td className="py-1 text-right align-top font-bold">{item.total.toFixed(2)}</td>
                    </tr>
                ))}
            </tbody>
        </table>

        <div className="border-b border-dashed border-slate-800 my-2"></div>

        {/* Totals */}
        <div className="space-y-1 text-right">
             {totalDiscount > 0 && <div>Disc: -{totalDiscount.toFixed(2)}</div>}
             {!isNoTax && <div>Tax: {totalTaxAmt.toFixed(2)}</div>}
             <div className="font-bold text-sm">TOTAL: {invoice.totalAmount.toFixed(2)}</div>
             <div>Paid: {invoice.paidAmount.toFixed(2)}</div>
             {(invoice.totalAmount - invoice.paidAmount) > 0.01 && (
                 <div className="font-bold">Due: {(invoice.totalAmount - invoice.paidAmount).toFixed(2)}</div>
             )}
        </div>

        {/* QR */}
        {options.showQr && qrUrl && (
            <div className="mt-4 text-center">
                <img src={qrUrl} alt="QR" className="w-20 h-20 mx-auto" />
                <div className="text-[9px] mt-1">Scan to Pay via UPI</div>
            </div>
        )}

        {/* Footer */}
        {options.showFooter && (
            <div className="mt-4 text-center text-[9px]">
                <p>Thank you for visiting!</p>
            </div>
        )}
      </div>
    );
  }

  // ==========================================
  // 2. MODERN LAYOUT
  // ==========================================
  if (options.template === 'modern') {
    return (
      <div className={`max-w-[210mm] mx-auto bg-white min-h-[297mm] text-slate-800 ${fontClass}`}>
          {/* Header Banner */}
          <div className="p-8 text-white" style={{ backgroundColor: themeColor }}>
              <div className="flex justify-between items-center">
                  <div>
                      <h1 className="text-3xl font-bold uppercase tracking-wide">{settings.businessName}</h1>
                      <div className="opacity-90 text-sm mt-1">{settings.address} • {settings.phone}</div>
                  </div>
                  {settings.logo && (
                      <div className="bg-white p-2 rounded-lg">
                          <img src={settings.logo} alt="Logo" className="h-16 object-contain" />
                      </div>
                  )}
              </div>
          </div>

          <div className="p-8">
              <div className="flex justify-between mb-8">
                  <div>
                      <div className="text-sm text-slate-500 uppercase font-bold mb-1">{partyLabel}</div>
                      <h2 className="text-xl font-bold">{invoice.partyName}</h2>
                      <div className="text-sm text-slate-600">{invoice.partyName} Address</div>
                      {invoice.gstin && <div className="text-sm font-mono mt-1">GSTIN: {invoice.gstin}</div>}
                  </div>
                  <div className="text-right">
                      <div className="text-4xl font-black text-slate-100 uppercase tracking-tighter absolute right-8 top-40 z-0 select-none">
                          {docTitle}
                      </div>
                      <div className="relative z-10">
                          <div className="text-sm text-slate-500 uppercase font-bold">Invoice Details</div>
                          <div className="text-lg font-bold text-slate-800">#{invoice.id}</div>
                          <div className="text-slate-600">Date: {invoice.date}</div>
                          {invoice.dueDate && <div className="text-red-600 font-bold text-sm">Due: {invoice.dueDate}</div>}
                      </div>
                  </div>
              </div>

              {/* Modern Table */}
              <table className="w-full mb-8">
                  <thead>
                      <tr className="text-xs uppercase tracking-wider text-slate-500 border-b-2 border-slate-200">
                          <th className="py-3 text-left">Description</th>
                          <th className="py-3 text-center">Qty</th>
                          <th className="py-3 text-right">Price</th>
                          <th className="py-3 text-right">Disc</th>
                          {!isNoTax && <th className="py-3 text-right">Tax</th>}
                          <th className="py-3 text-right">Amount</th>
                      </tr>
                  </thead>
                  <tbody className="text-sm font-medium">
                      {invoice.items.map((item, idx) => (
                          <tr key={idx} className={idx % 2 === 0 ? 'bg-slate-50' : 'bg-white'}>
                              <td className="py-3 px-2">
                                  <div className="font-bold text-slate-700">{item.name}</div>
                                  {item.hsn && <span className="text-xs text-slate-400">HSN: {item.hsn}</span>}
                              </td>
                              <td className="py-3 px-2 text-center text-slate-600">{item.qty}</td>
                              <td className="py-3 px-2 text-right text-slate-600">{item.price.toFixed(2)}</td>
                              <td className="py-3 px-2 text-right text-slate-400">
                                  {item.discount > 0 ? `-${item.discount}` : '-'}
                              </td>
                              {!isNoTax && (
                                  <td className="py-3 px-2 text-right text-slate-400">{(item.gstAmount || 0).toFixed(2)}</td>
                              )}
                              <td className="py-3 px-2 text-right font-bold text-slate-800">{item.total.toFixed(2)}</td>
                          </tr>
                      ))}
                  </tbody>
              </table>

              <div className="flex justify-end">
                  <div className="w-1/2 bg-slate-50 p-6 rounded-xl space-y-2">
                       <div className="flex justify-between text-sm text-slate-500">
                           <span>Subtotal</span>
                           <span>₹ {(invoice.totalAmount + totalDiscount - totalTaxAmt).toFixed(2)}</span>
                       </div>
                       {!isNoTax && (
                           <div className="flex justify-between text-sm text-slate-500">
                               <span>Tax</span>
                               <span>₹ {totalTaxAmt.toFixed(2)}</span>
                           </div>
                       )}
                       {totalDiscount > 0 && (
                           <div className="flex justify-between text-sm text-green-600">
                               <span>Discount</span>
                               <span>- ₹ {totalDiscount.toFixed(2)}</span>
                           </div>
                       )}
                       <div className="flex justify-between text-xl font-bold mt-4 pt-4 border-t border-slate-200" style={{ color: themeColor }}>
                           <span>Total</span>
                           <span>₹ {invoice.totalAmount.toFixed(2)}</span>
                       </div>
                  </div>
              </div>

              {/* Footer Section */}
              <div className="mt-12 flex justify-between items-end">
                   {options.showQr && qrUrl ? (
                       <div className="flex items-center gap-4">
                           <img src={qrUrl} alt="QR" className="w-24 h-24 border-2 border-slate-100 rounded-lg" />
                           <div className="text-xs text-slate-500">
                               <p className="font-bold">Payment QR</p>
                               <p>Scan with any UPI app</p>
                           </div>
                       </div>
                   ) : <div></div>}

                   {options.showFooter && (
                       <div className="text-right">
                           <div className="h-16 w-40 border-b-2 border-slate-300 mb-2 ml-auto"></div>
                           <p className="text-xs font-bold text-slate-600 uppercase">Authorized Signature</p>
                       </div>
                   )}
              </div>
          </div>
          
          {/* Footer Bar */}
          <div className="h-4 w-full mt-auto" style={{ backgroundColor: themeColor }}></div>
      </div>
    );
  }

  // ==========================================
  // 3. STANDARD LAYOUT (Classic)
  // ==========================================
  const logoClass = { 'sm': 'h-12', 'md': 'h-16', 'lg': 'h-24' }[options.logoSize || 'md'];

  return (
    <div className={`max-w-[210mm] mx-auto p-8 bg-white min-h-[297mm] text-slate-800 ${fontClass}`} style={{ borderTop: `8px solid ${themeColor}` }}>
      {options.showHeader && (
        <header className="flex justify-between items-start border-b-2 pb-6 mb-8" style={{ borderColor: themeColor }}>
            <div className="flex-1">
                {settings.logo && <img src={settings.logo} alt="Logo" className={`${logoClass} object-contain mb-3`} />}
                <h1 className="text-2xl font-bold uppercase tracking-tight" style={{ color: themeColor }}>{settings.businessName}</h1>
                <div className="text-sm mt-1 text-slate-600 whitespace-pre-line max-w-xs leading-tight">{settings.address}</div>
                <div className="text-sm text-slate-600 font-medium mt-1">Ph: {settings.phone}</div>
                {settings.gstin && <div className="text-sm text-slate-600">GSTIN: {settings.gstin}</div>}
            </div>
            <div className="text-right">
                <div className="text-4xl font-extrabold text-slate-100 uppercase tracking-widest select-none">{docTitle}</div>
                <div className="mt-4">
                    <table className="text-right ml-auto text-sm">
                        <tbody>
                            <tr><td className="pr-4 text-slate-500">Invoice No:</td><td className="font-bold text-lg">{invoice.id}</td></tr>
                            <tr><td className="pr-4 text-slate-500">Date:</td><td className="font-bold">{invoice.date}</td></tr>
                            {invoice.dueDate && <tr><td className="pr-4 text-slate-500">Due Date:</td><td className="font-bold text-red-600">{invoice.dueDate}</td></tr>}
                            {invoice.referenceNo && <tr><td className="pr-4 text-slate-500">Reference:</td><td className="font-bold">{invoice.referenceNo}</td></tr>}
                        </tbody>
                    </table>
                </div>
            </div>
        </header>
      )}

      <div className="flex justify-between items-start mb-8">
        <div className="w-1/2 p-4 bg-slate-50 rounded border border-slate-100">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">{partyLabel}</h3>
            <div className="font-bold text-lg text-slate-800">{invoice.partyName}</div>
            {invoice.gstin && <div className="text-sm text-slate-600 mt-1 font-mono">GSTIN: {invoice.gstin}</div>}
        </div>
        {options.showQr && qrUrl && (
            <div className="flex flex-col items-center">
                <div className="border p-2 bg-white rounded shadow-sm">
                   <img src={qrUrl} alt="UPI QR" className="w-24 h-24" />
                </div>
                <span className="text-[10px] uppercase font-bold text-slate-400 mt-1">Scan to Pay</span>
                <span className="text-xs font-bold text-slate-700">₹ {invoice.totalAmount.toFixed(2)}</span>
            </div>
        )}
      </div>

      <table className="w-full mb-8 border-collapse">
        <thead>
            <tr className="text-white text-sm uppercase" style={{ backgroundColor: themeColor }}>
                <th className="p-3 text-left first:rounded-tl last:rounded-tr">Item</th>
                <th className="p-3 text-right">Price</th>
                <th className="p-3 text-center">Qty</th>
                <th className="p-3 text-right">Disc</th>
                { !isNoTax && (
                    <>
                        <th className="p-3 text-right">Taxable</th>
                        {isInterState ? <th className="p-3 text-right">IGST</th> : <><th className="p-3 text-right">CGST</th><th className="p-3 text-right">SGST</th></>}
                    </>
                )}
                <th className="p-3 text-right last:rounded-tr">Total</th>
            </tr>
        </thead>
        <tbody className="text-sm">
            {invoice.items.map((item, idx) => {
                const taxAmt = item.gstAmount || 0;
                const rate = item.gstRate || 0;
                return (
                    <tr key={idx} className={`border-b border-slate-100 ${idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}`}>
                        <td className="p-3 font-medium text-slate-700">
                            {item.name}
                            {item.hsn && <span className="block text-[9px] text-slate-400">HSN: {item.hsn}</span>}
                        </td>
                        <td className="p-3 text-right">{item.price.toFixed(2)}</td>
                        <td className="p-3 text-center">{item.qty}</td>
                        <td className="p-3 text-right text-slate-500">{item.discount > 0 ? item.discount : '-'}</td>
                        { !isNoTax && (
                            <>
                                <td className="p-3 text-right font-mono text-slate-600">{item.taxableValue?.toFixed(2)}</td>
                                {isInterState ? (
                                    <td className="p-3 text-right">{taxAmt.toFixed(2)} <span className="text-[9px]">({rate}%)</span></td>
                                ) : (
                                    <>
                                        <td className="p-3 text-right">{(taxAmt/2).toFixed(2)} <span className="text-[9px]">({rate/2}%)</span></td>
                                        <td className="p-3 text-right">{(taxAmt/2).toFixed(2)} <span className="text-[9px]">({rate/2}%)</span></td>
                                    </>
                                )}
                            </>
                        )}
                        <td className="p-3 text-right font-bold text-slate-800">{item.total.toFixed(2)}</td>
                    </tr>
                );
            })}
        </tbody>
      </table>

      <div className="flex justify-end mb-12">
          <div className="w-1/2 lg:w-1/3 space-y-2 text-sm">
                {totalDiscount > 0 && <div className="flex justify-between text-slate-500"><span>Total Discount</span><span className="text-green-600 font-medium">- ₹ {totalDiscount.toFixed(2)}</span></div>}
                { !isNoTax && <div className="flex justify-between text-slate-500"><span>Total Tax (GST)</span><span className="font-medium">₹ {totalTaxAmt.toFixed(2)}</span></div>}
                <div className="flex justify-between items-center py-2 border-t border-b border-slate-300">
                    <span className="font-bold text-lg" style={{ color: themeColor }}>Grand Total</span>
                    <span className="font-bold text-xl" style={{ color: themeColor }}>₹ {invoice.totalAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-slate-500 pt-1"><span>Paid Amount</span><span className="font-medium">₹ {invoice.paidAmount.toFixed(2)}</span></div>
                {(invoice.totalAmount - invoice.paidAmount) > 0.01 && <div className="flex justify-between text-red-600 font-bold pt-1"><span>Balance Due</span><span>₹ {(invoice.totalAmount - invoice.paidAmount).toFixed(2)}</span></div>}
          </div>
      </div>

      {options.showFooter && (
        <footer className="mt-auto flex flex-col justify-between text-xs text-slate-400">
            <div className="flex justify-between items-end">
                <div className="w-2/3 pr-8">
                     <h4 className="font-bold text-slate-600 mb-1">Terms & Conditions</h4>
                     {settings.footerText ? <p className="whitespace-pre-wrap leading-relaxed">{settings.footerText}</p> : <ul className="list-disc list-inside space-y-1"><li>Goods once sold will not be taken back.</li><li>Interest @24% p.a. will be charged if payment is delayed.</li><li>Subject to local jurisdiction.</li></ul>}
                </div>
                <div className="text-center">
                     <div className="h-16 w-32 border-b-2 border-slate-300 mb-2"></div>
                     <span className="font-bold text-slate-600">Authorized Signatory</span>
                </div>
            </div>
            <div className="text-center mt-8 pt-4 border-t border-slate-100 text-[10px]">Generated by Sakshi ERP Pro</div>
        </footer>
      )}
    </div>
  );
};
