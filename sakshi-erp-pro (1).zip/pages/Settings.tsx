import React, { useState } from 'react';
import { UserSettings } from '../types';
import * as db from '../services/db';

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<UserSettings>(db.getSettings());

  const handleSave = () => {
    db.saveSettings(settings);
    alert('Settings saved!');
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-8 rounded-xl shadow-sm border">
        <h2 className="text-xl font-bold mb-6">Business Settings</h2>
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium mb-1">Business Name</label>
                <input className="w-full border p-2 rounded" value={settings.businessName} onChange={e => setSettings({...settings, businessName: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Address</label>
                <textarea className="w-full border p-2 rounded" value={settings.address} onChange={e => setSettings({...settings, address: e.target.value})}></textarea>
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">Phone</label>
                <input className="w-full border p-2 rounded" value={settings.phone} onChange={e => setSettings({...settings, phone: e.target.value})} />
            </div>
            <div>
                <label className="block text-sm font-medium mb-1">UPI ID (For QR Code)</label>
                <input className="w-full border p-2 rounded" value={settings.upiId} onChange={e => setSettings({...settings, upiId: e.target.value})} />
                <p className="text-xs text-slate-400 mt-1">e.g. 9876543210@upi</p>
            </div>
            <button onClick={handleSave} className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save Configuration</button>
        </div>
    </div>
  );
};