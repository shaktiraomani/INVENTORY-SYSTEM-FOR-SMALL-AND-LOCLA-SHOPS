import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Edit2, Search, Package, AlertTriangle, ClipboardList, ArrowUp, ArrowDown } from 'lucide-react';
import { Product } from '../types';
import * as db from '../services/db';

export const ProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Edit State
  const [editing, setEditing] = useState<Product | null>(null);
  
  // Stock Adjustment State
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [adjForm, setAdjForm] = useState({ type: 'INCREASE' as 'INCREASE'|'DECREASE', qty: 0, reason: '' });

  const [search, setSearch] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);
  
  const [form, setForm] = useState<Partial<Product>>({ name: '', unit: 'PCS', price: 0, stock: 0 });

  const load = () => setProducts(db.getProducts());
  useEffect(() => { load(); }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    db.saveProduct({ id: editing ? editing.id : '', ...form } as Product);
    setIsModalOpen(false);
    setForm({ name: '', unit: 'PCS', price: 0, stock: 0 });
    setEditing(null);
    load();
  };

  const handleStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;
    if (adjForm.qty <= 0) return alert("Quantity must be greater than 0");
    if (!adjForm.reason.trim()) return alert("Reason is mandatory for audit purposes");

    db.adjustStock({
      productId: adjustingProduct.id,
      productName: adjustingProduct.name,
      type: adjForm.type,
      qty: adjForm.qty,
      reason: adjForm.reason
    });

    setAdjustingProduct(null);
    setAdjForm({ type: 'INCREASE', qty: 0, reason: '' });
    load();
    alert('Stock adjusted successfully');
  };

  const filtered = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesStock = showLowStock ? p.stock < 10 : true;
    return matchesSearch && matchesStock;
  });

  const lowStockCount = db.getLowStockProducts(10).length;

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
         <div className="relative flex-1 w-full md:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Search products..." 
            className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none w-full md:w-64"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
            <button 
                onClick={() => setShowLowStock(!showLowStock)}
                className={`px-4 py-2 rounded-lg flex items-center gap-2 border transition ${showLowStock ? 'bg-red-100 text-red-700 border-red-200' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
            >
                <AlertTriangle size={20} /> 
                <span className="hidden md:inline">Low Stock</span>
                <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded-full">{lowStockCount}</span>
            </button>
            <button 
            onClick={() => { setEditing(null); setForm({ name: '', unit: 'PCS', price: 0, stock: 0 }); setIsModalOpen(true); }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 flex-1 justify-center md:flex-none"
            >
            <Plus size={20} /> <span className="hidden md:inline">Add Product</span><span className="md:hidden">Add</span>
            </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-500 text-sm uppercase">
            <tr>
              <th className="p-4">Product Name</th>
              <th className="p-4">Unit</th>
              <th className="p-4">Price</th>
              <th className="p-4">Current Stock</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(p => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="p-4 font-medium text-slate-800 flex items-center gap-2">
                  <Package className="text-slate-400" size={16} /> {p.name}
                </td>
                <td className="p-4 text-slate-600">{p.unit}</td>
                <td className="p-4 font-medium">₹ {p.price.toFixed(2)}</td>
                <td className="p-4">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${p.stock < 10 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                    {p.stock} {p.stock < 10 && 'Low'}
                  </span>
                </td>
                <td className="p-4 text-right flex justify-end gap-2">
                   <button 
                    onClick={() => { setAdjustingProduct(p); setAdjForm({ type: 'INCREASE', qty: 0, reason: '' }) }} 
                    className="text-slate-400 hover:text-purple-600"
                    title="Adjust Stock"
                   >
                     <ClipboardList size={18} />
                   </button>
                   <button onClick={() => { setEditing(p); setForm(p); setIsModalOpen(true); }} className="text-slate-400 hover:text-blue-600"><Edit2 size={18} /></button>
                   <button onClick={() => { if(confirm('Delete?')) { db.deleteProduct(p.id); load(); } }} className="text-slate-400 hover:text-red-600"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
                <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">No products found.</td>
                </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl w-96 shadow-2xl">
            <h3 className="text-xl font-bold mb-4">{editing ? 'Edit' : 'Add'} Product</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input required className="w-full border p-2 rounded" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
              </div>
               <div>
                <label className="block text-sm font-medium mb-1">Unit</label>
                <select className="w-full border p-2 rounded" value={form.unit} onChange={e => setForm({...form, unit: e.target.value})}>
                  <option>PCS</option><option>KG</option><option>BOX</option><option>MTR</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                    <label className="block text-sm font-medium mb-1">Price (₹)</label>
                    <input type="number" required className="w-full border p-2 rounded" value={form.price} onChange={e => setForm({...form, price: parseFloat(e.target.value)})} />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1">Stock</label>
                    <input type="number" required className="w-full border p-2 rounded" value={form.stock} onChange={e => setForm({...form, stock: parseFloat(e.target.value)})} />
                </div>
              </div>
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-slate-200 py-2 rounded hover:bg-slate-300">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustingProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl w-96 shadow-2xl">
            <h3 className="text-xl font-bold mb-1">Adjust Stock</h3>
            <p className="text-sm text-slate-500 mb-4">Product: {adjustingProduct.name} (Current: {adjustingProduct.stock})</p>
            
            <form onSubmit={handleStockAdjustment} className="space-y-4">
              <div className="flex bg-slate-100 p-1 rounded">
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'INCREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'INCREASE' ? 'bg-green-500 text-white shadow' : 'text-slate-500'}`}
                >
                  <ArrowUp size={16} /> Add Stock
                </button>
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'DECREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'DECREASE' ? 'bg-red-500 text-white shadow' : 'text-slate-500'}`}
                >
                   <ArrowDown size={16} /> Reduce Stock
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input required type="number" min="0" className="w-full border p-2 rounded" value={adjForm.qty} onChange={e => setAdjForm({...adjForm, qty: parseFloat(e.target.value)})} />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Reason (Audit Mandatory)</label>
                <textarea 
                  required 
                  className="w-full border p-2 rounded" 
                  placeholder="e.g. Damaged goods, Found extra stock..."
                  value={adjForm.reason} 
                  onChange={e => setAdjForm({...adjForm, reason: e.target.value})}
                  rows={2}
                ></textarea>
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setAdjustingProduct(null)} className="flex-1 bg-slate-200 py-2 rounded hover:bg-slate-300">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save Adjustment</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};