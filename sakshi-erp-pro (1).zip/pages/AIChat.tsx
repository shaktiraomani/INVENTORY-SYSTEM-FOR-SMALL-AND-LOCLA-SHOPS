import React, { useState } from 'react';
import { Send, Sparkles } from 'lucide-react';
import { askAI } from '../services/aiService';

export const AIChatPage: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if(!prompt) return;
    
    setLoading(true);
    setResponse('');
    const answer = await askAI(prompt);
    setResponse(answer);
    setLoading(false);
  };

  const suggestions = [
    "What is my total sales this month?",
    "Who is my top customer?",
    "Which product is low on stock?",
    "Draft a payment reminder for customers with due balance."
  ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white shadow-lg">
        <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-white/20 rounded-full backdrop-blur-sm">
                <Sparkles size={24} className="text-yellow-300" />
            </div>
            <div>
                <h2 className="text-2xl font-bold">Sakshi AI Assistant</h2>
                <p className="text-blue-100">Ask anything about your business data.</p>
            </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border p-6 min-h-[400px] flex flex-col">
          <div className="flex-1 space-y-4 mb-6">
             {!response && !loading && (
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8">
                     {suggestions.map((s, i) => (
                         <button key={i} onClick={() => setPrompt(s)} className="p-4 border rounded-xl hover:bg-slate-50 text-left text-sm text-slate-600 transition">
                             {s}
                         </button>
                     ))}
                 </div>
             )}
             
             {loading && (
                 <div className="flex items-center justify-center h-full text-slate-400 gap-2">
                     <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                     Analyzing data...
                 </div>
             )}

             {response && (
                 <div className="bg-slate-50 p-6 rounded-xl border border-slate-200 prose prose-slate max-w-none">
                     <p className="whitespace-pre-wrap">{response}</p>
                 </div>
             )}
          </div>

          <form onSubmit={handleAsk} className="relative">
              <input 
                type="text" 
                className="w-full border-2 border-slate-200 rounded-xl p-4 pr-14 focus:border-blue-500 outline-none transition"
                placeholder="Ask me anything..."
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
              />
              <button 
                disabled={loading}
                type="submit" 
                className="absolute right-2 top-2 bottom-2 bg-blue-600 text-white p-2 rounded-lg hover:bg-blue-700 disabled:opacity-50"
              >
                  <Send size={20} />
              </button>
          </form>
      </div>
    </div>
  );
};