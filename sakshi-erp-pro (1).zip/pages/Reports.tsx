import React, { useState, useEffect } from 'react';
import { Printer, CreditCard, Receipt, Edit, Mail, Download, FileDown } from 'lucide-react';
import { Invoice, PrintOptions, Transaction, Party } from '../types';
import * as db from '../services/db';
import { InvoiceTemplate } from '../components/InvoiceTemplate';

interface ReportsPageProps {
  onEdit?: (invoice: Invoice) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ onEdit }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [search, setSearch] = useState('');
  
  // Tab State: 'invoices' or 'transactions'
  const [activeTab, setActiveTab] = useState<'invoices' | 'transactions'>('invoices');
  
  // Invoice Filter: 'ALL' | 'SALE' | 'PURCHASE'
  const [filterType, setFilterType] = useState<'ALL' | 'SALE' | 'PURCHASE'>('ALL');

  // Print Modal State for Reprinting
  const [printingInvoice, setPrintingInvoice] = useState<Invoice | null>(null);
  const [printConfig, setPrintConfig] = useState<PrintOptions>({
    template: 'standard',
    showQr: true,
    showTerms: true,
    showHeader: true,
    showFooter: true
  });
  const [settings] = useState(db.getSettings());

  useEffect(() => {
    setInvoices(db.getInvoices());
    setTransactions(db.getTransactions());
    setParties(db.getParties());
  }, []);

  const handleEmail = (invoice: Invoice) => {
    const party = parties.find(p => p.id === invoice.partyId);
    if (!party?.email) {
      alert('No email address found for this party. Please update party details.');
      return;
    }
    
    const subject = `${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} - ${settings.businessName}`;
    const body = `Dear ${party.name},\n\nPlease find the details below for ${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} dated ${invoice.date}.\n\nTotal Amount: ${invoice.totalAmount}\nPaid Amount: ${invoice.paidAmount}\n\nThank you,\n${settings.businessName}`;
    
    window.open(`mailto:${party.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = inv.partyName.toLowerCase().includes(search.toLowerCase()) || 
                          inv.id.includes(search) ||
                          (inv.referenceNo && inv.referenceNo.includes(search));
    const matchesType = filterType === 'ALL' || inv.type === filterType;
    return matchesSearch && matchesType;
  });

  const filteredTransactions = transactions.filter(t => 
    t.partyName.toLowerCase().includes(search.toLowerCase()) ||
    t.note?.toLowerCase().includes(search.toLowerCase())
  );

  const handleExport = () => {
    let headers: string[] = [];
    let data: (string | number)[][] = [];
    let filename = '';

    if (activeTab === 'invoices') {
      headers = ['Date', 'Invoice ID', 'Reference', 'Party Name', 'Type', 'Total Amount', 'Paid Amount', 'Due Amount'];
      data = filteredInvoices.map(inv => [
        inv.date,
        inv.id,
        inv.referenceNo || '',
        inv.partyName,
        inv.type,
        inv.totalAmount,
        inv.paidAmount,
        (inv.totalAmount - inv.paidAmount)
      ]);
      filename = `SakshiERP_Invoices_${new Date().toISOString().split('T')[0]}.csv`;
    } else {
      headers = ['Date', 'Party Name', 'Type', 'Note', 'Amount'];
      data = filteredTransactions.map(t => [
        t.date,
        t.partyName,
        t.type,
        t.note || '',
        t.amount
      ]);
      filename = `SakshiERP_Transactions_${new Date().toISOString().split('T')[0]}.csv`;
    }

    const csvContent = [
      headers.join(','),
      ...data.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadPdf = () => {
    const element = document.getElementById('print-area');
    if (!element || !printingInvoice) return;

    let jsPdfFormat: any = 'a4';
    if (printConfig.template === 'thermal') {
        jsPdfFormat = [80, 297];
    }

    const opt = {
      margin: 2,
      filename: `Invoice_${printingInvoice.id}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: jsPdfFormat, orientation: 'portrait' }
    };

    // @ts-ignore
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert('PDF library not loaded.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Sales</h4>
              <p className="text-2xl font-bold text-blue-600 mt-2">
                  ₹ {invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + curr.totalAmount, 0).toLocaleString()}
              </p>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Purchase</h4>
               <p className="text-2xl font-bold text-purple-600 mt-2">
                  ₹ {invoices.filter(i => i.type === 'PURCHASE').reduce((acc, curr) => acc + curr.totalAmount, 0).toLocaleString()}
              </p>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Due</h4>
               <p className="text-2xl font-bold text-red-600 mt-2">
                  ₹ {invoices.reduce((acc, curr) => acc + (curr.totalAmount - curr.paidAmount), 0).toLocaleString()}
              </p>
          </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-50 flex flex-col lg:flex-row justify-between items-center gap-4">
            <div className="flex gap-4 items-center w-full lg:w-auto">
                <div className="flex space-x-2 bg-slate-200 p-1 rounded-lg">
                    <button 
                    onClick={() => setActiveTab('invoices')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'invoices' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <Receipt size={16} /> Invoices / PO
                    </button>
                    <button 
                    onClick={() => setActiveTab('transactions')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'transactions' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <CreditCard size={16} /> Payments
                    </button>
                </div>
                
                {activeTab === 'invoices' && (
                    <div className="flex bg-slate-100 rounded-lg p-1 border">
                        <button onClick={() => setFilterType('ALL')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'ALL' ? 'bg-white shadow text-slate-800' : 'text-slate-400'}`}>All</button>
                        <button onClick={() => setFilterType('SALE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'SALE' ? 'bg-blue-100 text-blue-700' : 'text-slate-400'}`}>Sales</button>
                        <button onClick={() => setFilterType('PURCHASE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'PURCHASE' ? 'bg-purple-100 text-purple-700' : 'text-slate-400'}`}>Purchases</button>
                    </div>
                )}
            </div>

            <div className="flex gap-2 w-full lg:w-auto items-center">
                 <input 
                    type="text" 
                    placeholder={activeTab === 'invoices' ? "Search Invoice #, Party..." : "Search Party, Note..."}
                    className="flex-1 border p-2 rounded text-sm w-full lg:w-64 outline-none focus:ring-1 focus:ring-blue-500"
                    value={search}
                    onChange={e => setSearch(e.target.value)}
                />
                <button 
                    onClick={handleExport}
                    className="bg-white border border-slate-300 text-slate-700 p-2 rounded hover:bg-slate-50 transition"
                    title="Export to CSV"
                >
                    <Download size={20} />
                </button>
            </div>
        </div>

        {activeTab === 'invoices' ? (
          <table className="w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-500">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Invoice #</th>
                      <th className="p-4">Ref #</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4 text-right">Total</th>
                      <th className="p-4 text-right">Paid</th>
                      <th className="p-4 text-right">Due</th>
                      <th className="p-4 text-center">Action</th>
                  </tr>
              </thead>
              <tbody className="divide-y">
                  {filteredInvoices.map(inv => (
                      <tr key={inv.id} className="hover:bg-slate-50">
                          <td className="p-4">{inv.date}</td>
                          <td className="p-4 font-mono text-xs text-slate-500">{inv.id.substring(0, 8)}</td>
                          <td className="p-4 text-xs font-mono">{inv.referenceNo || '-'}</td>
                          <td className="p-4 font-medium">{inv.partyName}</td>
                           <td className="p-4">
                               <span className={`text-xs px-2 py-1 rounded font-bold ${inv.type === 'SALE' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                                   {inv.type === 'SALE' ? 'SALE' : 'PURCHASE'}
                               </span>
                           </td>
                          <td className="p-4 text-right font-medium">₹ {inv.totalAmount}</td>
                          <td className="p-4 text-right text-green-600">₹ {inv.paidAmount}</td>
                          <td className="p-4 text-right text-red-500 font-bold">
                              {inv.totalAmount - inv.paidAmount > 0 ? `₹ ${inv.totalAmount - inv.paidAmount}` : '-'}
                          </td>
                          <td className="p-4 text-center flex justify-center gap-2">
                              {onEdit && (
                                <button onClick={() => onEdit(inv)} className="text-slate-500 hover:text-blue-600" title="Edit">
                                    <Edit size={18} />
                                </button>
                              )}
                              <button onClick={() => handleEmail(inv)} className="text-slate-500 hover:text-indigo-600" title="Email Invoice">
                                  <Mail size={18} />
                              </button>
                              <button onClick={() => setPrintingInvoice(inv)} className="text-slate-500 hover:text-black" title="Print">
                                  <Printer size={18} />
                              </button>
                          </td>
                      </tr>
                  ))}
                  {filteredInvoices.length === 0 && (
                    <tr><td colSpan={9} className="p-8 text-center text-slate-400">No records found.</td></tr>
                  )}
              </tbody>
          </table>
        ) : (
          <table className="w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-500">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4">Note</th>
                      <th className="p-4 text-right">Amount</th>
                  </tr>
              </thead>
              <tbody className="divide-y">
                  {filteredTransactions.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50">
                          <td className="p-4 text-slate-500">{t.date}</td>
                          <td className="p-4 font-medium">{t.partyName}</td>
                          <td className="p-4">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                  {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                              </span>
                          </td>
                          <td className="p-4 text-slate-500 italic max-w-xs truncate">{t.note || '-'}</td>
                          <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600' : 'text-red-600'}`}>
                              {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                          </td>
                      </tr>
                  ))}
                  {filteredTransactions.length === 0 && (
                    <tr><td colSpan={5} className="p-8 text-center text-slate-400">No transactions found.</td></tr>
                  )}
              </tbody>
          </table>
        )}
      </div>

      {/* REPRINT MODAL */}
      {printingInvoice && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-100 rounded-xl w-full max-w-6xl h-[90vh] flex overflow-hidden">
                <div className="w-80 bg-white border-r p-6 flex flex-col overflow-y-auto no-print">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold flex items-center gap-2"><Printer /> Reprint</h2>
                    </div>
                    
                    <div className="space-y-6 flex-1">
                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block">Template</label>
                            <div className="grid grid-cols-1 gap-2">
                                {(['standard', 'thermal', 'modern'] as const).map(t => (
                                    <button 
                                        key={t}
                                        onClick={() => setPrintConfig({...printConfig, template: t})}
                                        className={`px-4 py-3 rounded text-left capitalize border transition ${printConfig.template === t ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white hover:bg-slate-50'}`}
                                    >
                                        {t} Layout
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block">Options</label>
                             <div className="space-y-3">
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showHeader} onChange={e => setPrintConfig({...printConfig, showHeader: e.target.checked})} />
                                    <span>Show Header</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showFooter} onChange={e => setPrintConfig({...printConfig, showFooter: e.target.checked})} />
                                    <span>Show Footer</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showQr} onChange={e => setPrintConfig({...printConfig, showQr: e.target.checked})} />
                                    <span>Show UPI QR</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showTerms} onChange={e => setPrintConfig({...printConfig, showTerms: e.target.checked})} />
                                    <span>Show Terms</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div className="mt-6 pt-6 border-t space-y-3">
                        <button 
                            onClick={() => window.print()} 
                            className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-blue-700"
                        >
                            <Printer size={20} /> Print Invoice
                        </button>
                        <button 
                            onClick={handleDownloadPdf}
                            className="w-full bg-green-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-green-700"
                        >
                            <FileDown size={20} /> Save as PDF
                        </button>
                        <button 
                            onClick={() => setPrintingInvoice(null)} 
                            className="w-full bg-white border border-slate-300 text-slate-700 py-3 rounded-lg font-bold hover:bg-slate-50"
                        >
                            Close
                        </button>
                    </div>
                </div>

                <div className="flex-1 bg-slate-500 overflow-auto p-8 flex justify-center">
                    <div className="shadow-2xl h-fit">
                        <div id="print-area" className="bg-white">
                            <InvoiceTemplate 
                                invoice={printingInvoice} 
                                settings={settings}
                                options={printConfig}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};