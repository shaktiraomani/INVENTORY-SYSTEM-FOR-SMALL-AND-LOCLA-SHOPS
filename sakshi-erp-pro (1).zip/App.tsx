import React, { useState, useEffect } from 'react';
import { Layout } from './components/Layout';
import { PartiesPage } from './pages/Parties';
import { ProductsPage } from './pages/Products';
import { BillingPage } from './pages/Billing';
import { PaymentsPage } from './pages/Payments';
import { ReportsPage } from './pages/Reports';
import { SettingsPage } from './pages/Settings';
import { AIChatPage } from './pages/AIChat';
import { TrendingUp, TrendingDown, AlertTriangle, Users, Wallet, Loader2 } from 'lucide-react';
import * as db from './services/db';
import { Invoice, Party } from './types';

const Dashboard: React.FC<{ onChangeTab: (t: string) => void }> = ({ onChangeTab }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [lowStockCount, setLowStockCount] = useState(0);

  useEffect(() => {
    setInvoices(db.getInvoices());
    setParties(db.getParties());
    setLowStockCount(db.getLowStockProducts(10).length);
  }, []);

  const totalSales = invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + curr.totalAmount, 0);
  const totalPurchase = invoices.filter(i => i.type === 'PURCHASE').reduce((acc, curr) => acc + curr.totalAmount, 0);
  const totalReceivable = parties.filter(p => p.balance > 0).reduce((acc, curr) => acc + curr.balance, 0);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">Business Overview</h2>
        <p className="text-slate-500">Welcome back, here is what is happening today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Sales Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Total Sales</p>
            <h3 className="text-2xl font-bold text-slate-800">₹ {totalSales.toLocaleString()}</h3>
            <span className="text-xs text-green-500 font-medium flex items-center gap-1 mt-2">
              <TrendingUp size={14} /> All time
            </span>
          </div>
          <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
             <TrendingUp size={24} />
          </div>
        </div>

        {/* Purchase Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Total Purchases</p>
            <h3 className="text-2xl font-bold text-slate-800">₹ {totalPurchase.toLocaleString()}</h3>
            <span className="text-xs text-purple-500 font-medium flex items-center gap-1 mt-2">
              <TrendingDown size={14} /> All time
            </span>
          </div>
          <div className="p-3 bg-purple-50 rounded-xl text-purple-600">
             <TrendingDown size={24} />
          </div>
        </div>

        {/* Receivables Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Total Receivable</p>
            <h3 className="text-2xl font-bold text-slate-800">₹ {totalReceivable.toLocaleString()}</h3>
            <span className="text-xs text-orange-500 font-medium flex items-center gap-1 mt-2">
              <Users size={14} /> Pending from parties
            </span>
          </div>
          <div className="p-3 bg-orange-50 rounded-xl text-orange-600">
             <Wallet size={24} />
          </div>
        </div>

        {/* Low Stock Card */}
        <div 
          onClick={() => onChangeTab('products')}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between cursor-pointer hover:border-red-200 transition"
        >
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Low Stock Alerts</p>
            <h3 className="text-2xl font-bold text-slate-800">{lowStockCount}</h3>
            <span className="text-xs text-red-500 font-medium flex items-center gap-1 mt-2">
              <AlertTriangle size={14} /> Items below limit
            </span>
          </div>
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
             <AlertTriangle size={24} />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="font-bold text-lg mb-4">Recent Sales</h3>
             <div className="space-y-4">
                 {invoices.filter(i => i.type === 'SALE').slice(0, 5).map(inv => (
                     <div key={inv.id} className="flex justify-between items-center pb-4 border-b last:border-0 last:pb-0">
                         <div>
                             <p className="font-medium text-slate-800">{inv.partyName}</p>
                             <p className="text-xs text-slate-400">{inv.date}</p>
                         </div>
                         <div className="text-right">
                             <p className="font-bold text-blue-600">₹ {inv.totalAmount}</p>
                             <p className="text-xs text-slate-400">{inv.items.length} items</p>
                         </div>
                     </div>
                 ))}
                 {invoices.filter(i => i.type === 'SALE').length === 0 && <p className="text-slate-400 text-sm">No sales recorded yet.</p>}
             </div>
         </div>
         <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
             <h3 className="font-bold text-lg mb-4">Recent Purchases</h3>
             <div className="space-y-4">
                 {invoices.filter(i => i.type === 'PURCHASE').slice(0, 5).map(inv => (
                     <div key={inv.id} className="flex justify-between items-center pb-4 border-b last:border-0 last:pb-0">
                         <div>
                             <p className="font-medium text-slate-800">{inv.partyName}</p>
                             <p className="text-xs text-slate-400">{inv.date}</p>
                         </div>
                         <div className="text-right">
                             <p className="font-bold text-purple-600">₹ {inv.totalAmount}</p>
                             <p className="text-xs text-slate-400">{inv.items.length} items</p>
                         </div>
                     </div>
                 ))}
                 {invoices.filter(i => i.type === 'PURCHASE').length === 0 && <p className="text-slate-400 text-sm">No purchases recorded yet.</p>}
             </div>
         </div>
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  
  // Edit Invoice State
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);

  useEffect(() => {
    // Initial Data Fetch
    db.initDB().then(() => {
      setLoading(false);
    });
  }, []);

  const handleEditInvoice = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setActiveTab('billing');
  };

  const renderContent = () => {
    switch(activeTab) {
      case 'dashboard': return <Dashboard onChangeTab={setActiveTab} />;
      case 'parties': return <PartiesPage />;
      case 'products': return <ProductsPage />;
      case 'billing': return (
        <BillingPage 
          initialInvoice={editingInvoice} 
          onClear={() => setEditingInvoice(null)} 
        />
      );
      case 'payments': return <PaymentsPage />;
      case 'reports': return <ReportsPage onEdit={handleEditInvoice} />;
      case 'ai': return <AIChatPage />;
      case 'settings': return <SettingsPage />;
      default: return <Dashboard onChangeTab={setActiveTab} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center text-slate-600">
        <Loader2 className="animate-spin text-blue-600 mb-4" size={48} />
        <h2 className="text-xl font-bold">Sakshi ERP Pro</h2>
        <p className="text-sm">Connecting to cloud database...</p>
      </div>
    );
  }

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}