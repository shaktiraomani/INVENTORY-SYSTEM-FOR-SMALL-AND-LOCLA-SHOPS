
export enum PartyType {
  CUSTOMER = 'CUSTOMER',
  SUPPLIER = 'SUPPLIER'
}

export interface Party {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  type: PartyType;
  balance: number; // Positive = Receivable, Negative = Payable
  gstin?: string;
}

export interface ProductVariant {
  id: string;
  name: string; // e.g. "Size S - Red"
  price: number;
  buyPrice: number;
  stock: number;
}

export interface Product {
  id: string;
  name: string;
  buyPrice: number; // Purchase Rate (Cost) - Base or Default
  price: number;    // Sale Rate (MRP/Selling Price) - Base or Default
  unit: string;
  stock: number;    // Base stock if no variants, or Total stock if variants exist (calculated)
  hsn?: string;
  gstRate?: number; // percentage (0, 5, 12, 18, 28)
  variants?: ProductVariant[]; // New: Support for variants
}

export enum PaymentMethod {
  CASH = 'CASH',
  ONLINE = 'ONLINE', // UPI/Bank
  CREDIT = 'CREDIT'
}

export interface CartItem extends Product {
  qty: number;
  discount: number; // Value
  discountType: 'PERCENT' | 'AMOUNT'; // New: Type of discount
  total: number;
  taxableValue?: number;
  gstAmount?: number;
  variantId?: string; // New: specific variant ID if applicable
}

export interface Invoice {
  id: string;
  date: string;
  partyId: string;
  partyName: string;
  items: CartItem[];
  totalAmount: number;
  paidAmount: number;
  paymentMethod: PaymentMethod;
  type: 'SALE' | 'PURCHASE';
  referenceNo?: string; // Supplier Invoice # or External Ref
  gstin?: string; // Party GSTIN at time of invoice
  taxType?: 'INTRA' | 'INTER' | 'NONE'; // Added NONE
}

export interface Transaction {
  id: string;
  date: string;
  partyId: string;
  partyName: string;
  amount: number;
  type: 'PAYMENT_IN' | 'PAYMENT_OUT';
  note: string;
  invoiceId?: string; // Link to specific invoice
}

export interface StockAdjustment {
  id: string;
  date: string;
  productId: string;
  productName: string;
  variantId?: string; // New: Adjust specific variant
  variantName?: string;
  type: 'INCREASE' | 'DECREASE';
  qty: number;
  reason: string;
}

// Configuration for the user
export interface UserSettings {
  businessName: string;
  address: string;
  phone: string;
  upiId: string;
  gstin?: string;
  logo?: string;
  footerText?: string; 
  // New Invoice Customization
  invoicePrefix?: string; // e.g., "INV-24-"
  invoiceStartSequence?: number; // e.g. 1001
  availableGstRates?: number[];
}

export type PrintTemplate = 'standard' | 'thermal' | 'modern';

export interface PrintOptions {
  template: PrintTemplate;
  showQr: boolean;
  showTerms: boolean;
  showHeader: boolean;
  showFooter: boolean;
}

// Google Apps Script Types
declare global {
  interface Window {
    html2pdf: () => {
      set: (opt: any) => any;
      from: (element: HTMLElement | null) => any;
      save: () => void;
    };
    google?: {
      script: {
        run: {
          withSuccessHandler: (callback: (data: any) => void) => any;
          withFailureHandler: (callback: (error: any) => void) => any;
          [key: string]: any;
        };
      };
    };
  }
}
