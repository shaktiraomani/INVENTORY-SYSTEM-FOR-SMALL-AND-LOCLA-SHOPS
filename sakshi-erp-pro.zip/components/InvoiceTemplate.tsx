
import React, { useEffect, useState } from 'react';
import { Invoice, UserSettings, PrintOptions } from '../types';
import QRCode from 'qrcode';

interface Props {
  invoice: Invoice;
  settings: UserSettings;
  options: PrintOptions;
}

export const InvoiceTemplate: React.FC<Props> = ({ invoice, settings, options }) => {
  const [qrUrl, setQrUrl] = useState('');

  const isSale = invoice.type === 'SALE';
  const docTitle = isSale ? 'INVOICE' : 'PURCHASE ORDER';
  const partyLabel = isSale ? 'Billed To' : 'Vendor / Supplier';
  const isInterState = invoice.taxType === 'INTER';
  const isNoTax = invoice.taxType === 'NONE';

  useEffect(() => {
    if (isSale && settings.upiId && options.showQr) {
      const upiString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.businessName)}&am=${invoice.totalAmount}&tr=${invoice.id}&tn=Bill%20${invoice.id}`;
      QRCode.toDataURL(upiString).then(setQrUrl).catch(console.error);
    }
  }, [invoice, settings, options.showQr, isSale]);

  const totalDiscount = invoice.items.reduce((acc, item) => {
    const gross = item.price * item.qty;
    let discAmt = item.discountType === 'PERCENT' ? (gross * item.discount) / 100 : item.discount;
    return acc + discAmt;
  }, 0);

  const totalTaxAmt = invoice.items.reduce((acc, item) => acc + (item.gstAmount || 0), 0);

  // --- TEMPLATE: STANDARD (A4) ---
  return (
    <div className="max-w-[210mm] mx-auto p-8 bg-white border min-h-[297mm]">
      {options.showHeader && (
        <header className="flex justify-between items-center border-b-2 border-slate-800 pb-6 mb-8">
            <div>
                <h1 className="text-3xl font-bold uppercase tracking-tight">{settings.businessName}</h1>
                <div className="text-sm mt-2 text-slate-600 whitespace-pre-line">{settings.address}</div>
                <div className="text-sm text-slate-600">Ph: {settings.phone}</div>
            </div>
            <div className="text-right">
                <div className="text-4xl font-extrabold text-slate-200 uppercase">
                    {docTitle}
                </div>
                <table className="text-right ml-auto mt-2 text-sm">
                    <tbody>
                        <tr><td className="pr-4 text-slate-500">No:</td><td className="font-bold">{invoice.id}</td></tr>
                        <tr><td className="pr-4 text-slate-500">Date:</td><td className="font-bold">{invoice.date}</td></tr>
                        {invoice.referenceNo && (
                             <tr><td className="pr-4 text-slate-500">Ref:</td><td className="font-bold">{invoice.referenceNo}</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        </header>
      )}

      <div className="flex justify-between mb-8">
        <div className="w-1/2">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">{partyLabel}</h3>
            <div className="font-bold text-lg">{invoice.partyName}</div>
            <div className="text-sm text-slate-600">ID: {invoice.partyId}</div>
            {invoice.gstin && <div className="text-sm text-slate-600">GSTIN: {invoice.gstin}</div>}
        </div>
      </div>

      <table className="w-full mb-8 border-collapse">
        <thead>
            <tr className="bg-slate-100 text-slate-600 text-sm uppercase">
                <th className="p-3 text-left border-y">Item</th>
                <th className="p-3 text-right border-y">Price</th>
                <th className="p-3 text-center border-y">Qty</th>
                <th className="p-3 text-right border-y">Disc</th>
                { !isNoTax && (
                    <>
                        <th className="p-3 text-right border-y">Taxable</th>
                        {isInterState ? (
                            <th className="p-3 text-right border-y">IGST</th>
                        ) : (
                            <>
                                <th className="p-3 text-right border-y">CGST</th>
                                <th className="p-3 text-right border-y">SGST</th>
                            </>
                        )}
                    </>
                )}
                <th className="p-3 text-right border-y">Total</th>
            </tr>
        </thead>
        <tbody>
            {invoice.items.map((item, idx) => {
                const taxAmt = item.gstAmount || 0;
                const rate = item.gstRate || 0;
                return (
                    <tr key={idx} className="border-b">
                        <td className="p-3 font-medium">{item.name}</td>
                        <td className="p-3 text-right">{item.price.toFixed(2)}</td>
                        <td className="p-3 text-center">{item.qty}</td>
                        <td className="p-3 text-right text-slate-500">
                            {item.discountType === 'PERCENT' && item.discount > 0 ? `${item.discount}%` : (item.discount > 0 ? item.discount : '-')}
                        </td>
                        { !isNoTax && (
                            <>
                                <td className="p-3 text-right">{item.taxableValue?.toFixed(2)}</td>
                                {isInterState ? (
                                    <td className="p-3 text-right">
                                        <div>{taxAmt.toFixed(2)}</div>
                                        <div className="text-[10px] text-slate-400">@{rate}%</div>
                                    </td>
                                ) : (
                                    <>
                                        <td className="p-3 text-right">
                                            <div>{(taxAmt/2).toFixed(2)}</div>
                                            <div className="text-[10px] text-slate-400">@{rate/2}%</div>
                                        </td>
                                        <td className="p-3 text-right">
                                            <div>{(taxAmt/2).toFixed(2)}</div>
                                            <div className="text-[10px] text-slate-400">@{rate/2}%</div>
                                        </td>
                                    </>
                                )}
                            </>
                        )}
                        <td className="p-3 text-right font-bold">{item.total.toFixed(2)}</td>
                    </tr>
                );
            })}
        </tbody>
        <tfoot>
            {totalDiscount > 0 && (
                <tr>
                    <td colSpan={isNoTax ? 4 : (isInterState ? 6 : 7)} className="p-3 text-right text-slate-500">Total Discount</td>
                    <td className="p-3 text-right text-green-600 font-bold">- ₹ {totalDiscount.toFixed(2)}</td>
                </tr>
            )}
            { !isNoTax && (
                <tr>
                    <td colSpan={isNoTax ? 4 : (isInterState ? 6 : 7)} className="p-3 text-right text-slate-500">Total Tax (GST)</td>
                    <td className="p-3 text-right font-bold">₹ {totalTaxAmt.toFixed(2)}</td>
                </tr>
            )}
            <tr>
                <td colSpan={isNoTax ? 4 : (isInterState ? 6 : 7)} className="p-3 text-right font-bold text-slate-600">Total Amount</td>
                <td className="p-3 text-right font-bold text-xl">₹ {invoice.totalAmount.toFixed(2)}</td>
            </tr>
            <tr>
                <td colSpan={isNoTax ? 4 : (isInterState ? 6 : 7)} className="p-3 text-right text-slate-500">Paid Amount</td>
                <td className="p-3 text-right text-green-600">₹ {invoice.paidAmount.toFixed(2)}</td>
            </tr>
            {invoice.totalAmount - invoice.paidAmount > 0 && (
                <tr>
                    <td colSpan={isNoTax ? 4 : (isInterState ? 6 : 7)} className="p-3 text-right text-slate-500">Balance Due</td>
                    <td className="p-3 text-right text-red-600 font-bold">₹ {(invoice.totalAmount - invoice.paidAmount).toFixed(2)}</td>
                </tr>
            )}
        </tfoot>
      </table>

      {options.showFooter && (
        <footer className="mt-auto pt-8 border-t flex flex-col justify-between text-xs text-slate-400">
            {settings.footerText && (
                <div className="w-full text-center border-b pb-4 mb-4 text-slate-600 whitespace-pre-wrap">
                    {settings.footerText}
                </div>
            )}
            <div className="flex justify-between items-center w-full">
                <div className="flex flex-col">
                     <span className="font-bold text-slate-600 mb-4">Authorized Signatory</span>
                     <div className="h-8 border-b w-32 mb-1"></div>
                     <span>For {settings.businessName}</span>
                </div>
            </div>
        </footer>
      )}
    </div>
  );
};
