import React, { useEffect, useState } from 'react';
import { Invoice, UserSettings, PrintOptions } from '../types';
import QRCode from 'qrcode';

interface Props {
  invoice: Invoice;
  settings: UserSettings;
  options: PrintOptions;
}

export const InvoiceTemplate: React.FC<Props> = ({ invoice, settings, options }) => {
  const [qrUrl, setQrUrl] = useState('');

  const isSale = invoice.type === 'SALE';
  const docTitle = isSale ? 'INVOICE' : 'PURCHASE ORDER';
  const partyLabel = isSale ? 'Billed To' : 'Vendor / Supplier';

  useEffect(() => {
    if (isSale && settings.upiId && options.showQr) {
      const upiString = `upi://pay?pa=${settings.upiId}&pn=${encodeURIComponent(settings.businessName)}&am=${invoice.totalAmount}&tr=${invoice.id}&tn=Bill%20${invoice.id}`;
      QRCode.toDataURL(upiString).then(setQrUrl).catch(console.error);
    }
  }, [invoice, settings, options.showQr, isSale]);

  const totalDiscount = invoice.items.reduce((acc, item) => {
    const originalTotal = item.price * item.qty;
    return acc + (originalTotal - item.total);
  }, 0);

  // --- TEMPLATE: THERMAL (POS) ---
  if (options.template === 'thermal') {
    return (
      <div className="font-mono text-xs max-w-[80mm] mx-auto p-2 bg-white text-black">
        {options.showHeader && (
          <div className="text-center mb-4 border-b pb-2 border-black border-dashed">
            <h1 className="font-bold text-lg uppercase">{settings.businessName}</h1>
            <p>{settings.address}</p>
            <p>Ph: {settings.phone}</p>
          </div>
        )}
        
        <div className="mb-2">
            <div className="flex justify-between">
                <span>Date: {invoice.date}</span>
                <span>#{invoice.id.substring(0,6)}</span>
            </div>
            {invoice.referenceNo && (
                <div className="font-bold">Ref: {invoice.referenceNo}</div>
            )}
            <div className="mt-1 font-bold">{invoice.partyName}</div>
            {!isSale && <div className="text-[10px] uppercase">(Supplier)</div>}
        </div>

        <table className="w-full text-left mb-2 border-b border-black border-dashed pb-2">
            <thead>
                <tr>
                    <th className="py-1">Item</th>
                    <th className="text-right py-1">Qty</th>
                    <th className="text-right py-1">Amt</th>
                </tr>
            </thead>
            <tbody>
                {invoice.items.map((item, i) => (
                    <tr key={i}>
                        <td className="py-1">
                          {item.name}
                          {item.discount > 0 && <span className="block text-[10px] italic">(-{item.discount}%)</span>}
                        </td>
                        <td className="text-right py-1">{item.qty}</td>
                        <td className="text-right py-1">{item.total.toFixed(0)}</td>
                    </tr>
                ))}
            </tbody>
        </table>

        <div className="flex justify-between font-bold text-sm mb-1">
            <span>TOTAL</span>
            <span>{invoice.totalAmount.toFixed(2)}</span>
        </div>
        
        {totalDiscount > 0 && (
             <div className="flex justify-between text-xs mb-4 text-slate-600 italic">
                <span>You Saved:</span>
                <span>{totalDiscount.toFixed(2)}</span>
            </div>
        )}

        {options.showQr && qrUrl && isSale && (
            <div className="flex justify-center mb-4">
                <img src={qrUrl} alt="QR" className="w-32 h-32" />
            </div>
        )}

        {options.showFooter && (
             <div className="text-center text-[10px] mt-4 border-t border-black border-dashed pt-2">
                <p>Thank you for your business!</p>
            </div>
        )}
      </div>
    );
  }

  // --- TEMPLATE: MODERN ---
  if (options.template === 'modern') {
      return (
        <div className="max-w-[210mm] mx-auto p-8 bg-white min-h-[297mm] text-slate-800">
            {options.showHeader && (
                <div className="flex justify-between items-start mb-12">
                    <div>
                        <h1 className="text-4xl font-bold text-blue-600 mb-2">{settings.businessName}</h1>
                        <p className="text-slate-500 w-64">{settings.address}</p>
                        <p className="text-slate-500">{settings.phone}</p>
                    </div>
                    <div className="text-right">
                        <h2 className="text-3xl font-light uppercase tracking-widest text-slate-300">
                            {docTitle}
                        </h2>
                        <p className="font-mono text-lg mt-2">#{invoice.id}</p>
                        <p className="text-slate-500">{invoice.date}</p>
                        {invoice.referenceNo && <p className="text-sm font-bold bg-yellow-100 px-2 inline-block rounded">Ref: {invoice.referenceNo}</p>}
                    </div>
                </div>
            )}

            <div className="bg-slate-50 p-6 rounded-lg mb-8">
                <p className="text-xs font-bold uppercase text-slate-400 mb-2">{partyLabel}</p>
                <h3 className="text-xl font-bold">{invoice.partyName}</h3>
                <p className="text-slate-500">Party ID: {invoice.partyId}</p>
            </div>

            <table className="w-full mb-8">
                <thead className={isSale ? "bg-blue-600 text-white" : "bg-purple-600 text-white"}>
                    <tr>
                        <th className="p-3 text-left rounded-l-lg">Description</th>
                        <th className="p-3 text-center">Qty</th>
                        <th className="p-3 text-right">Price</th>
                        <th className="p-3 text-right">Disc %</th>
                        <th className="p-3 text-right rounded-r-lg">Total</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                    {invoice.items.map((item, i) => (
                        <tr key={i}>
                            <td className="p-3 font-medium">{item.name}</td>
                            <td className="p-3 text-center">{item.qty}</td>
                            <td className="p-3 text-right">{item.price.toFixed(2)}</td>
                            <td className="p-3 text-right text-slate-400">{item.discount || '-'}</td>
                            <td className="p-3 text-right font-bold">{item.total.toFixed(2)}</td>
                        </tr>
                    ))}
                </tbody>
            </table>

            <div className="flex justify-end mb-12">
                <div className="w-64 space-y-3">
                    <div className="flex justify-between text-slate-500">
                        <span>Subtotal</span>
                        <span>{(invoice.totalAmount + totalDiscount).toFixed(2)}</span>
                    </div>
                    {totalDiscount > 0 && (
                        <div className="flex justify-between text-slate-500">
                            <span>Discount</span>
                            <span className="text-green-600">- {totalDiscount.toFixed(2)}</span>
                        </div>
                    )}
                    <div className={`flex justify-between text-xl font-bold border-t pt-3 ${isSale ? 'text-blue-600' : 'text-purple-600'}`}>
                        <span>Total</span>
                        <span>₹ {invoice.totalAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-green-600">
                        <span>Paid</span>
                        <span>₹ {invoice.paidAmount.toFixed(2)}</span>
                    </div>
                </div>
            </div>

            <div className="flex justify-between items-end">
                <div>
                     {options.showTerms && (
                        <div className="text-xs text-slate-400 max-w-sm">
                            <h5 className="font-bold text-slate-600 mb-1">Terms & Conditions</h5>
                            <ol className="list-decimal pl-4 space-y-1">
                                <li>Goods once sold will not be taken back.</li>
                                <li>Interest @18% pa will be charged if not paid within due date.</li>
                            </ol>
                        </div>
                    )}
                </div>
                {options.showQr && qrUrl && isSale && (
                    <div className="text-center">
                        <img src={qrUrl} className="w-32 h-32 mb-2" />
                        <p className="text-xs text-slate-400">Scan to Pay</p>
                    </div>
                )}
            </div>
            
            {options.showFooter && (
                <div className="mt-12 pt-8 border-t text-center text-slate-400 text-sm">
                    Generated by Sakshi ERP Pro
                </div>
            )}
        </div>
      );
  }

  // --- TEMPLATE: STANDARD (A4) ---
  return (
    <div className="max-w-[210mm] mx-auto p-8 bg-white border min-h-[297mm]">
      {options.showHeader && (
        <header className="flex justify-between items-center border-b-2 border-slate-800 pb-6 mb-8">
            <div>
                <h1 className="text-3xl font-bold uppercase tracking-tight">{settings.businessName}</h1>
                <div className="text-sm mt-2 text-slate-600 whitespace-pre-line">{settings.address}</div>
                <div className="text-sm text-slate-600">Ph: {settings.phone}</div>
            </div>
            <div className="text-right">
                <div className="text-4xl font-extrabold text-slate-200 uppercase">
                    {docTitle}
                </div>
                <table className="text-right ml-auto mt-2 text-sm">
                    <tbody>
                        <tr><td className="pr-4 text-slate-500">No:</td><td className="font-bold">{invoice.id}</td></tr>
                        <tr><td className="pr-4 text-slate-500">Date:</td><td className="font-bold">{invoice.date}</td></tr>
                        {invoice.referenceNo && (
                             <tr><td className="pr-4 text-slate-500">Ref:</td><td className="font-bold">{invoice.referenceNo}</td></tr>
                        )}
                    </tbody>
                </table>
            </div>
        </header>
      )}

      <div className="flex justify-between mb-8">
        <div className="w-1/2">
            <h3 className="text-xs font-bold text-slate-400 uppercase mb-2">{partyLabel}</h3>
            <div className="font-bold text-lg">{invoice.partyName}</div>
            <div className="text-sm text-slate-600">ID: {invoice.partyId}</div>
        </div>
      </div>

      <table className="w-full mb-8 border-collapse">
        <thead>
            <tr className="bg-slate-100 text-slate-600 text-sm uppercase">
                <th className="p-3 text-left border-y">Item Description</th>
                <th className="p-3 text-right border-y">Price</th>
                <th className="p-3 text-right border-y">Qty</th>
                <th className="p-3 text-right border-y">Disc %</th>
                <th className="p-3 text-right border-y">Total</th>
            </tr>
        </thead>
        <tbody>
            {invoice.items.map((item, idx) => (
                <tr key={idx} className="border-b">
                    <td className="p-3 font-medium">{item.name}</td>
                    <td className="p-3 text-right">{item.price.toFixed(2)}</td>
                    <td className="p-3 text-right">{item.qty}</td>
                    <td className="p-3 text-right text-slate-500">{item.discount > 0 ? item.discount + '%' : '-'}</td>
                    <td className="p-3 text-right font-bold">{item.total.toFixed(2)}</td>
                </tr>
            ))}
        </tbody>
        <tfoot>
            {totalDiscount > 0 && (
                <tr>
                    <td colSpan={4} className="p-3 text-right text-slate-500">Total Discount</td>
                    <td className="p-3 text-right text-green-600 font-bold">- ₹ {totalDiscount.toFixed(2)}</td>
                </tr>
            )}
            <tr>
                <td colSpan={4} className="p-3 text-right font-bold text-slate-600">Total Amount</td>
                <td className="p-3 text-right font-bold text-xl">₹ {invoice.totalAmount.toFixed(2)}</td>
            </tr>
            <tr>
                <td colSpan={4} className="p-3 text-right text-slate-500">Paid Amount</td>
                <td className="p-3 text-right text-green-600">₹ {invoice.paidAmount.toFixed(2)}</td>
            </tr>
            {invoice.totalAmount - invoice.paidAmount > 0 && (
                <tr>
                    <td colSpan={4} className="p-3 text-right text-slate-500">Balance Due</td>
                    <td className="p-3 text-right text-red-600 font-bold">₹ {(invoice.totalAmount - invoice.paidAmount).toFixed(2)}</td>
                </tr>
            )}
        </tfoot>
      </table>

      <div className="flex gap-8 items-start">
         <div className="flex-1">
             {options.showTerms && (
                <div>
                    <h4 className="font-bold text-xs uppercase text-slate-400 mb-2">Terms & Conditions</h4>
                    <p className="text-xs text-slate-500">Payment is due upon receipt. Please include invoice number on your check.</p>
                </div>
            )}
         </div>
         {options.showQr && qrUrl && isSale && (
            <div className="text-center border p-2 rounded">
                <img src={qrUrl} className="w-24 h-24" />
                <p className="text-[10px] mt-1 uppercase font-bold text-slate-500">Scan UPI</p>
            </div>
         )}
      </div>

      {options.showFooter && (
        <footer className="mt-auto pt-8 border-t flex justify-between items-center text-xs text-slate-400">
            <div>Authorized Signatory</div>
            <div>{settings.businessName}</div>
        </footer>
      )}
    </div>
  );
};