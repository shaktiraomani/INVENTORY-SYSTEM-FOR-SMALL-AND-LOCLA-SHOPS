import { GoogleGenAI } from "@google/genai";
import { getInvoices, getParties, getProducts, getTransactions } from "./db";

export const askAI = async (prompt: string): Promise<string> => {
  if (!process.env.API_KEY) return "API Key not configured.";
  
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // Gather Context
  const context = {
    sales: getInvoices().slice(0, 50), // Send last 50 invoices for context
    products: getProducts(),
    parties: getParties(),
    transactions: getTransactions().slice(0, 50)
  };

  const fullPrompt = `
    You are the AI assistant for "Sakshi ERP Pro". 
    Analyze the following business data JSON: ${JSON.stringify(context)}.
    
    User Query: ${prompt}
    
    Keep the answer concise, professional, and actionable. 
    If asking about sales, calculate totals from the provided JSON.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: fullPrompt,
    });
    return response.text || "No response generated.";
  } catch (e) {
    console.error(e);
    return "Failed to fetch AI response. Please check your API key.";
  }
};