
import React, { useState, useEffect, useMemo } from 'react';
import { Layout } from './components/Layout';
import { PartiesPage } from './pages/Parties';
import { ProductsPage } from './pages/Products';
import { BillingPage } from './pages/Billing';
import { PaymentsPage } from './pages/Payments';
import { ReportsPage } from './pages/Reports';
import { SettingsPage } from './pages/Settings';
import { AIChatPage } from './pages/AIChat';
import { TrendingUp, TrendingDown, AlertTriangle, Users, Wallet, Loader2, BarChart2, IndianRupee } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import * as db from './services/db';
import { Invoice, Party } from './types';

// Define Interface for Chart Data
interface ChartData {
  name: string;
  monthIdx: number;
  year: number;
  Sales: number;
  Purchase: number;
}

const Dashboard: React.FC<{ onChangeTab: (t: string) => void }> = ({ onChangeTab }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [lowStockCount, setLowStockCount] = useState(0);

  useEffect(() => {
    setInvoices(db.getInvoices());
    setParties(db.getParties());
    setLowStockCount(db.getLowStockProducts(10).length);
  }, []);

  const totalSales = invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + curr.totalAmount, 0);
  const totalPurchase = invoices.filter(i => i.type === 'PURCHASE').reduce((acc, curr) => acc + curr.totalAmount, 0);
  
  // Calculate Cash vs Credit
  const totalCollected = invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + curr.paidAmount, 0);
  const totalUnpaidSales = invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + (curr.totalAmount - curr.paidAmount), 0);
  
  // Outstanding from Parties (General Ledger)
  const marketReceivable = parties.filter(p => p.balance > 0).reduce((acc, curr) => acc + curr.balance, 0);

  // Prepare Chart Data
  const chartData = useMemo(() => {
    const months: ChartData[] = [];
    const today = new Date();
    
    for (let i = 5; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      months.push({
        name: d.toLocaleString('default', { month: 'short', year: '2-digit' }),
        monthIdx: d.getMonth(),
        year: d.getFullYear(),
        Sales: 0,
        Purchase: 0
      });
    }

    invoices.forEach(inv => {
      const d = new Date(inv.date);
      const invMonth = d.getMonth();
      const invYear = d.getFullYear();
      
      const bucket = months.find(m => m.monthIdx === invMonth && m.year === invYear);
      if (bucket) {
        if (inv.type === 'SALE') bucket.Sales += inv.totalAmount;
        else bucket.Purchase += inv.totalAmount;
      }
    });

    return months;
  }, [invoices]);

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-slate-800">Business Overview</h2>
        <p className="text-slate-500">Welcome back, here is what is happening today.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Sales Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Total Sales</p>
            <h3 className="text-2xl font-bold text-slate-800">₹ {totalSales.toLocaleString()}</h3>
            <span className="text-xs text-green-500 font-medium flex items-center gap-1 mt-2">
              <TrendingUp size={14} /> Gross Revenue
            </span>
          </div>
          <div className="p-3 bg-blue-50 rounded-xl text-blue-600">
             <TrendingUp size={24} />
          </div>
        </div>

        {/* Cash Collected Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Cash Collected</p>
            <h3 className="text-2xl font-bold text-emerald-600">₹ {totalCollected.toLocaleString()}</h3>
            <span className="text-xs text-emerald-500 font-medium flex items-center gap-1 mt-2">
              <IndianRupee size={14} /> Money In Hand
            </span>
          </div>
          <div className="p-3 bg-emerald-50 rounded-xl text-emerald-600">
             <Wallet size={24} />
          </div>
        </div>

        {/* Unpaid / Credit Card */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between">
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Unpaid / Credit</p>
            <h3 className="text-2xl font-bold text-orange-600">₹ {marketReceivable.toLocaleString()}</h3>
            <span className="text-xs text-orange-500 font-medium flex items-center gap-1 mt-2">
              <Users size={14} /> Market Outstanding
            </span>
          </div>
          <div className="p-3 bg-orange-50 rounded-xl text-orange-600">
             <Users size={24} />
          </div>
        </div>

        {/* Low Stock Card */}
        <div 
          onClick={() => onChangeTab('products')}
          className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-start justify-between cursor-pointer hover:border-red-200 transition"
        >
          <div>
            <p className="text-sm font-medium text-slate-400 mb-1">Low Stock Alerts</p>
            <h3 className="text-2xl font-bold text-slate-800">{lowStockCount}</h3>
            <span className="text-xs text-red-500 font-medium flex items-center gap-1 mt-2">
              <AlertTriangle size={14} /> Items below limit
            </span>
          </div>
          <div className="p-3 bg-red-50 rounded-xl text-red-600">
             <AlertTriangle size={24} />
          </div>
        </div>
      </div>

      {/* CHART SECTION */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-bold text-lg flex items-center gap-2">
            <BarChart2 size={20} className="text-slate-400" />
            Monthly Trends
          </h3>
          <div className="text-xs text-slate-400">Last 6 Months</div>
        </div>
        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis 
                dataKey="name" 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#64748b', fontSize: 12 }} 
                dy={10}
              />
              <YAxis 
                axisLine={false} 
                tickLine={false} 
                tick={{ fill: '#64748b', fontSize: 12 }} 
              />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
              />
              <Legend iconType="circle" />
              <Bar dataKey="Sales" fill="#2563eb" radius={[4, 4, 0, 0]} barSize={30} name="Total Sales" />
              <Bar dataKey="Purchase" fill="#9333ea" radius={[4, 4, 0, 0]} barSize={30} name="Total Purchases" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loading, setLoading] = useState(true);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);

  useEffect(() => {
    db.initDB().then(() => setLoading(false));
  }, []);

  const handleEditInvoice = (invoice: Invoice) => {
    setEditingInvoice(invoice);
    setActiveTab('billing');
  };

  const renderContent = () => {
    switch(activeTab) {
      case 'dashboard': return <Dashboard onChangeTab={setActiveTab} />;
      case 'parties': return <PartiesPage />;
      case 'products': return <ProductsPage />;
      case 'billing': return (
        <BillingPage 
          initialInvoice={editingInvoice} 
          onClear={() => setEditingInvoice(null)} 
        />
      );
      case 'payments': return <PaymentsPage />;
      case 'reports': return <ReportsPage onEdit={handleEditInvoice} />;
      case 'ai': return <AIChatPage />;
      case 'settings': return <SettingsPage />;
      default: return <Dashboard onChangeTab={setActiveTab} />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center text-slate-600">
        <Loader2 className="animate-spin text-blue-600 mb-4" size={48} />
        <h2 className="text-xl font-bold">Sakshi ERP Pro</h2>
        <p className="text-sm">Connecting to cloud database...</p>
      </div>
    );
  }

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}
