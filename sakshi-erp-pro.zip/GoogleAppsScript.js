/**
 * SAKSHI ERP PRO - GOOGLE APPS SCRIPT BACKEND
 */

const SHEET_MAPPING = {
  'party': 'Parties',
  'product': 'Products',
  'invoice': 'Invoices',
  'transaction': 'Transactions',
  'setting': 'Settings'
};

/**
 * SERVES THE FRONTEND
 */
function doGet(e) {
  // Check if it's an API call or loading the UI
  if (e && e.parameter && e.parameter.op === 'getData') {
    return ContentService.createTextOutput(apiGetData())
      .setMimeType(ContentService.MimeType.JSON);
  }

  try {
    return HtmlService.createTemplateFromFile('index')
      .evaluate()
      .setTitle('Sakshi ERP Pro')
      .addMetaTag('viewport', 'width=device-width, initial-scale=1')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  } catch (err) {
    return ContentService.createTextOutput("Error: 'index.html' not found. Please paste your built HTML code into the script editor.");
  }
}

function doPost(e) {
  if (!e) return ContentService.createTextOutput("Error: No POST data found.");
  try {
    apiPostData(e.postData.contents);
    return ContentService.createTextOutput(JSON.stringify({status: 'success'}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({status: 'error', message: err.toString()}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * API: GET DATA (Returns JSON String)
 */
function apiGetData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  
  // Create sheets if missing
  Object.values(SHEET_MAPPING).forEach(name => {
    if (!ss.getSheetByName(name)) ss.insertSheet(name);
  });

  const payload = {
    parties: getSheetData(ss, SHEET_MAPPING['party']),
    products: getSheetData(ss, SHEET_MAPPING['product']),
    invoices: getSheetData(ss, SHEET_MAPPING['invoice']),
    transactions: getSheetData(ss, SHEET_MAPPING['transaction']),
    settings: getSheetData(ss, SHEET_MAPPING['setting'])[0] || {}
  };

  // CRITICAL: We JSON.stringify here to ensure Dates and Objects survive the trip to React
  return JSON.stringify(payload);
}

/**
 * API: POST DATA
 */
function apiPostData(payloadString) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000); 

  try {
    const data = JSON.parse(payloadString);
    const type = data.type; 
    const action = data.action;
    const payload = data.payload;

    const sheetName = SHEET_MAPPING[type] || capitalize(type + 's');
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let sheet = ss.getSheetByName(sheetName);

    if (!sheet) sheet = ss.insertSheet(sheetName);

    // Auto-Header
    if (sheet.getLastRow() === 0) {
      sheet.appendRow(Object.keys(payload));
    }

    // Dynamic Header Update
    let headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
    const newColumns = Object.keys(payload).filter(k => !headers.includes(k));
    
    if (newColumns.length > 0) {
      sheet.getRange(1, headers.length + 1, 1, newColumns.length).setValues([newColumns]);
      headers = [...headers, ...newColumns];
    }

    const objToRow = (obj) => headers.map(h => {
      let val = obj[h];
      if (val === undefined || val === null) return '';
      if (typeof val === 'object') return JSON.stringify(val); // Serialize nested objects
      return val;
    });

    // Find Row ID
    const idIndex = headers.indexOf('id');
    let rowIndex = -1;

    if (action !== 'create' && idIndex !== -1 && sheet.getLastRow() > 1) {
       const ids = sheet.getRange(2, idIndex + 1, sheet.getLastRow() - 1, 1).getValues().flat();
       rowIndex = ids.indexOf(payload.id);
    }

    if (action === 'create') {
      sheet.appendRow(objToRow(payload));
    } 
    else if (action === 'update') {
      if (rowIndex !== -1) {
        const newRowData = objToRow(payload);
        sheet.getRange(rowIndex + 2, 1, 1, newRowData.length).setValues([newRowData]);
      } else {
        sheet.appendRow(objToRow(payload));
      }
    } 
    else if (action === 'delete') {
      if (rowIndex !== -1) {
        sheet.deleteRow(rowIndex + 2);
      }
    }

    return { status: "success" };
  } catch (e) {
    Logger.log("Error in apiPostData: " + e);
    throw e;
  } finally {
    lock.releaseLock();
  }
}

/**
 * UTILITIES
 */
function getSheetData(ss, sheetName) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || sheet.getLastRow() <= 1) return [];
  
  const rows = sheet.getDataRange().getValues();
  const headers = rows[0];
  const data = rows.slice(1);
  
  return data.map(row => {
    let obj = {};
    headers.forEach((h, i) => {
      let val = row[i];
      // Convert Dates to clean Strings
      if (val instanceof Date) {
        val = Utilities.formatDate(val, ss.getSpreadsheetTimeZone(), "yyyy-MM-dd");
      }
      // Try parsing JSON for items
      if (typeof val === 'string' && (val.startsWith('[') || val.startsWith('{'))) {
         try { val = JSON.parse(val); } catch(e) {}
      }
      obj[h] = val;
    });
    return obj;
  });
}

function capitalize(s) { 
  if (!s) return '';
  return s.charAt(0).toUpperCase() + s.slice(1); 
}