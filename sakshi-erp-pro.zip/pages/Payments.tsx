
import React, { useState, useEffect } from 'react';
import { ArrowDownLeft, ArrowUpRight, Wallet, Receipt, Trash2, Edit2, X } from 'lucide-react';
import { Party, Transaction, Invoice } from '../types';
import * as db from '../services/db';

export const PaymentsPage: React.FC = () => {
  const [parties, setParties] = useState<Party[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  
  // Form State
  const [type, setType] = useState<'PAYMENT_IN' | 'PAYMENT_OUT'>('PAYMENT_IN');
  const [partyId, setPartyId] = useState('');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  
  // Edit State
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);

  // Filter State
  const [filter, setFilter] = useState<'ALL' | 'PAYMENT_IN' | 'PAYMENT_OUT'>('ALL');

  const load = () => {
    setParties(db.getParties());
    setTransactions(db.getTransactions());
    setInvoices(db.getInvoices());
  };
  
  useEffect(() => { load(); }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parties.find(x => x.id === partyId);
    if (!p) return;

    const txData: Transaction = {
      id: editingTx ? editingTx.id : '',
      date: editingTx ? editingTx.date : new Date().toISOString().split('T')[0],
      partyId,
      partyName: p.name,
      amount: parseFloat(amount),
      type,
      note,
      invoiceId: selectedInvoiceId || undefined
    };

    if (editingTx) {
        db.updateTransaction(txData);
        alert('Transaction updated successfully. Balances adjusted.');
    } else {
        db.createTransaction(txData);
    }
    
    resetForm();
    load(); 
  };

  const resetForm = () => {
      setAmount('');
      setNote('');
      setSelectedInvoiceId('');
      setEditingTx(null);
      // We keep partyId and type for convenience unless cleared
  };

  const handleEdit = (tx: Transaction) => {
      setEditingTx(tx);
      setType(tx.type);
      setPartyId(tx.partyId);
      setAmount(tx.amount.toString());
      setNote(tx.note);
      setSelectedInvoiceId(tx.invoiceId || '');
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = (id: string) => {
      if(confirm("Are you sure? This will reverse the effect on Party Balance and Invoice Paid Amount.")) {
          db.deleteTransaction(id);
          load();
      }
  };

  const selectedParty = parties.find(p => p.id === partyId);

  // Filter Pending Invoices for selected party
  const pendingInvoices = selectedParty ? invoices.filter(inv => {
      const isPending = (inv.totalAmount - inv.paidAmount) > 1; // Tolerance
      const matchParty = inv.partyId === selectedParty.id;
      const matchType = type === 'PAYMENT_IN' ? inv.type === 'SALE' : inv.type === 'PURCHASE';
      // If editing, include the currently selected invoice even if fully paid (so we can see it)
      const isCurrentlySelected = editingTx && editingTx.invoiceId === inv.id;
      return matchParty && (isPending || isCurrentlySelected) && matchType;
  }) : [];

  const handleInvoiceSelect = (invId: string) => {
      setSelectedInvoiceId(invId);
      
      if (!invId) {
          if (!editingTx) setNote('');
          return;
      }

      const inv = pendingInvoices.find(i => i.id === invId);
      if (inv) {
          // If selecting a bill, default amount to Due amount
          // Be careful not to overwrite if editing and amount is already set
          if (!editingTx) {
            const due = inv.totalAmount - inv.paidAmount;
            setAmount(due.toFixed(2));
            setNote(`Payment for ${inv.type} #${inv.id}`);
          }
      }
  };

  const filteredTransactions = transactions.filter(t => {
    if (filter === 'ALL') return true;
    return t.type === filter;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      {/* Form */}
      <div className="bg-white p-6 rounded-xl shadow-sm border h-fit">
        <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold text-lg flex items-center gap-2">
                {type === 'PAYMENT_IN' ? <ArrowDownLeft className="text-green-500" /> : <ArrowUpRight className="text-red-500" />}
                {editingTx ? 'Edit Transaction' : 'Record Payment'}
            </h3>
            {editingTx && (
                <button onClick={resetForm} className="text-xs text-red-500 flex items-center gap-1 bg-red-50 px-2 py-1 rounded">
                    <X size={12} /> Cancel Edit
                </button>
            )}
        </div>
        
        <div className="flex bg-slate-100 p-1 rounded mb-4">
            <button onClick={() => { setType('PAYMENT_IN'); setPartyId(''); }} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_IN' ? 'bg-green-500 text-white shadow' : 'text-slate-500'}`}>Receive (In)</button>
            <button onClick={() => { setType('PAYMENT_OUT'); setPartyId(''); }} className={`flex-1 py-2 rounded font-medium text-sm transition ${type === 'PAYMENT_OUT' ? 'bg-red-500 text-white shadow' : 'text-slate-500'}`}>Pay (Out)</button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
             <div>
                <label className="block text-sm font-medium mb-1">Party Name</label>
                <select required className="w-full border p-2 rounded" value={partyId} onChange={e => { setPartyId(e.target.value); setSelectedInvoiceId(''); }}>
                    <option value="">Select Party</option>
                    {parties.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
             </div>
             
             {/* Current Balance Display */}
             {selectedParty && (
                <div className={`p-3 rounded-lg flex items-center justify-between text-sm ${selectedParty.balance > 0 ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-700'}`}>
                    <span className="flex items-center gap-2 font-medium"><Wallet size={16}/> Balance:</span>
                    <span className="font-bold text-lg">
                        ₹ {Math.abs(selectedParty.balance).toFixed(2)} {selectedParty.balance > 0 ? 'Dr' : 'Cr'}
                    </span>
                </div>
             )}

             {/* Link Invoice Selector */}
             {pendingInvoices.length > 0 && (
                 <div className="bg-blue-50 p-3 rounded border border-blue-100">
                     <label className="block text-xs font-bold text-blue-700 mb-1 flex items-center gap-1">
                        <Receipt size={12} /> Link to Bill (Optional)
                     </label>
                     <select 
                        className="w-full border p-2 rounded text-sm bg-white" 
                        value={selectedInvoiceId} 
                        onChange={e => handleInvoiceSelect(e.target.value)}
                     >
                        <option value="">-- General Payment (On Account) --</option>
                        {pendingInvoices.map(inv => (
                            <option key={inv.id} value={inv.id}>
                                #{inv.id.substring(0,6)} - Date: {inv.date} (Due: ₹{inv.totalAmount - inv.paidAmount})
                            </option>
                        ))}
                     </select>
                 </div>
             )}

             <div>
                <label className="block text-sm font-medium mb-1">Amount</label>
                <input required type="number" step="0.01" className="w-full border p-2 rounded font-bold" value={amount} onChange={e => setAmount(e.target.value)} />
             </div>
             <div>
                <label className="block text-sm font-medium mb-1">Note / Reference</label>
                <textarea className="w-full border p-2 rounded" value={note} onChange={e => setNote(e.target.value)} rows={3}></textarea>
             </div>
             <button className={`w-full py-2 rounded text-white font-bold ${type === 'PAYMENT_IN' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}>
                 {editingTx ? 'Update Transaction' : 'Save Transaction'}
             </button>
        </form>
      </div>

      {/* History */}
      <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-50 flex flex-col sm:flex-row justify-between items-center gap-3">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
                Recently Transactions
            </h3>
            <div className="flex bg-slate-200 rounded-lg p-1 text-xs font-bold">
                <button 
                    onClick={() => setFilter('ALL')} 
                    className={`px-3 py-1 rounded-md transition ${filter === 'ALL' ? 'bg-white shadow text-slate-800' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    All
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_IN')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_IN' ? 'bg-white shadow text-green-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <ArrowDownLeft size={12} /> Received
                </button>
                <button 
                    onClick={() => setFilter('PAYMENT_OUT')} 
                    className={`px-3 py-1 rounded-md transition flex items-center gap-1 ${filter === 'PAYMENT_OUT' ? 'bg-white shadow text-red-700' : 'text-slate-500 hover:text-slate-700'}`}
                >
                    <ArrowUpRight size={12} /> Paid
                </button>
            </div>
        </div>
        <table className="w-full text-left text-sm">
            <thead className="text-slate-500 border-b">
                <tr>
                    <th className="p-4">Date</th>
                    <th className="p-4">Party</th>
                    <th className="p-4">Type</th>
                    <th className="p-4">Note</th>
                    <th className="p-4 text-right">Amount</th>
                    <th className="p-4 text-center">Action</th>
                </tr>
            </thead>
            <tbody className="divide-y">
                {filteredTransactions.map(t => (
                    <tr key={t.id} className={editingTx?.id === t.id ? "bg-blue-50" : ""}>
                        <td className="p-4 text-slate-500">{t.date}</td>
                        <td className="p-4 font-medium">{t.partyName}</td>
                        <td className="p-4">
                            <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                            </span>
                            {t.invoiceId && <span className="block text-[10px] text-slate-400 mt-1">Inv #{t.invoiceId.substring(0,6)}</span>}
                        </td>
                        <td className="p-4 text-slate-500 max-w-xs truncate">{t.note}</td>
                        <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600' : 'text-red-600'}`}>
                            {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                        </td>
                        <td className="p-4 text-center flex justify-center gap-2">
                            <button onClick={() => handleEdit(t)} className="text-slate-400 hover:text-blue-600"><Edit2 size={16} /></button>
                            <button onClick={() => handleDelete(t.id)} className="text-slate-400 hover:text-red-600"><Trash2 size={16} /></button>
                        </td>
                    </tr>
                ))}
                {filteredTransactions.length === 0 && <tr><td colSpan={6} className="p-8 text-center text-slate-400">No transactions found</td></tr>}
            </tbody>
        </table>
      </div>
    </div>
  );
};
