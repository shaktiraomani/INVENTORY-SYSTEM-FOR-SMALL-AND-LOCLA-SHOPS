
import React, { useState, useEffect } from 'react';
import { Printer, CreditCard, Receipt, Edit, Mail, Download, FileDown, PieChart, TrendingUp, TrendingDown, Trash2, Share2, FileText } from 'lucide-react';
import { Invoice, PrintOptions, Transaction, Party, Product } from '../types';
import * as db from '../services/db';
import { InvoiceTemplate } from '../components/InvoiceTemplate';

interface ReportsPageProps {
  onEdit?: (invoice: Invoice) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ onEdit }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  
  // Tab State: 'invoices', 'transactions', 'financials', 'tax'
  const [activeTab, setActiveTab] = useState<'invoices' | 'transactions' | 'financials' | 'tax'>('invoices');
  
  // Invoice Filter: 'ALL' | 'SALE' | 'PURCHASE'
  const [filterType, setFilterType] = useState<'ALL' | 'SALE' | 'PURCHASE'>('ALL');

  // Print Modal State for Reprinting
  const [printingInvoice, setPrintingInvoice] = useState<Invoice | null>(null);
  const [printConfig, setPrintConfig] = useState<PrintOptions>({
    template: 'standard',
    showQr: true,
    showTerms: true,
    showHeader: true,
    showFooter: true
  });
  const [settings] = useState(db.getSettings());

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setInvoices(db.getInvoices());
    setTransactions(db.getTransactions());
    setParties(db.getParties());
    setProducts(db.getProducts());
  };

  const handleEmail = (invoice: Invoice) => {
    const party = parties.find(p => p.id === invoice.partyId);
    if (!party?.email) {
      alert('No email address found for this party. Please update party details.');
      return;
    }
    
    const subject = `${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} - ${settings.businessName}`;
    const body = `Dear ${party.name},\n\nPlease find the details below for ${invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order'} #${invoice.id} dated ${invoice.date}.\n\nTotal Amount: ${invoice.totalAmount}\nPaid Amount: ${invoice.paidAmount}\n\nThank you,\n${settings.businessName}`;
    
    window.open(`mailto:${party.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  const handleShare = (invoice: Invoice) => {
    const typeLabel = invoice.type === 'SALE' ? 'Invoice' : 'Purchase Order';
    const text = `*${settings.businessName}*\n${typeLabel} #${invoice.id.substring(0,6)}\nDate: ${invoice.date}\nParty: ${invoice.partyName}\n\n*Amount Due: ₹ ${invoice.totalAmount - invoice.paidAmount}*\nTotal Amount: ₹ ${invoice.totalAmount}\n\nPlease pay at your earliest convenience.`;
    
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleDeleteInvoice = (id: string) => {
    if (confirm('Are you sure you want to delete this invoice?\n\nThis will REVERSE the stock changes and adjust the party balance automatically.')) {
        db.deleteInvoice(id);
        loadData(); // Refresh list
    }
  };

  const handleEditClick = (inv: Invoice) => {
      if (onEdit) {
          if (confirm(`Edit Invoice #${inv.id.substring(0,6)}?\n\nWARNING: This will:\n1. Reverse previous Stock and Party Balance.\n2. Load data into Billing page.\n3. Apply new changes when you save.`)) {
              onEdit(inv);
          }
      }
  };

  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = inv.partyName.toLowerCase().includes(search.toLowerCase()) || 
                          inv.id.includes(search) ||
                          (inv.referenceNo && inv.referenceNo.includes(search));
    const matchesType = filterType === 'ALL' || inv.type === filterType;
    return matchesSearch && matchesType;
  });

  const filteredTransactions = transactions.filter(t => 
    t.partyName.toLowerCase().includes(search.toLowerCase()) ||
    (t.note && t.note.toLowerCase().includes(search.toLowerCase()))
  );

  const handleExport = () => {
    let headers: string[] = [];
    let data: (string | number)[][] = [];
    let filename = '';

    if (activeTab === 'invoices') {
      headers = ['Date', 'Invoice ID', 'Reference', 'Party Name', 'Type', 'Total Amount', 'Paid Amount', 'Due Amount'];
      data = filteredInvoices.map(inv => [
        inv.date,
        inv.id,
        inv.referenceNo || '',
        inv.partyName,
        inv.type,
        inv.totalAmount,
        inv.paidAmount,
        (inv.totalAmount - inv.paidAmount)
      ]);
      filename = `SakshiERP_Invoices_${new Date().toISOString().split('T')[0]}.csv`;
    } else if (activeTab === 'transactions') {
      headers = ['Date', 'Party Name', 'Type', 'Note', 'Amount'];
      data = filteredTransactions.map(t => [
        t.date,
        t.partyName,
        t.type,
        t.note || '',
        t.amount
      ]);
      filename = `SakshiERP_Transactions_${new Date().toISOString().split('T')[0]}.csv`;
    } else {
        return; // Financials not exported yet
    }

    const csvContent = [
      headers.join(','),
      ...data.map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadPdf = () => {
    const element = document.getElementById('print-area');
    if (!element || !printingInvoice) return;

    let jsPdfFormat: any = 'a4';
    if (printConfig.template === 'thermal') {
        jsPdfFormat = [80, 297];
    }

    const opt = {
      margin: 2,
      filename: `Invoice_${printingInvoice.id}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'mm', format: jsPdfFormat, orientation: 'portrait' }
    };

    // @ts-ignore
    if (window.html2pdf) {
        // @ts-ignore
        window.html2pdf().set(opt).from(element).save();
    } else {
        alert('PDF library not loaded.');
    }
  };

  // Financial Calculations
  const inventoryValue = products.reduce((acc, p) => acc + (p.stock * (p.buyPrice || 0)), 0);
  const receivablesList = parties.filter(p => p.balance > 0);
  const totalReceivables = receivablesList.reduce((acc, p) => acc + p.balance, 0);
  const payablesList = parties.filter(p => p.balance < 0);
  const totalPayables = payablesList.reduce((acc, p) => acc + Math.abs(p.balance), 0);
  
  // PROFIT CALCULATION - REALIZED (CASH) BASIS
  // Revenue = Collected Amount from Sales
  const realizedSalesRevenue = invoices.filter(i => i.type === 'SALE').reduce((acc, i) => acc + i.paidAmount, 0);
  // Cost = Paid Amount for Purchases (conservative view - usually we track COGS but this is simpler for cash flow)
  const totalPurchaseCost = invoices.filter(i => i.type === 'PURCHASE').reduce((acc, i) => acc + i.totalAmount, 0);
  
  // For approximate profit, we can subtract Total Purchase from Total Sales Collected
  // OR for safer margin: (Realized Sales) - (Total Purchase Bill Amount)
  const estimatedProfit = realizedSalesRevenue - totalPurchaseCost;
  
  const totalAssets = inventoryValue + totalReceivables;
  const totalLiabilities = totalPayables;

  // TAX REPORT CALCULATION
  const getTaxReport = () => {
      return filteredInvoices.map(inv => {
          const taxable = inv.items.reduce((acc, item) => acc + (item.taxableValue || 0), 0);
          const taxAmt = inv.items.reduce((acc, item) => acc + (item.gstAmount || 0), 0);
          
          let cgst = 0, sgst = 0, igst = 0;
          if (inv.taxType === 'INTER') {
              igst = taxAmt;
          } else {
              cgst = taxAmt / 2;
              sgst = taxAmt / 2;
          }
          
          return {
              ...inv,
              taxable,
              taxAmt,
              cgst, sgst, igst
          };
      });
  };
  
  const taxReportData = getTaxReport();
  const totalTaxable = taxReportData.reduce((acc, i) => acc + i.taxable, 0);
  const totalIGST = taxReportData.reduce((acc, i) => acc + i.igst, 0);
  const totalCGST = taxReportData.reduce((acc, i) => acc + i.cgst, 0);
  const totalSGST = taxReportData.reduce((acc, i) => acc + i.sgst, 0);

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Sales (Booked)</h4>
              <p className="text-2xl font-bold text-blue-600 mt-2">
                  ₹ {invoices.filter(i => i.type === 'SALE').reduce((acc, curr) => acc + curr.totalAmount, 0).toLocaleString()}
              </p>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Purchase</h4>
               <p className="text-2xl font-bold text-purple-600 mt-2">
                  ₹ {totalPurchaseCost.toLocaleString()}
              </p>
          </div>
          <div className="bg-white p-6 rounded-xl border shadow-sm">
              <h4 className="text-slate-500 text-sm font-bold uppercase">Total Due</h4>
               <p className="text-2xl font-bold text-red-600 mt-2">
                  ₹ {invoices.reduce((acc, curr) => acc + (curr.totalAmount - curr.paidAmount), 0).toLocaleString()}
              </p>
          </div>
      </div>

      {/* Main Content Area */}
      <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
        <div className="p-4 border-b bg-slate-50 flex flex-col lg:flex-row justify-between items-center gap-4">
            <div className="flex gap-4 items-center w-full lg:w-auto overflow-x-auto">
                <div className="flex space-x-2 bg-slate-200 p-1 rounded-lg shrink-0">
                    <button 
                    onClick={() => setActiveTab('invoices')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'invoices' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <Receipt size={16} /> Invoices / PO
                    </button>
                    <button 
                    onClick={() => setActiveTab('transactions')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'transactions' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <CreditCard size={16} /> Payments
                    </button>
                    <button 
                    onClick={() => setActiveTab('financials')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'financials' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <PieChart size={16} /> Balance Sheet
                    </button>
                    <button 
                    onClick={() => setActiveTab('tax')}
                    className={`px-4 py-2 rounded-md text-sm font-bold transition flex items-center gap-2 ${activeTab === 'tax' ? 'bg-white text-blue-600 shadow' : 'text-slate-500'}`}
                    >
                    <FileText size={16} /> Tax / GST
                    </button>
                </div>
                
                {(activeTab === 'invoices' || activeTab === 'tax') && (
                    <div className="flex bg-slate-100 rounded-lg p-1 border shrink-0">
                        <button onClick={() => setFilterType('ALL')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'ALL' ? 'bg-white shadow text-slate-800' : 'text-slate-400'}`}>All</button>
                        <button onClick={() => setFilterType('SALE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'SALE' ? 'bg-blue-100 text-blue-700' : 'text-slate-400'}`}>Sales</button>
                        <button onClick={() => setFilterType('PURCHASE')} className={`px-3 py-1 text-xs font-bold rounded ${filterType === 'PURCHASE' ? 'bg-purple-100 text-purple-700' : 'text-slate-400'}`}>Purchases</button>
                    </div>
                )}
            </div>

            {activeTab !== 'financials' && (
                <div className="flex gap-2 w-full lg:w-auto items-center">
                    <input 
                        type="text" 
                        placeholder={activeTab === 'invoices' ? "Search Invoice #, Ref..." : "Search Party, Note..."}
                        className="flex-1 border p-2 rounded text-sm w-full lg:w-64 outline-none focus:ring-1 focus:ring-blue-500"
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                    />
                    <button 
                        onClick={handleExport}
                        className="bg-white border border-slate-300 text-slate-700 p-2 rounded hover:bg-slate-50 transition"
                        title="Export to CSV"
                    >
                        <Download size={20} />
                    </button>
                </div>
            )}
        </div>

        {activeTab === 'invoices' && (
          <table className="w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-500">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Invoice #</th>
                      <th className="p-4">Ref #</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4 text-right">Total</th>
                      <th className="p-4 text-right">Paid</th>
                      <th className="p-4 text-right">Due</th>
                      <th className="p-4 text-center">Action</th>
                  </tr>
              </thead>
              <tbody className="divide-y">
                  {filteredInvoices.map(inv => (
                      <tr key={inv.id} className="hover:bg-slate-50">
                          <td className="p-4">{inv.date}</td>
                          <td className="p-4 font-mono text-xs text-slate-500">{inv.id.substring(0, 8)}</td>
                          <td className="p-4 text-xs font-mono">{inv.referenceNo || '-'}</td>
                          <td className="p-4 font-medium">{inv.partyName}</td>
                           <td className="p-4">
                               <span className={`text-xs px-2 py-1 rounded font-bold ${inv.type === 'SALE' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                                   {inv.type === 'SALE' ? 'SALE' : 'PURCHASE'}
                               </span>
                           </td>
                          <td className="p-4 text-right font-medium">₹ {inv.totalAmount}</td>
                          <td className="p-4 text-right text-green-600">₹ {inv.paidAmount}</td>
                          <td className="p-4 text-right text-red-500 font-bold">
                              {inv.totalAmount - inv.paidAmount > 0 ? `₹ ${inv.totalAmount - inv.paidAmount}` : '-'}
                          </td>
                          <td className="p-4 text-center flex justify-center gap-2">
                              {onEdit && (
                                <button onClick={() => handleEditClick(inv)} className="text-slate-500 hover:text-blue-600" title="Edit">
                                    <Edit size={18} />
                                </button>
                              )}
                              <button onClick={() => handleShare(inv)} className="text-slate-500 hover:text-green-600" title="Share via WhatsApp">
                                  <Share2 size={18} />
                              </button>
                              <button onClick={() => handleEmail(inv)} className="text-slate-500 hover:text-indigo-600" title="Email Invoice">
                                  <Mail size={18} />
                              </button>
                              <button onClick={() => setPrintingInvoice(inv)} className="text-slate-500 hover:text-black" title="Print">
                                  <Printer size={18} />
                              </button>
                              <button 
                                onClick={() => handleDeleteInvoice(inv.id)} 
                                className="text-slate-500 hover:text-red-600" 
                                title="Delete Invoice (Reverses Stock)"
                              >
                                  <Trash2 size={18} />
                              </button>
                          </td>
                      </tr>
                  ))}
                  {filteredInvoices.length === 0 && (
                    <tr><td colSpan={9} className="p-8 text-center text-slate-400">No records found.</td></tr>
                  )}
              </tbody>
          </table>
        )}

        {activeTab === 'transactions' && (
          <table className="w-full text-left text-sm">
              <thead className="bg-slate-100 text-slate-500">
                  <tr>
                      <th className="p-4">Date</th>
                      <th className="p-4">Party</th>
                      <th className="p-4">Type</th>
                      <th className="p-4">Note</th>
                      <th className="p-4 text-right">Amount</th>
                  </tr>
              </thead>
              <tbody className="divide-y">
                  {filteredTransactions.map(t => (
                      <tr key={t.id} className="hover:bg-slate-50">
                          <td className="p-4 text-slate-500">{t.date}</td>
                          <td className="p-4 font-medium">{t.partyName}</td>
                          <td className="p-4">
                              <span className={`px-2 py-1 rounded text-xs font-bold ${t.type === 'PAYMENT_IN' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                  {t.type === 'PAYMENT_IN' ? 'RECEIVED' : 'PAID'}
                              </span>
                          </td>
                          <td className="p-4 text-slate-500 italic max-w-xs truncate">{t.note || '-'}</td>
                          <td className={`p-4 text-right font-bold ${t.type === 'PAYMENT_IN' ? 'text-green-600' : 'text-red-600'}`}>
                              {t.type === 'PAYMENT_IN' ? '+' : '-'} ₹ {t.amount}
                          </td>
                      </tr>
                  ))}
                  {filteredTransactions.length === 0 && (
                    <tr><td colSpan={5} className="p-8 text-center text-slate-400">No transactions found.</td></tr>
                  )}
              </tbody>
          </table>
        )}
        
        {activeTab === 'tax' && (
            <div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 border-b bg-slate-50 text-center">
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Total Taxable</p>
                        <p className="font-bold">₹ {totalTaxable.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Total CGST</p>
                        <p className="font-bold text-blue-600">₹ {totalCGST.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Total SGST</p>
                        <p className="font-bold text-blue-600">₹ {totalSGST.toFixed(2)}</p>
                    </div>
                    <div>
                        <p className="text-xs text-slate-500 uppercase font-bold">Total IGST</p>
                        <p className="font-bold text-indigo-600">₹ {totalIGST.toFixed(2)}</p>
                    </div>
                </div>
                <div className="overflow-auto">
                    <table className="w-full text-left text-sm">
                        <thead className="bg-white text-slate-500 border-b">
                            <tr>
                                <th className="p-3">Date</th>
                                <th className="p-3">Invoice</th>
                                <th className="p-3">Party</th>
                                <th className="p-3">GSTIN</th>
                                <th className="p-3 text-right">Taxable</th>
                                <th className="p-3 text-right">CGST</th>
                                <th className="p-3 text-right">SGST</th>
                                <th className="p-3 text-right">IGST</th>
                                <th className="p-3 text-right">Total Tax</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y">
                            {taxReportData.map(row => (
                                <tr key={row.id} className="hover:bg-slate-50">
                                    <td className="p-3 text-slate-500">{row.date}</td>
                                    <td className="p-3 font-mono text-xs">{row.id.substring(0,8)}</td>
                                    <td className="p-3 font-medium">{row.partyName}</td>
                                    <td className="p-3 text-xs uppercase">{row.gstin || '-'}</td>
                                    <td className="p-3 text-right">₹{row.taxable.toFixed(2)}</td>
                                    <td className="p-3 text-right text-slate-500">{row.cgst > 0 ? row.cgst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right text-slate-500">{row.sgst > 0 ? row.sgst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right text-slate-500">{row.igst > 0 ? row.igst.toFixed(2) : '-'}</td>
                                    <td className="p-3 text-right font-bold text-slate-700">₹{row.taxAmt.toFixed(2)}</td>
                                </tr>
                            ))}
                            {taxReportData.length === 0 && (
                                <tr><td colSpan={9} className="p-8 text-center text-slate-400">No tax records found.</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {activeTab === 'financials' && (
            <div className="p-8 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Assets & Liabilities Summary */}
                    <div className="space-y-6">
                        <h3 className="font-bold text-lg text-slate-800 border-b pb-2">Balance Sheet Overview</h3>
                        
                        <div className="bg-white border rounded-xl overflow-hidden">
                            <div className="bg-slate-100 px-4 py-2 font-bold text-slate-600 text-sm uppercase">Current Assets</div>
                            <div className="divide-y">
                                <div className="p-4 flex justify-between items-center">
                                    <span className="flex items-center gap-2 text-slate-700"><CreditCard size={18} className="text-green-500"/> Market Receivables</span>
                                    <span className="font-bold">₹ {totalReceivables.toLocaleString()}</span>
                                </div>
                                <div className="p-4 flex justify-between items-center">
                                    <span className="flex items-center gap-2 text-slate-700"><Receipt size={18} className="text-blue-500"/> Inventory Value (Stock)</span>
                                    <span className="font-bold">₹ {inventoryValue.toLocaleString()}</span>
                                </div>
                            </div>
                            <div className="bg-green-50 px-4 py-3 flex justify-between items-center border-t border-green-100">
                                <span className="font-bold text-green-800">Total Assets</span>
                                <span className="font-bold text-green-800 text-lg">₹ {totalAssets.toLocaleString()}</span>
                            </div>
                        </div>

                        <div className="bg-white border rounded-xl overflow-hidden">
                            <div className="bg-slate-100 px-4 py-2 font-bold text-slate-600 text-sm uppercase">Current Liabilities</div>
                            <div className="p-4 flex justify-between items-center">
                                <span className="flex items-center gap-2 text-slate-700"><CreditCard size={18} className="text-red-500"/> Market Payables</span>
                                <span className="font-bold">₹ {totalPayables.toLocaleString()}</span>
                            </div>
                            <div className="bg-red-50 px-4 py-3 flex justify-between items-center border-t border-red-100">
                                <span className="font-bold text-red-800">Total Liabilities</span>
                                <span className="font-bold text-red-800 text-lg">₹ {totalLiabilities.toLocaleString()}</span>
                            </div>
                        </div>
                    </div>

                    {/* Profit & Loss Estimate */}
                    <div className="space-y-6">
                        <h3 className="font-bold text-lg text-slate-800 border-b pb-2">Profit & Loss (Est.)</h3>
                         <div className="bg-white border rounded-xl p-6 space-y-4">
                             <div className="flex justify-between items-center">
                                 <div className="flex items-center gap-3">
                                     <div className="p-2 bg-green-100 rounded text-green-600"><TrendingUp size={20} /></div>
                                     <div>
                                         <p className="text-sm text-slate-500">Collected Revenue (Cash)</p>
                                         <p className="font-bold text-lg">₹ {realizedSalesRevenue.toLocaleString()}</p>
                                     </div>
                                 </div>
                             </div>
                             <div className="flex justify-between items-center">
                                 <div className="flex items-center gap-3">
                                     <div className="p-2 bg-red-100 rounded text-red-600"><TrendingDown size={20} /></div>
                                     <div>
                                         <p className="text-sm text-slate-500">Total Expenses (Purchases)</p>
                                         <p className="font-bold text-lg">₹ {totalPurchaseCost.toLocaleString()}</p>
                                     </div>
                                 </div>
                             </div>
                             
                             <div className="pt-4 border-t">
                                 <p className="text-sm text-slate-400 mb-1">Realized Profit (Cash Flow)</p>
                                 <div className={`text-3xl font-bold ${estimatedProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                                     {estimatedProfit >= 0 ? '+' : ''} ₹ {estimatedProfit.toLocaleString()}
                                 </div>
                                 <p className="text-xs text-slate-400 mt-2 italic">*Based on (Money Collected) minus (Total Purchases).</p>
                             </div>
                         </div>
                    </div>
                </div>

                {/* Outstanding Balances Detail */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                    {/* Receivables Table */}
                    <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
                        <div className="bg-green-50 px-4 py-3 border-b border-green-100 flex justify-between items-center">
                             <h4 className="font-bold text-green-800">Receivables (To Collect)</h4>
                             <span className="text-xs bg-white px-2 py-1 rounded border text-green-700 font-bold">{receivablesList.length} Parties</span>
                        </div>
                        <div className="max-h-64 overflow-y-auto">
                            <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 text-slate-500 sticky top-0">
                                    <tr>
                                        <th className="p-3">Party Name</th>
                                        <th className="p-3 text-right">Amount</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {receivablesList.map(p => (
                                        <tr key={p.id} className="hover:bg-slate-50">
                                            <td className="p-3">{p.name}</td>
                                            <td className="p-3 text-right font-medium text-green-600">₹ {p.balance.toLocaleString()}</td>
                                        </tr>
                                    ))}
                                    {receivablesList.length === 0 && <tr><td colSpan={2} className="p-4 text-center text-slate-400">No pending receivables.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {/* Payables Table */}
                    <div className="bg-white rounded-xl border shadow-sm overflow-hidden">
                        <div className="bg-red-50 px-4 py-3 border-b border-red-100 flex justify-between items-center">
                             <h4 className="font-bold text-red-800">Payables (To Pay)</h4>
                             <span className="text-xs bg-white px-2 py-1 rounded border text-red-700 font-bold">{payablesList.length} Parties</span>
                        </div>
                        <div className="max-h-64 overflow-y-auto">
                             <table className="w-full text-sm text-left">
                                <thead className="bg-slate-50 text-slate-500 sticky top-0">
                                    <tr>
                                        <th className="p-3">Party Name</th>
                                        <th className="p-3 text-right">Amount</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y">
                                    {payablesList.map(p => (
                                        <tr key={p.id} className="hover:bg-slate-50">
                                            <td className="p-3">{p.name}</td>
                                            <td className="p-3 text-right font-medium text-red-600">₹ {Math.abs(p.balance).toLocaleString()}</td>
                                        </tr>
                                    ))}
                                    {payablesList.length === 0 && <tr><td colSpan={2} className="p-4 text-center text-slate-400">No pending payables.</td></tr>}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )}
      </div>

      {/* REPRINT MODAL */}
      {printingInvoice && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <div className="bg-slate-100 rounded-xl w-full max-w-6xl h-[90vh] flex overflow-hidden">
                <div className="w-80 bg-white border-r p-6 flex flex-col overflow-y-auto no-print">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-xl font-bold flex items-center gap-2"><Printer /> Reprint</h2>
                    </div>
                    
                    <div className="space-y-6 flex-1">
                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block">Template</label>
                            <div className="grid grid-cols-1 gap-2">
                                {(['standard', 'thermal', 'modern'] as const).map(t => (
                                    <button 
                                        key={t}
                                        onClick={() => setPrintConfig({...printConfig, template: t})}
                                        className={`px-4 py-3 rounded text-left capitalize border transition ${printConfig.template === t ? 'bg-blue-50 border-blue-500 text-blue-700 ring-1 ring-blue-500' : 'bg-white hover:bg-slate-50'}`}
                                    >
                                        {t} Layout
                                    </button>
                                ))}
                            </div>
                        </div>

                        <div>
                            <label className="text-sm font-bold text-slate-500 mb-2 block">Options</label>
                             <div className="space-y-3">
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showHeader} onChange={e => setPrintConfig({...printConfig, showHeader: e.target.checked})} />
                                    <span>Show Header</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showFooter} onChange={e => setPrintConfig({...printConfig, showFooter: e.target.checked})} />
                                    <span>Show Footer</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showQr} onChange={e => setPrintConfig({...printConfig, showQr: e.target.checked})} />
                                    <span>Show UPI QR</span>
                                </label>
                                <label className="flex items-center gap-3 cursor-pointer">
                                    <input type="checkbox" className="w-5 h-5" checked={printConfig.showTerms} onChange={e => setPrintConfig({...printConfig, showTerms: e.target.checked})} />
                                    <span>Show Terms</span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div className="mt-6 pt-6 border-t space-y-3">
                        <button 
                            onClick={() => window.print()} 
                            className="w-full bg-blue-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-blue-700"
                        >
                            <Printer size={20} /> Print Invoice
                        </button>
                        <button 
                            onClick={handleDownloadPdf}
                            className="w-full bg-green-600 text-white py-3 rounded-lg font-bold flex justify-center items-center gap-2 hover:bg-green-700"
                        >
                            <FileDown size={20} /> Save as PDF
                        </button>
                        <button 
                            onClick={() => setPrintingInvoice(null)} 
                            className="w-full bg-white border border-slate-300 text-slate-700 py-3 rounded-lg font-bold hover:bg-slate-50"
                        >
                            Close
                        </button>
                    </div>
                </div>

                <div className="flex-1 bg-slate-500 overflow-auto p-8 flex justify-center">
                    <div className="shadow-2xl h-fit">
                        <div id="print-area" className="bg-white">
                            <InvoiceTemplate 
                                invoice={printingInvoice} 
                                settings={settings}
                                options={printConfig}
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};
