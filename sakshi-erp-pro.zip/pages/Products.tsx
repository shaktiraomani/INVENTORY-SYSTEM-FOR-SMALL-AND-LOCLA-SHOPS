

import React, { useState, useEffect } from 'react';
import { Plus, Trash2, Edit2, Search, Package, AlertTriangle, ClipboardList, ArrowUp, ArrowDown, History, X, Layers } from 'lucide-react';
import { Product, StockAdjustment, ProductVariant } from '../types';
import * as db from '../services/db';

export const ProductsPage: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  // Edit State
  const [editing, setEditing] = useState<Product | null>(null);
  
  // Stock Adjustment State
  const [adjustingProduct, setAdjustingProduct] = useState<Product | null>(null);
  const [selectedVariantId, setSelectedVariantId] = useState<string>(''); // For adjusting variant stock
  const [adjForm, setAdjForm] = useState({ type: 'INCREASE' as 'INCREASE'|'DECREASE', qty: 0, reason: '' });

  // Stock History State
  const [historyProduct, setHistoryProduct] = useState<Product | null>(null);
  const [historyData, setHistoryData] = useState<StockAdjustment[]>([]);

  const [search, setSearch] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);
  
  const [form, setForm] = useState<Partial<Product>>({ name: '', unit: 'PCS', buyPrice: 0, price: 0, stock: 0, variants: [] });
  const [hasVariants, setHasVariants] = useState(false);
  
  // Variant Form State
  const [variantForm, setVariantForm] = useState<Partial<ProductVariant>>({ name: '', price: 0, buyPrice: 0, stock: 0 });

  const load = () => setProducts(db.getProducts());
  useEffect(() => { load(); }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    db.saveProduct({ id: editing ? editing.id : '', ...form } as Product);
    setIsModalOpen(false);
    resetForm();
    load();
  };

  const resetForm = () => {
    setForm({ name: '', unit: 'PCS', buyPrice: 0, price: 0, stock: 0, variants: [] });
    setEditing(null);
    setHasVariants(false);
    setVariantForm({ name: '', price: 0, buyPrice: 0, stock: 0 });
  };

  const handleAddVariant = () => {
    if (!variantForm.name || !variantForm.price) return alert("Name and Sale Price are required for variant");
    
    const newVariant: ProductVariant = {
        id: db.generateId(),
        name: variantForm.name,
        price: Number(variantForm.price),
        buyPrice: Number(variantForm.buyPrice),
        stock: Number(variantForm.stock)
    };

    const updatedVariants = [...(form.variants || []), newVariant];
    setForm({ ...form, variants: updatedVariants });
    setVariantForm({ name: '', price: 0, buyPrice: 0, stock: 0 });
  };

  const removeVariant = (idx: number) => {
      const updated = [...(form.variants || [])];
      updated.splice(idx, 1);
      setForm({ ...form, variants: updated });
  };

  const handleStockAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustingProduct) return;
    if (adjForm.qty <= 0) return alert("Quantity must be greater than 0");
    if (!adjForm.reason.trim()) return alert("Reason is mandatory for audit purposes");

    let variantName = '';
    if (selectedVariantId) {
        const v = adjustingProduct.variants?.find(x => x.id === selectedVariantId);
        variantName = v ? v.name : '';
    }

    db.adjustStock({
      productId: adjustingProduct.id,
      productName: adjustingProduct.name,
      variantId: selectedVariantId || undefined,
      variantName: variantName || undefined,
      type: adjForm.type,
      qty: adjForm.qty,
      reason: adjForm.reason
    });

    setAdjustingProduct(null);
    setSelectedVariantId('');
    setAdjForm({ type: 'INCREASE', qty: 0, reason: '' });
    load();
    alert('Stock adjusted successfully');
  };

  const handleViewHistory = (product: Product) => {
      const allAdjustments = db.getStockAdjustments();
      const filtered = allAdjustments.filter(a => a.productId === product.id);
      filtered.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      setHistoryData(filtered);
      setHistoryProduct(product);
  };

  const openEdit = (p: Product) => {
      setEditing(p);
      setForm(p);
      setHasVariants(!!(p.variants && p.variants.length > 0));
      setIsModalOpen(true);
  };

  const filtered = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesStock = showLowStock ? p.stock < 10 : true; // Checks calculated total stock
    return matchesSearch && matchesStock;
  });

  const lowStockCount = db.getLowStockProducts(10).length;

  return (
    <div>
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
         <div className="relative flex-1 w-full md:w-auto">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
          <input 
            type="text" 
            placeholder="Search products..." 
            className="pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none w-full md:w-64"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <div className="flex gap-2 w-full md:w-auto">
            <button 
                onClick={() => setShowLowStock(!showLowStock)}
                className={`px-4 py-2 rounded-lg flex items-center gap-2 border transition ${showLowStock ? 'bg-red-100 text-red-700 border-red-200' : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'}`}
            >
                <AlertTriangle size={20} /> 
                <span className="hidden md:inline">Low Stock</span>
                <span className="bg-red-600 text-white text-xs px-2 py-0.5 rounded-full">{lowStockCount}</span>
            </button>
            <button 
            onClick={() => { resetForm(); setIsModalOpen(true); }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 flex-1 justify-center md:flex-none"
            >
            <Plus size={20} /> <span className="hidden md:inline">Add Product</span><span className="md:hidden">Add</span>
            </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-500 text-sm uppercase">
            <tr>
              <th className="p-4">Product Name</th>
              <th className="p-4">Unit</th>
              <th className="p-4 text-right">Buy Price</th>
              <th className="p-4 text-right">Sale Price</th>
              <th className="p-4 text-center">Stock</th>
              <th className="p-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filtered.map(p => (
              <tr key={p.id} className="hover:bg-slate-50">
                <td className="p-4 font-medium text-slate-800">
                  <div className="flex items-center gap-2">
                    <Package className="text-slate-400" size={16} /> 
                    {p.name}
                  </div>
                  {p.variants && p.variants.length > 0 && (
                      <div className="flex items-center gap-1 text-xs text-blue-600 mt-1 ml-6">
                          <Layers size={12} /> {p.variants.length} Variants
                      </div>
                  )}
                </td>
                <td className="p-4 text-slate-600">{p.unit}</td>
                <td className="p-4 text-slate-500 text-right">₹ {p.buyPrice ? p.buyPrice.toFixed(2) : '0.00'}</td>
                <td className="p-4 font-medium text-blue-600 text-right">₹ {p.price.toFixed(2)}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-1 rounded text-xs font-bold ${p.stock < 10 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>
                    {p.stock} {p.stock < 10 && 'Low'}
                  </span>
                </td>
                <td className="p-4 text-right flex justify-end gap-2">
                   <button 
                    onClick={() => handleViewHistory(p)}
                    className="text-slate-400 hover:text-slate-700"
                    title="View Stock History"
                   >
                       <History size={18} />
                   </button>
                   <button 
                    onClick={() => { setAdjustingProduct(p); setAdjForm({ type: 'INCREASE', qty: 0, reason: '' }) }} 
                    className="text-slate-400 hover:text-purple-600"
                    title="Adjust Stock"
                   >
                     <ClipboardList size={18} />
                   </button>
                   <button onClick={() => openEdit(p)} className="text-slate-400 hover:text-blue-600"><Edit2 size={18} /></button>
                   <button onClick={() => { if(confirm('Delete?')) { db.deleteProduct(p.id); load(); } }} className="text-slate-400 hover:text-red-600"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
                <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">No products found.</td>
                </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Product Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-xl font-bold mb-4">{editing ? 'Edit' : 'Add'} Product</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Name</label>
                <input required className="w-full border p-2 rounded" value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
              </div>
               <div>
                <label className="block text-sm font-medium mb-1">Unit</label>
                <select className="w-full border p-2 rounded" value={form.unit} onChange={e => setForm({...form, unit: e.target.value})}>
                  <option>PCS</option><option>KG</option><option>BOX</option><option>MTR</option>
                  <option>LTR</option><option>SET</option>
                </select>
              </div>

              {/* VARIANTS TOGGLE */}
              <div className="flex items-center gap-2 bg-slate-50 p-3 rounded">
                  <input 
                    type="checkbox" 
                    id="hasVariants" 
                    className="w-4 h-4"
                    checked={hasVariants} 
                    onChange={e => {
                        setHasVariants(e.target.checked);
                        // If turning off, maybe warn? For now we just hide.
                    }} 
                  />
                  <label htmlFor="hasVariants" className="text-sm font-bold text-slate-700 select-none cursor-pointer">
                      This product has variants (Sizes, Colors, etc.)
                  </label>
              </div>
              
              {!hasVariants ? (
                // NORMAL PRODUCT INPUTS
                <>
                    <div className="grid grid-cols-2 gap-2">
                        <div>
                            <label className="block text-sm font-medium mb-1 text-slate-500">Buy Price (Cost)</label>
                            <input type="number" step="0.01" className="w-full border p-2 rounded bg-slate-50" value={form.buyPrice} onChange={e => setForm({...form, buyPrice: parseFloat(e.target.value)})} />
                        </div>
                        <div>
                            <label className="block text-sm font-medium mb-1 text-blue-600">Sale Price (MRP)</label>
                            <input type="number" step="0.01" required className="w-full border p-2 rounded" value={form.price} onChange={e => setForm({...form, price: parseFloat(e.target.value)})} />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium mb-1">Stock</label>
                        <input type="number" required className="w-full border p-2 rounded" value={form.stock} onChange={e => setForm({...form, stock: parseFloat(e.target.value)})} />
                    </div>
                </>
              ) : (
                // VARIANT MANAGER
                <div className="border rounded p-4 bg-slate-50">
                    <div className="space-y-3 mb-4 border-b pb-4">
                        <label className="block text-xs font-bold uppercase text-slate-500">Add Variant</label>
                        <input 
                            placeholder="Variant Name (e.g. Red / XL)" 
                            className="w-full border p-2 rounded text-sm"
                            value={variantForm.name}
                            onChange={e => setVariantForm({...variantForm, name: e.target.value})}
                        />
                        <div className="grid grid-cols-3 gap-2">
                            <input type="number" placeholder="Cost" className="border p-2 rounded text-sm" value={variantForm.buyPrice} onChange={e => setVariantForm({...variantForm, buyPrice: parseFloat(e.target.value)})} />
                            <input type="number" placeholder="MRP" className="border p-2 rounded text-sm" value={variantForm.price} onChange={e => setVariantForm({...variantForm, price: parseFloat(e.target.value)})} />
                            <input type="number" placeholder="Stock" className="border p-2 rounded text-sm" value={variantForm.stock} onChange={e => setVariantForm({...variantForm, stock: parseFloat(e.target.value)})} />
                        </div>
                        <button type="button" onClick={handleAddVariant} className="w-full bg-slate-800 text-white py-2 rounded text-sm">Add Variant</button>
                    </div>

                    <div className="max-h-40 overflow-y-auto">
                        <table className="w-full text-xs text-left bg-white">
                            <thead className="bg-slate-200">
                                <tr>
                                    <th className="p-2">Name</th>
                                    <th className="p-2">Price</th>
                                    <th className="p-2">Stock</th>
                                    <th className="p-2 w-8"></th>
                                </tr>
                            </thead>
                            <tbody className="divide-y">
                                {form.variants?.map((v, i) => (
                                    <tr key={i}>
                                        <td className="p-2">{v.name}</td>
                                        <td className="p-2">₹{v.price}</td>
                                        <td className="p-2">{v.stock}</td>
                                        <td className="p-2 cursor-pointer text-red-500" onClick={() => removeVariant(i)}><Trash2 size={14} /></td>
                                    </tr>
                                ))}
                                {(!form.variants || form.variants.length === 0) && <tr><td colSpan={4} className="p-2 text-center">No variants added</td></tr>}
                            </tbody>
                        </table>
                    </div>
                </div>
              )}
              
              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 bg-slate-200 py-2 rounded hover:bg-slate-300">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save Product</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {adjustingProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl w-96 shadow-2xl">
            <h3 className="text-xl font-bold mb-1">Adjust Stock</h3>
            <p className="text-sm text-slate-500 mb-4">Product: {adjustingProduct.name}</p>
            
            <form onSubmit={handleStockAdjustment} className="space-y-4">
              
              {/* VARIANT SELECTOR FOR ADJUSTMENT */}
              {adjustingProduct.variants && adjustingProduct.variants.length > 0 ? (
                  <div>
                      <label className="block text-sm font-medium mb-1 text-slate-700">Select Variant</label>
                      <select 
                        className="w-full border p-2 rounded"
                        value={selectedVariantId}
                        onChange={e => setSelectedVariantId(e.target.value)}
                        required
                      >
                          <option value="">-- Select Variant --</option>
                          {adjustingProduct.variants.map(v => (
                              <option key={v.id} value={v.id}>{v.name} (Stk: {v.stock})</option>
                          ))}
                      </select>
                  </div>
              ) : (
                  <p className="text-xs bg-slate-100 p-2 rounded">Current Stock: <b>{adjustingProduct.stock}</b></p>
              )}

              <div className="flex bg-slate-100 p-1 rounded">
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'INCREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'INCREASE' ? 'bg-green-500 text-white shadow' : 'text-slate-500'}`}
                >
                  <ArrowUp size={16} /> Add Stock
                </button>
                <button 
                  type="button"
                  onClick={() => setAdjForm({ ...adjForm, type: 'DECREASE' })}
                  className={`flex-1 py-2 rounded flex items-center justify-center gap-2 text-sm font-medium transition ${adjForm.type === 'DECREASE' ? 'bg-red-500 text-white shadow' : 'text-slate-500'}`}
                >
                   <ArrowDown size={16} /> Reduce Stock
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Quantity</label>
                <input required type="number" min="0" className="w-full border p-2 rounded" value={adjForm.qty} onChange={e => setAdjForm({...adjForm, qty: parseFloat(e.target.value)})} />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-1">Reason</label>
                <textarea 
                  required 
                  className="w-full border p-2 rounded" 
                  value={adjForm.reason} 
                  onChange={e => setAdjForm({...adjForm, reason: e.target.value})}
                  rows={2}
                ></textarea>
              </div>

              <div className="flex gap-2 pt-2">
                <button type="button" onClick={() => { setAdjustingProduct(null); setSelectedVariantId(''); }} className="flex-1 bg-slate-200 py-2 rounded hover:bg-slate-300">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-2 rounded hover:bg-blue-700">Save</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* History Modal */}
      {historyProduct && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[80vh] flex flex-col">
                  <div className="p-4 border-b flex justify-between items-center">
                      <div>
                        <h3 className="text-lg font-bold">Stock History</h3>
                        <p className="text-sm text-slate-500">{historyProduct.name}</p>
                      </div>
                      <button onClick={() => setHistoryProduct(null)} className="text-slate-400 hover:text-black">
                          <X size={20} />
                      </button>
                  </div>
                  
                  <div className="p-0 overflow-auto flex-1">
                      <table className="w-full text-left text-sm">
                          <thead className="bg-slate-50 text-slate-500 sticky top-0">
                              <tr>
                                  <th className="p-4">Date</th>
                                  <th className="p-4">Variant</th>
                                  <th className="p-4">Type</th>
                                  <th className="p-4 text-center">Qty</th>
                                  <th className="p-4">Reason</th>
                              </tr>
                          </thead>
                          <tbody className="divide-y">
                              {historyData.map(adj => (
                                  <tr key={adj.id}>
                                      <td className="p-4 text-slate-500">{adj.date}</td>
                                      <td className="p-4 text-xs font-mono">{adj.variantName || '-'}</td>
                                      <td className="p-4">
                                          <span className={`px-2 py-1 rounded-full text-xs font-bold ${adj.type === 'INCREASE' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                              {adj.type}
                                          </span>
                                      </td>
                                      <td className="p-4 text-center font-medium">{adj.qty}</td>
                                      <td className="p-4 text-slate-600">{adj.reason}</td>
                                  </tr>
                              ))}
                              {historyData.length === 0 && (
                                  <tr><td colSpan={5} className="p-8 text-center text-slate-400">No stock adjustment history found.</td></tr>
                              )}
                          </tbody>
                      </table>
                  </div>
                  
                  <div className="p-4 border-t text-right bg-slate-50">
                      <button onClick={() => setHistoryProduct(null)} className="px-4 py-2 bg-white border rounded hover:bg-slate-50 font-medium">Close</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};